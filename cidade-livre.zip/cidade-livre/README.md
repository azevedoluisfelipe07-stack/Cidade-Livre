# CIDADE LIVRE — sandbox de direção 3D no navegador

Jogo single-player de direção em mundo aberto: uma cidade contemporânea gerada proceduralmente (ruas, avenidas, semáforos,
prédios com lojas, parques, árvores, tráfego e carros estacionados) e um cupê esportivo com física semirrealista.
**Sem missões, sem pontuação, sem multiplayer** — apenas dirigir e explorar. Interface 100% em português.

## Como rodar

**Opção 1 — mais simples (sem instalar nada):** abra o arquivo `dist/cidade-livre.html` com um duplo clique em um navegador
atualizado (Chrome, Edge ou Firefox, com aceleração de hardware ligada) e clique em **INICIAR**.

**Opção 2 — pelo `index.html`:** também funciona por duplo clique (ele usa `dist/jogo.js`). Se preferir um servidor local:
`node server.mjs` e acesse http://localhost:8080 (ou qualquer servidor estático, ex.: `python3 -m http.server`).

**Recompilar após editar o código** (opcional): `npm install` e `npm run build` (usa esbuild; o Three.js já está em `vendor/`).

## Controles

| Ação | Teclado | Gamepad |
|---|---|---|
| Acelerar / frear e ré | `W` `S` ou `↑` `↓` | gatilhos RT / LT |
| Esterçar | `A` `D` ou `←` `→` | analógico esquerdo |
| Freio de mão (drift) | `Espaço` | A / ✕ |
| Câmera externa / interna | `C` | Y / △ |
| Olhar para trás | segure `B` | — |
| Girar a câmera | arraste o mouse | analógico direito |
| Faróis / buzina | `F` / `H` | LB / X |
| Reposicionar o carro na pista | `R` | B / ○ |
| Horário (+3 h) / clima | `T` / `Y` | RB / ↑ |
| Minimapa / som | `M` / `N` | ← |
| Menu / pausa | `Esc` ou `P` | Start |

## Qualidade gráfica

| Preset | O que ativa |
|---|---|
| **Baixo** | sem sombras nem pós-processamento, 75 % da resolução, menos tráfego e árvores |
| **Médio** | sombras 2048, bloom, SMAA, reflexos do céu (PMREM), luzes de postes, tráfego moderado |
| **Alto** | sombras 4096, MSAA 4×, oclusão ambiente GTAO, bloom, reflexos em alta resolução, mais tráfego e carros estacionados |

Há também **resolução dinâmica**: se a taxa de quadros cair, o jogo reduz a escala de renderização automaticamente.
O ciclo de dia/noite e o clima (limpo, nublado, chuva) podem ser mudados no menu ou durante o jogo.

## Tecnologia (e por quê)

* **WebGL2 via Three.js** — é o caminho com suporte universal hoje. WebGPU ainda não está disponível de forma consistente
  em todos os navegadores/placas; WebGL2 entrega o mesmo nível visual aqui com muito mais compatibilidade.
* **Gráficos:** céu físico (Preetham) com nuvens, estrelas e lua; sol com sombras de alta resolução estabilizadas; reflexos de
  ambiente em tempo real (PMREM); materiais PBR (fachadas com mapas de rugosidade/metal e janelas emissivas à noite);
  tinta do carro com *clear coat*, vidros, faróis e lanternas desenhados em shader; asfalto molhado na chuva; bloom, GTAO,
  MSAA/SMAA, tone mapping ACES, gradação de cor, vinheta e desfoque radial por velocidade.
* **Física:** modelo bicicleta com pneus tipo Pacejka, transferência de carga, círculo de atrito, motor com curva de torque,
  câmbio automático de 6 marchas, freio de mão, colisões por SAT com impulsos e atrito (cenário, postes, árvores, carros).
* **Tráfego:** IA que segue faixas, respeita semáforos, converte nos cruzamentos e reage a colisões.
* **Áudio:** sintetizado em WebAudio (motor, pneus, vento, chuva, batidas, buzina), sem arquivos externos.
* Tudo é procedural: **nenhum modelo, textura ou áudio externo** — o projeto é totalmente autocontido.

## Estrutura

```
index.html, style.css      página, menu e HUD
dist/cidade-livre.html     versão em arquivo único (pronta para jogar)
dist/jogo.js               código empacotado usado pelo index.html
src/                       código-fonte (city, car, physics, sky, post, traffic, audio, camera, input, main…)
vendor/three/              Three.js (build + addons usados)
build.mjs, server.mjs      empacotamento e servidor estático opcionais
```
