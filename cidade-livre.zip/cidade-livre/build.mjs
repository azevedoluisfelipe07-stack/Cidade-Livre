// Empacota o jogo com esbuild: dist/jogo.js (para index.html) e dist/cidade-livre.html (arquivo único).
import { createRequire } from 'node:module';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);
let esbuild;
try { esbuild = require('esbuild'); } catch { esbuild = require('/opt/npm-tools/node_modules/esbuild'); }
const minify = !process.argv.includes('--dev');
const res = await esbuild.build({
  entryPoints: [path.join(here, 'src/main.js')], bundle: true, format: 'iife', minify, write: false, target: 'es2020',
  alias: { three: path.join(here, 'vendor/three/build/three.module.js'), 'three/addons': path.join(here, 'vendor/three/examples/jsm') },
  legalComments: 'none', logLevel: 'warning',
});
const js = res.outputFiles[0].text;
fs.mkdirSync(path.join(here, 'dist'), { recursive: true });
fs.writeFileSync(path.join(here, 'dist/jogo.js'), js);
let html = fs.readFileSync(path.join(here, 'index.html'), 'utf8');
const css = fs.readFileSync(path.join(here, 'style.css'), 'utf8');
html = html.replace('<link rel="stylesheet" href="style.css">', `<style>${css}</style>`)
  .replace('<script src="dist/jogo.js"></script>', () => `<script>${js.replace(/<\/script/g, '<\\/script')}</script>`);
fs.writeFileSync(path.join(here, 'dist/cidade-livre.html'), html);
console.log('ok', (js.length / 1024).toFixed(0) + ' KB');
