// Áudio sintetizado com WebAudio: motor, pneus, vento, chuva, colisões e buzina.
import { clamp, lerp } from './util.js';

export class GameAudio {
  constructor() { this.ctx = null; this.muted = false; this.ready = false; }
  start() {
    if (this.ctx) { this.ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
    const c = this.ctx = new AC();
    this.master = c.createGain(); this.master.gain.value = this.muted ? 0 : 0.7; this.master.connect(c.destination);
    const comp = c.createDynamicsCompressor(); comp.connect(this.master); this.bus = comp;
    // ruído
    const len = c.sampleRate * 2, nb = c.createBuffer(1, len, c.sampleRate), d = nb.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    this.noiseBuf = nb;
    const noise = () => { const s = c.createBufferSource(); s.buffer = nb; s.loop = true; s.start(); return s; };
    // motor
    this.eng = { g: c.createGain(), lp: c.createBiquadFilter(), sh: c.createWaveShaper(), o: [] };
    const curve = new Float32Array(512); for (let i = 0; i < 512; i++) { const x = i / 256 - 1; curve[i] = Math.tanh(x * 2.6); }
    this.eng.sh.curve = curve;
    this.eng.lp.type = 'lowpass'; this.eng.lp.Q.value = 1.2;
    for (const [type, mul, gain] of [['sawtooth', 1, 0.5], ['square', 2, 0.16], ['sawtooth', 0.5, 0.55], ['triangle', 3, 0.14]]) {
      const o = c.createOscillator(); o.type = type; const g = c.createGain(); g.gain.value = gain;
      o.connect(g); g.connect(this.eng.sh); o.start(); this.eng.o.push({ o, mul });
    }
    this.eng.sh.connect(this.eng.lp); this.eng.lp.connect(this.eng.g); this.eng.g.connect(this.bus); this.eng.g.gain.value = 0;
    // admissão
    const n1 = noise(); this.intake = { g: c.createGain(), f: c.createBiquadFilter() };
    this.intake.f.type = 'bandpass'; this.intake.f.Q.value = 0.7; n1.connect(this.intake.f); this.intake.f.connect(this.intake.g); this.intake.g.connect(this.bus); this.intake.g.gain.value = 0;
    // pneus
    const n2 = noise(); this.squeal = { g: c.createGain(), f: c.createBiquadFilter() };
    this.squeal.f.type = 'bandpass'; this.squeal.f.Q.value = 7; this.squeal.f.frequency.value = 1500; n2.connect(this.squeal.f); this.squeal.f.connect(this.squeal.g); this.squeal.g.connect(this.bus); this.squeal.g.gain.value = 0;
    // vento + rolagem
    const n3 = noise(); this.wind = { g: c.createGain(), f: c.createBiquadFilter() };
    this.wind.f.type = 'lowpass'; this.wind.f.frequency.value = 500; n3.connect(this.wind.f); this.wind.f.connect(this.wind.g); this.wind.g.connect(this.bus); this.wind.g.gain.value = 0;
    // chuva
    const n4 = noise(); this.rain = { g: c.createGain(), f: c.createBiquadFilter() };
    this.rain.f.type = 'highpass'; this.rain.f.frequency.value = 1400; n4.connect(this.rain.f); this.rain.f.connect(this.rain.g); this.rain.g.connect(this.bus); this.rain.g.gain.value = 0;
    // cidade ao fundo
    const n5 = noise(); this.amb = { g: c.createGain(), f: c.createBiquadFilter() };
    this.amb.f.type = 'lowpass'; this.amb.f.frequency.value = 220; n5.connect(this.amb.f); this.amb.f.connect(this.amb.g); this.amb.g.connect(this.bus); this.amb.g.gain.value = 0.05;
    // buzina
    this.horn = c.createGain(); this.horn.gain.value = 0; this.horn.connect(this.bus);
    for (const f of [392, 494]) { const o = c.createOscillator(); o.type = 'square'; o.frequency.value = f; const g = c.createGain(); g.gain.value = 0.07; const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 1800; o.connect(g); g.connect(lp); lp.connect(this.horn); o.start(); }
    this.ready = true;
  }
  setMuted(m) { this.muted = m; if (this.master) this.master.gain.setTargetAtTime(m ? 0 : 0.7, this.ctx.currentTime, 0.05); }
  update(dt, s) {
    if (!this.ready) return;
    const c = this.ctx, t = c.currentTime, k = 0.06;
    const rpmF = clamp((s.rpm - 900) / 6300, 0, 1);
    const f = (s.rpm / 60) * 3; // V6
    for (const o of this.eng.o) o.o.frequency.setTargetAtTime(f * o.mul * (1 + (Math.random() - 0.5) * 0.004), t, 0.03);
    this.eng.lp.frequency.setTargetAtTime(380 + rpmF * 2400 + s.throttle * 1400, t, k);
    this.eng.g.gain.setTargetAtTime(s.cockpit ? 0.22 + s.throttle * 0.16 : 0.15 + s.throttle * 0.17, t, k);
    this.intake.f.frequency.setTargetAtTime(600 + rpmF * 2500, t, k);
    this.intake.g.gain.setTargetAtTime(s.throttle * (0.02 + rpmF * 0.05), t, k);
    this.squeal.g.gain.setTargetAtTime(s.skid * 0.13 * (s.speed > 3 ? 1 : 0), t, 0.04);
    this.squeal.f.frequency.setTargetAtTime(1200 + s.speed * 18 + s.skid * 500, t, 0.05);
    this.wind.g.gain.setTargetAtTime(clamp(s.speed / 60, 0, 1) ** 1.5 * 0.35 + s.speed * 0.0015, t, k);
    this.wind.f.frequency.setTargetAtTime(300 + s.speed * 18, t, k);
    this.rain.g.gain.setTargetAtTime(s.rain * (s.cockpit ? 0.1 : 0.06), t, 0.3);
    this.horn.gain.setTargetAtTime(s.horn ? 1 : 0, t, 0.015);
  }
  crash(intensity) {
    if (!this.ready) return;
    const c = this.ctx, t = c.currentTime, a = clamp(intensity / 14, 0.1, 1);
    const s = c.createBufferSource(); s.buffer = this.noiseBuf;
    const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 900 + a * 3000;
    const g = c.createGain(); g.gain.setValueAtTime(a * 0.9, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.35 + a * 0.4);
    s.connect(f); f.connect(g); g.connect(this.bus); s.start(t, Math.random()); s.stop(t + 0.9);
    const o = c.createOscillator(); o.type = 'sine'; o.frequency.setValueAtTime(110, t); o.frequency.exponentialRampToValueAtTime(40, t + 0.3);
    const og = c.createGain(); og.gain.setValueAtTime(a * 0.9, t); og.gain.exponentialRampToValueAtTime(0.001, t + 0.35);
    o.connect(og); og.connect(this.bus); o.start(t); o.stop(t + 0.4);
  }
}
