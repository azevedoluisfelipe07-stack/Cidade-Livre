// Câmera em terceira pessoa (perseguição) e interna (cockpit).
import * as THREE from 'three';
import { clamp, lerp, angleDiff } from './util.js';

export class CameraRig {
  constructor(camera, city) {
    this.cam = camera; this.city = city; this.mode = 0;
    this.yaw = 0; this.pos = new THREE.Vector3(); this.look = new THREE.Vector3(); this.fov = 60;
    this.shake = 0; this.init = false; this.dist = 6.5;
    this.tmpQ = new THREE.Quaternion(); this.tmpQ2 = new THREE.Quaternion(); this.tmpV = new THREE.Vector3(); this.e = new THREE.Euler();
  }
  toggle() { this.mode = 1 - this.mode; this.init = false; return this.mode; }
  kick(a) { this.shake = Math.min(1.2, this.shake + a); }

  update(dt, veh, carObj, input, t) {
    const cam = this.cam;
    const sp = veh.speed;
    const cx = veh.x + Math.sin(veh.yaw) * veh.cOff, cz = veh.z + Math.cos(veh.yaw) * veh.cOff;
    const gy = veh.y;
    this.shake = Math.max(0, this.shake - dt * 2.2);
    const sh = this.shake * this.shake * 0.35 + (sp > 25 ? (sp - 25) * 0.0012 : 0);
    const jx = (Math.sin(t * 61) + Math.sin(t * 37.3)) * sh * 0.5, jy = (Math.sin(t * 53.1) + Math.cos(t * 71)) * sh * 0.5;

    if (this.mode === 0) {
      const velAng = Math.atan2(veh.vx, veh.vz);
      let target = veh.yaw;
      if (sp > 4 && veh.fwdSpeed > 0) target += angleDiff(veh.yaw, velAng) * 0.3 * clamp(sp / 14, 0, 1);
      if (!this.init) { this.yaw = target; this.init = true; this.pos.set(cx, gy + 3, cz); }
      this.yaw += angleDiff(this.yaw, target) * (1 - Math.exp(-dt * (3.2 + sp * 0.04)));
      let yaw = this.yaw + input.orbitYaw + (input.lookBack ? Math.PI : 0);
      const pitch = input.orbitPitch;
      const dist = 6.4 + sp * 0.022 + (this.mode === 0 ? 0 : 0);
      const h = 1.95 + sp * 0.005 + pitch * 4.5;
      const dx = Math.sin(yaw), dz = Math.cos(yaw);
      const ex = cx - dx * dist * Math.cos(pitch * 0.5), ez = cz - dz * dist * Math.cos(pitch * 0.5);
      const ey = gy + h;
      // lookAt do ponto do carro; evita atravessar prédios
      const ly = gy + 1.15;
      const t0 = this.city.freeAlong(cx, cz, ex, ez, 0.7);
      const fx = lerp(cx, ex, t0), fz = lerp(cz, ez, t0);
      const desired = this.tmpV.set(fx, Math.max(ey, 0.7), fz);
      this.pos.lerp(desired, 1 - Math.exp(-dt * 14));
      this.look.set(cx + dx * 3.2, ly, cz + dz * 3.2);
      cam.position.copy(this.pos); cam.position.x += jx; cam.position.y += jy;
      cam.lookAt(this.look);
      const fovT = 58 + clamp(sp, 0, 70) * 0.32 + (input.lookBack ? 0 : 0);
      this.fov = lerp(this.fov, fovT, 1 - Math.exp(-dt * 3));
      cam.near = 0.3;
    } else {
      const car = carObj;
      car.group.updateMatrixWorld(true);
      const eye = car.interior ? car.interior.eye : new THREE.Vector3(0.36, 1.3, 0.2);
      const p = car.body.localToWorld(eye.clone());
      cam.position.copy(p); cam.position.x += jx * 0.4; cam.position.y += jy * 0.4;
      car.body.getWorldQuaternion(this.tmpQ);
      this.e.set(0.05 + clamp(-input.orbitPitch * 0.7, -0.5, 0.5), Math.PI + clamp(input.orbitYaw, -2.2, 2.2) + (input.lookBack ? Math.PI : 0), 0, 'YXZ');
      this.tmpQ2.setFromEuler(this.e);
      cam.quaternion.copy(this.tmpQ).multiply(this.tmpQ2);
      this.fov = lerp(this.fov, 84 + clamp(sp, 0, 70) * 0.1, 1 - Math.exp(-dt * 3));
      cam.near = 0.05;
    }
    cam.fov = this.fov; cam.updateProjectionMatrix();
  }
}
