// Modelo procedural do carro: carroceria por "loft" + detalhes desenhados no shader da pintura.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { curve, clamp } from './util.js';
import { makePlate } from './textures.js';

// ------------------------------------------------------------------ especificações
const BASE = {
  coupe: { L: 4.72, W: 0.93, gc: 0.22, bh: 0.97, deck: 1.0, hoodY: 0.9, noseH: 0.58, tailH: 0.82, cabF: 1.0, roofF: 0.42, roofR: -0.55, cabR: -1.12, roofH: 1.42, wR: 0.335, wzF: 1.42, wzR: -1.45, tw: 0.245, mass: 1560, name: 'Cupê' },
  sedan: { L: 4.55, W: 0.9, gc: 0.2, bh: 0.98, deck: 1.02, hoodY: 0.93, noseH: 0.62, tailH: 0.88, cabF: 0.95, roofF: 0.32, roofR: -0.6, cabR: -1.05, roofH: 1.46, wR: 0.32, wzF: 1.35, wzR: -1.35, tw: 0.215, mass: 1400, name: 'Sedã' },
  hatch: { L: 3.95, W: 0.86, gc: 0.2, bh: 0.93, deck: 0.94, hoodY: 0.88, noseH: 0.6, tailH: 0.86, cabF: 0.72, roofF: 0.1, roofR: -0.98, cabR: -1.2, roofH: 1.5, wR: 0.3, wzF: 1.15, wzR: -1.15, tw: 0.195, mass: 1150, name: 'Hatch' },
  suv: { L: 4.65, W: 0.95, gc: 0.28, bh: 1.15, deck: 1.18, hoodY: 1.08, noseH: 0.74, tailH: 0.98, cabF: 0.95, roofF: 0.2, roofR: -1.0, cabR: -1.45, roofH: 1.72, wR: 0.37, wzF: 1.4, wzR: -1.4, tw: 0.26, mass: 1850, name: 'SUV' },
};
export const CAR_TYPES = Object.keys(BASE);

export function makeSpec(type) {
  const p = BASE[type];
  const zr = -p.L / 2, zf = p.L / 2;
  const s = { ...p, type, zr, zf };
  s.top = curve([[zr, p.tailH], [zr + 0.22, p.deck - 0.04], [p.cabR - 0.3, p.deck], [(p.cabR + p.cabF) / 2, p.bh], [p.cabF + 0.1, p.bh - 0.015],
    [p.cabF + 0.55, p.hoodY + 0.02], [zf - 0.45, p.hoodY - 0.04], [zf - 0.12, p.noseH + 0.14], [zf, p.noseH]]);
  s.bot = curve([[zr, p.gc + 0.1], [zr + 0.3, p.gc], [zf - 0.35, p.gc], [zf, p.gc + 0.12]]);
  s.half = curve([[zr, p.W * 0.84], [zr + 0.55, p.W * 0.96], [zr + 1.2, p.W], [zf - 1.0, p.W], [zf - 0.35, p.W * 0.97], [zf, p.W * 0.86]]);
  const bh = p.bh, rh = p.roofH;
  s.ghTop = curve([[p.cabR, bh + 0.01], [p.cabR + (p.roofR - p.cabR) * 0.45, bh + (rh - bh) * 0.62], [p.roofR, rh - 0.04], [(p.roofR + p.roofF) / 2, rh],
    [p.roofF, rh - 0.04], [p.roofF + (p.cabF - p.roofF) * 0.45, bh + (rh - bh) * 0.66], [p.cabF, bh + 0.005]]);
  s.ghHalf = curve([[p.cabR, p.W * 0.76], [p.roofR, p.W * 0.8], [0, p.W * 0.81], [p.roofF, p.W * 0.8], [p.cabF, p.W * 0.76]]);
  s.trackX = p.W - 0.12;
  s.wheelR = p.wR;
  // parâmetros dos vidros / detalhes para o shader
  const yW0 = bh + 0.035, yW1 = rh - 0.1;
  const zF0 = p.cabF - 0.17, zTopF = p.roofF, zR0 = p.cabR + 0.15, zTopR = p.roofR - 0.03;
  s.shader = {
    uA: new THREE.Vector4(yW0, yW1, zF0, (zF0 - zTopF) / (yW1 - yW0)),
    uB: new THREE.Vector4(zR0, (zTopR - zR0) / (yW1 - yW0), (p.roofF + p.roofR) / 2 - 0.12, p.roofF + 0.02),
    uC: new THREE.Vector4(p.roofR - 0.02, zf, zr, p.gc),
    uD: new THREE.Vector4(zF0 - 0.05, (p.roofF + p.roofR) / 2 - 0.12, p.cabR - 0.1, bh),
    uE: new THREE.Vector4(p.cabF + 0.1, zf - 0.12, p.W * 0.68, p.cabR - 0.38),
    uF: new THREE.Vector4(p.noseH + 0.1, p.W * 0.64, 0.2, 0.065),
    uG: new THREE.Vector4(p.tailH - 0.1, p.W * 0.6, 0.3, 0.045),
  };
  return s;
}

// ------------------------------------------------------------------ geometria
function addAttrs(g, roof = null, hw = null) {
  if (g.index) g = g.toNonIndexed();
  if (g.attributes.uv) g.deleteAttribute('uv');
  const n = g.attributes.position.count;
  g.setAttribute('aRoof', new THREE.BufferAttribute(roof || new Float32Array(n), 1));
  g.setAttribute('aHW', new THREE.BufferAttribute(hw || new Float32Array(n), 1));
  return g;
}
function plain(g) {
  if (g.index) g = g.toNonIndexed();
  if (g.attributes.uv) g.deleteAttribute('uv');
  return g;
}

function loft(spec, which, S, R) {
  const isGH = which === 'gh';
  const z0 = isGH ? spec.cabR - 0.02 : spec.zr, z1 = isGH ? spec.cabF + 0.02 : spec.zf;
  const n = isGH ? 4 : 4.2, tumble = isGH ? 0.2 : 0.06;
  const pos = [], roof = [], hwA = [], idx = [];
  const sgnp = (v, e) => Math.sign(v) * Math.pow(Math.abs(v), e);
  for (let i = 0; i < S; i++) {
    const t = 0.5 - 0.5 * Math.cos((Math.PI * i) / (S - 1));
    const z = z0 + (z1 - z0) * t;
    let yb, yt, w;
    if (isGH) { yb = spec.bh - 0.1; yt = spec.ghTop(z); w = spec.ghHalf(z); }
    else { yb = spec.bot(z); yt = spec.top(z); w = spec.half(z); }
    let f = 1;
    if (!isGH) {
      const e = 0.2, d = Math.min(z - z0, z1 - z);
      f = Math.sqrt(clamp(d / e, 0.0004, 1));
    } else { f = 1; }
    const yc = (yb + yt) / 2, hh = (yt - yb) / 2;
    for (let k = 0; k < R; k++) {
      const a = (k / R) * Math.PI * 2;
      const ex = sgnp(Math.cos(a), 2 / n), ey = sgnp(Math.sin(a), 2 / n);
      const ww = w * f * (1 - tumble * Math.pow(0.5 + 0.5 * ey, 1.4));
      pos.push(ex * ww, yc + ey * hh * f, z);
      roof.push(isGH ? yt : 0); hwA.push(isGH ? w : 0);
    }
  }
  for (let i = 0; i < S - 1; i++) for (let k = 0; k < R; k++) {
    const a = i * R + k, b = i * R + ((k + 1) % R), c = (i + 1) * R + k, d = (i + 1) * R + ((k + 1) % R);
    idx.push(a, b, c, b, d, c);
  }
  let g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setIndex(idx);
  g.computeVertexNormals();
  // orientação: normal do vértice de topo (k = R/4) deve apontar +y
  const mid = Math.floor(S / 2) * R + Math.round(R / 4);
  if (g.attributes.normal.getY(mid) < 0) {
    const ix = g.index.array;
    for (let i = 0; i < ix.length; i += 3) { const t = ix[i + 1]; ix[i + 1] = ix[i + 2]; ix[i + 2] = t; }
    g.computeVertexNormals();
  }
  g.setAttribute('aRoof', new THREE.Float32BufferAttribute(roof, 1));
  g.setAttribute('aHW', new THREE.Float32BufferAttribute(hwA, 1));
  return g.toNonIndexed();
}

function box(w, h, d, x, y, z) { const g = new THREE.BoxGeometry(w, h, d); g.translate(x, y, z); return g; }

function wheelGeometry(R, tw, hi) {
  // pneu (lathe em torno de Y), depois gira para eixo X
  const rimR = R * 0.72, hw = tw / 2;
  const pts = [];
  const prof = [[rimR - 0.01, -hw * 0.92], [rimR + 0.02, -hw], [R * 0.86, -hw * 0.98], [R * 0.95, -hw * 0.82], [R * 0.995, -hw * 0.55], [R, -hw * 0.3],
    [R, -hw * 0.12], [R * 0.992, -hw * 0.09], [R * 0.992, hw * 0.09], [R, hw * 0.12], [R, hw * 0.3], [R * 0.995, hw * 0.55], [R * 0.95, hw * 0.82], [R * 0.86, hw * 0.98], [rimR + 0.02, hw], [rimR - 0.01, hw * 0.92]];
  for (const [r, y] of prof) pts.push(new THREE.Vector2(r, y));
  let tire = new THREE.LatheGeometry(pts, hi ? 36 : 16);
  tire.rotateZ(Math.PI / 2);
  tire = plain(tire);
  // aro: barril + face + raios
  const parts = [];
  const barrel = new THREE.CylinderGeometry(rimR, rimR * 0.92, tw * 0.9, hi ? 28 : 12, 1, true); barrel.rotateZ(Math.PI / 2);
  parts.push(plain(barrel));
  const face = new THREE.CylinderGeometry(rimR * 0.98, rimR * 0.98, 0.012, hi ? 28 : 12); face.rotateZ(Math.PI / 2); face.translate(hw * 0.55, 0, 0);
  const hub = new THREE.CylinderGeometry(rimR * 0.2, rimR * 0.2, 0.05, 12); hub.rotateZ(Math.PI / 2); hub.translate(hw * 0.62, 0, 0);
  parts.push(plain(hub));
  if (hi) {
    for (let i = 0; i < 10; i++) {
      const a = (i / 10) * Math.PI * 2;
      const sp = new THREE.BoxGeometry(0.022, rimR * 0.85, 0.045); sp.translate(hw * 0.58, rimR * 0.5, 0);
      sp.rotateX(a + (i % 2 ? 0.07 : -0.07)); parts.push(plain(sp));
    }
  } else parts.push(plain(face));
  const rim = mergeGeometries(parts);
  // disco de freio
  let disc = new THREE.CylinderGeometry(rimR * 0.78, rimR * 0.78, 0.028, hi ? 24 : 10); disc.rotateZ(Math.PI / 2); disc.translate(hw * 0.2, 0, 0);
  return { tire, rim, disc: plain(disc) };
}

export function buildCarGeometry(spec, lod = 'hi') {
  const hi = lod === 'hi';
  const S = hi ? 60 : 24, R = hi ? 44 : 20;
  const bodyParts = [loft(spec, 'body', S, R), loft(spec, 'gh', hi ? 36 : 14, hi ? 36 : 16)];
  const p = spec;
  const trim = [], chrome = [], under = [], liner = [];
  const archR = p.wR + 0.075;
  const wheels = [];
  for (const [zw, front] of [[p.wzF, true], [p.wzR, false]]) for (const sx of [1, -1]) wheels.push({ x: sx * p.trackX, z: zw, front, side: sx });
  // lábios dos paralamas (pintura) e forros (escuros)
  for (const w of wheels) {
    const lip = new THREE.TorusGeometry(archR + 0.005, 0.016, 5, hi ? 22 : 10, Math.PI);
    lip.rotateY(Math.PI / 2); lip.translate(w.side * (p.W - 0.005), p.wR, w.z);
    bodyParts.push(addAttrs(lip));
    // forro
    const segs = hi ? 18 : 8, ps = [];
    for (let k = 0; k <= segs; k++) {
      const a = (k / segs) * Math.PI;
      const zz = w.z + Math.cos(a) * archR, yy = p.wR + Math.sin(a) * archR;
      ps.push([zz, yy]);
    }
    const x0 = w.side * 0.45, x1 = w.side * (p.W - 0.03);
    const pos = [], ix = [];
    ps.forEach(([zz, yy], k) => { pos.push(x0, yy, zz, x1, yy, zz); if (k) { const b = (k - 1) * 2; ix.push(b, b + 1, b + 2, b + 1, b + 3, b + 2); } });
    const lg = new THREE.BufferGeometry(); lg.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); lg.setIndex(ix); lg.computeVertexNormals();
    liner.push(plain(lg));
    const wall = new THREE.CircleGeometry(archR, hi ? 18 : 8, 0, Math.PI); wall.rotateY(Math.PI / 2); wall.translate(w.side * 0.45, p.wR, w.z);
    liner.push(plain(wall));
  }
  // retrovisores
  for (const sx of [1, -1]) {
    const mz = p.cabF - 0.38, my = p.bh + 0.12, mx = sx * (p.ghHalf(mz) + 0.12);
    bodyParts.push(addAttrs(box(0.13, 0.08, 0.1, mx, my, mz)));
    trim.push(box(0.012, 0.08, 0.11, mx + sx * 0.05, my, mz - 0.01));
  }
  // spoiler discreto (cupê/sedã)
  if (p.type === 'coupe' || p.type === 'sedan') bodyParts.push(addAttrs(box(1.1, 0.025, 0.12, 0, p.deck + 0.03, p.zr + 0.28)));
  // difusor, splitter e saias
  trim.push(box(1.5, 0.03, 0.14, 0, p.gc + 0.02, p.zf - 0.14));
  trim.push(box(1.2, 0.04, 0.2, 0, p.gc + 0.04, p.zr + 0.2));
  for (const sx of [1, -1]) trim.push(box(0.03, 0.06, 1.7, sx * (p.W - 0.045), p.gc + 0.07, (p.wzF + p.wzR) / 2));
  // escapamentos
  for (const sx of [-1, 1]) { const e = new THREE.CylinderGeometry(0.04, 0.04, 0.12, 12); e.rotateX(Math.PI / 2); e.translate(sx * 0.55, p.gc + 0.07, p.zr + 0.03); chrome.push(plain(e)); }
  // assoalho
  under.push(box(p.W * 1.5, 0.05, p.L - 0.5, 0, p.gc + 0.05, 0));
  // grade frontal cromada fina e moldura dos vidros
  chrome.push(box(p.W * 0.9, 0.012, 0.01, 0, p.noseH + 0.0, p.zf - 0.02));
  const merge = (arr) => (arr.length ? mergeGeometries(arr.map(plain)) : null);
  const { tire, rim, disc } = wheelGeometry(p.wR, p.tw, hi);
  return {
    spec, wheels, wheelGeo: { tire, rim, disc },
    body: mergeGeometries(bodyParts.map((g) => addAttrs(g, g.attributes.aRoof?.array, g.attributes.aHW?.array))),
    trim: merge(trim), chrome: merge(chrome), under: merge(under), liner: merge(liner),
  };
}

// ------------------------------------------------------------------ materiais
const PAINT_VERT_DECL = `attribute float aRoof; attribute float aHW; varying vec3 vOP; varying vec3 vON; varying float vRoof; varying float vHW;`;
const PAINT_FRAG_DECL = `
varying vec3 vOP; varying vec3 vON; varying float vRoof; varying float vHW;
uniform vec4 uA,uB,uC,uD,uE,uF,uG; uniform vec3 uArch[4];
uniform float uLights, uBrake, uCockpit, uDetail, uRev;
float ln(float v, float w){ return 1.0 - smoothstep(w*0.5, w, abs(v)); }
`;
const PAINT_FRAG_MASK = `
  vec3 ap = vOP; vec3 an = normalize(vON);
  for (int i=0;i<4;i++){ vec2 dd = ap.zy - uArch[i].xy; if (dot(dd,dd) < uArch[i].z*uArch[i].z && abs(ap.x) > 0.45) discard; }
  float gl = 0.0; float gh = step(0.5, vRoof);
  float sideF = smoothstep(0.3, 0.5, abs(an.x));
  float yy = ap.y;
  float inY = smoothstep(uA.x, uA.x+0.02, yy) * (1.0 - smoothstep(vRoof-0.09, vRoof-0.06, yy));
  float zf = uA.z - (yy-uA.x)*uA.w;
  float zr = uB.x + (yy-uA.x)*uB.y;
  float inZ = (1.0 - smoothstep(zf-0.012, zf, ap.z)) * smoothstep(zr, zr+0.012, ap.z);
  float bp = smoothstep(0.03, 0.05, abs(ap.z - uB.z));
  float gS = sideF*inY*inZ*bp*gh;
  float wsX = 1.0 - smoothstep(0.78, 0.86, abs(ap.x)/max(vHW,0.1));
  float gW = smoothstep(0.08, 0.28, an.z) * step(uB.w - 0.07, ap.z) * smoothstep(uA.x-0.01, uA.x+0.02, yy) * wsX * gh;
  float gR = smoothstep(0.08, 0.28, -an.z) * step(ap.z, uC.x + 0.07) * smoothstep(uA.x-0.01, uA.x+0.02, yy) * wsX * gh;
  gl = clamp(gS+gW+gR, 0.0, 1.0);
  if (uCockpit > 0.5 && gl > 0.5) discard;
  float inner = gl_FrontFacing ? 0.0 : 1.0;
  // linhas de painel
  float lines = 0.0;
  if (uDetail > 0.5) {
    float lowS = smoothstep(0.55, 0.8, abs(an.x)) * smoothstep(uC.w+0.1, uC.w+0.16, yy) * (1.0 - smoothstep(uD.w-0.02, uD.w, yy)) * (1.0-gh);
    lines += lowS * max(ln(ap.z-uD.x, 0.009), max(ln(ap.z-uD.y, 0.009), ln(ap.z-uD.z, 0.009)));
    float top = smoothstep(0.75, 0.95, an.y) * (1.0-gh);
    float hood = step(uE.x, ap.z) * step(ap.z, uE.y);
    lines += top * hood * ln(abs(ap.x)-uE.z, 0.008);
    lines += top * ln(ap.z-uE.x, 0.008) * step(abs(ap.x), uE.z);
    lines += top * ln(ap.z-uE.w, 0.008) * step(abs(ap.x), uE.z);
    // maçanetas
    float handle = lowS * (step(abs(ap.z-(uD.x-0.32)),0.075)+step(abs(ap.z-(uD.y-0.32)),0.075)) * step(abs(yy-(uD.w-0.07)),0.012);
    lines += handle * 0.5;
  }
  diffuseColor.rgb *= 1.0 - clamp(lines,0.0,1.0)*0.85;
  // plásticos pretos: saias, para-choques inferiores, grade
  float lower = 1.0 - smoothstep(uC.w+0.1, uC.w+0.16, yy);
  float frontLow = step(uC.y-0.55, ap.z) * (1.0 - smoothstep(uC.w+0.24, uC.w+0.3, yy));
  float grille = step(uC.y-0.45, ap.z) * smoothstep(0.3,0.6,an.z) * step(abs(ap.x), uE.z*0.62) * smoothstep(uC.w+0.22, uC.w+0.26, yy) * (1.0 - smoothstep(uF.x-0.12, uF.x-0.08, yy));
  float rearLow = step(ap.z, uC.z+0.5) * (1.0 - smoothstep(uC.w+0.2, uC.w+0.26, yy)) * smoothstep(0.2, 0.5, -an.z);
  float plastic = clamp(lower*(1.0-gh) + frontLow + grille + rearLow, 0.0, 1.0);
  float meshp = 0.6 + 0.4*step(0.5, fract(ap.x*38.0)) * step(0.5, fract(ap.y*38.0+0.5));
  diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.018)*mix(1.0, meshp, grille), plastic);
  roughnessFactor = mix(roughnessFactor, 0.55, plastic);
  metalnessFactor = mix(metalnessFactor, 0.0, plastic);
  // vidros
  diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.075,0.085,0.095), gl);
  roughnessFactor = mix(roughnessFactor, 0.035, gl);
  metalnessFactor = mix(metalnessFactor, 1.0, gl);
  // faróis
  vec2 hq = vec2((abs(ap.x)-uF.y)/uF.z, (ap.y-uF.x-(abs(ap.x)-uF.y)*0.4)/uF.w);
  float hlm = (1.0 - smoothstep(0.82, 1.0, length(hq))) * smoothstep(0.1,0.4,an.z) * step(uC.y-0.65, ap.z);
  float core = (1.0 - smoothstep(0.1, 0.55, length(vec2(hq.x*0.8, hq.y*1.2)))) * hlm;
  float drl = hlm * smoothstep(0.35,0.5,hq.y) * (1.0 - smoothstep(0.7,0.9,hq.y)) ;
  diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.03,0.035,0.04), hlm);
  roughnessFactor = mix(roughnessFactor, 0.06, hlm);
  metalnessFactor = mix(metalnessFactor, 0.9, hlm);
  // lanternas
  vec2 tq = vec2((abs(ap.x)-uG.y)/uG.z, (ap.y-uG.x)/uG.w);
  float tlm = (1.0 - smoothstep(0.8, 1.0, max(abs(tq.x), abs(tq.y)*1.2))) * smoothstep(0.1,0.4,-an.z) * step(ap.z, uC.z+0.7);
  diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.25,0.0,0.0), tlm);
  roughnessFactor = mix(roughnessFactor, 0.12, tlm);
  if (inner > 0.5) { diffuseColor.rgb = vec3(0.1,0.1,0.11); roughnessFactor = 0.85; metalnessFactor = 0.0; }
`;
const PAINT_FRAG_EMIT = `
  totalEmissiveRadiance += vec3(1.0,0.96,0.88) * (core * (0.25 + uLights*5.0) + drl*(0.7 + uLights*0.5)) * 1.2;
  totalEmissiveRadiance += vec3(1.0,0.02,0.02) * tlm * (0.35 + uLights*0.5 + uBrake*6.0);
`;

export function makeCarMaterials(spec, colorHex, lod = 'hi') {
  const hi = lod === 'hi';
  const paint = new THREE.MeshPhysicalMaterial({
    color: colorHex, metalness: 0.55, roughness: 0.3, clearcoat: 1, clearcoatRoughness: 0.035,
    side: hi ? THREE.DoubleSide : THREE.FrontSide,
  });
  const U = {
    uA: { value: spec.shader.uA }, uB: { value: spec.shader.uB }, uC: { value: spec.shader.uC }, uD: { value: spec.shader.uD },
    uE: { value: spec.shader.uE }, uF: { value: spec.shader.uF }, uG: { value: spec.shader.uG },
    uArch: { value: [spec.wzF, spec.wzR, spec.wzF, spec.wzR].map((z) => new THREE.Vector3(z, spec.wR, spec.wR + 0.075)) },
    uLights: { value: 0 }, uBrake: { value: 0 }, uCockpit: { value: 0 }, uDetail: { value: 1 }, uRev: { value: 0 },
  };
  paint.userData.U = U;
  paint.customProgramCacheKey = () => 'carpaint' + (hi ? 'H' : 'L');
  paint.onBeforeCompile = (sh) => {
    Object.assign(sh.uniforms, U);
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\n' + PAINT_VERT_DECL)
      .replace('#include <begin_vertex>', '#include <begin_vertex>\n vOP = position; vON = normal; vRoof = aRoof; vHW = aHW;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\n' + PAINT_FRAG_DECL)
      .replace('#include <metalnessmap_fragment>', '#include <metalnessmap_fragment>\n' + PAINT_FRAG_MASK)
      .replace('#include <emissivemap_fragment>', '#include <emissivemap_fragment>\n' + PAINT_FRAG_EMIT);
  };
  const std = (o) => new THREE.MeshStandardMaterial(o);
  const m = {
    paint,
    trim: std({ color: 0x0c0c0d, roughness: 0.55 }),
    chrome: std({ color: 0x9a9fa4, metalness: 1, roughness: 0.3 }),
    under: std({ color: 0x050505, roughness: 0.9 }),
    liner: std({ color: 0x030303, roughness: 1, side: THREE.DoubleSide }),
    tire: std({ color: 0x0e0e10, roughness: 0.88 }),
    rim: std({ color: 0x8e949b, metalness: 1, roughness: 0.28 }),
    disc: std({ color: 0x80848a, metalness: 1, roughness: 0.45 }),
    caliper: std({ color: 0xb01418, roughness: 0.4, metalness: 0.3 }),
  };
  return m;
}

// ------------------------------------------------------------------ montagem do carro
/** Cria um Group completo com rodas animáveis. opts: {lod, color, interior} */
export function createCar(type, colorHex, opts = {}) {
  const lod = opts.lod || 'hi';
  const spec = makeSpec(type);
  const geo = opts.geo || buildCarGeometry(spec, lod);
  const mats = opts.mats || makeCarMaterials(spec, colorHex, lod);
  const group = new THREE.Group();
  const body = new THREE.Group(); // balança (pitch/roll)
  group.add(body);
  const add = (g, m, shadow = true) => { if (!g) return null; const mesh = new THREE.Mesh(g, m); mesh.castShadow = shadow; mesh.receiveShadow = true; body.add(mesh); return mesh; };
  const paintMesh = add(geo.body, mats.paint);
  add(geo.trim, mats.trim); add(geo.chrome, mats.chrome); add(geo.under, mats.under, false); add(geo.liner, mats.liner, false);
  // placas
  if (lod === 'hi') {
    const plateMat = new THREE.MeshStandardMaterial({ map: makePlate(), roughness: 0.4 });
    const pg = new THREE.PlaneGeometry(0.52, 0.13);
    const pr = new THREE.Mesh(pg, plateMat); pr.position.set(0, spec.gc + 0.36, spec.zr + 0.075); pr.rotation.y = Math.PI; body.add(pr);
    const pf = new THREE.Mesh(pg, plateMat); pf.position.set(0, spec.gc + 0.14, spec.zf - 0.04); body.add(pf);
  }
  // rodas
  const wheels = [];
  for (const w of geo.wheels) {
    const pivot = new THREE.Group(); pivot.position.set(w.x, spec.wR, w.z);
    const spin = new THREE.Group(); pivot.add(spin);
    const side = w.side > 0 ? 1 : -1;
    const tire = new THREE.Mesh(geo.wheelGeo.tire, mats.tire); tire.castShadow = lod === 'hi';
    const rim = new THREE.Mesh(geo.wheelGeo.rim, mats.rim);
    const disc = new THREE.Mesh(geo.wheelGeo.disc, mats.disc);
    for (const m of [tire, rim, disc]) { if (side < 0) m.rotation.y = Math.PI; spin.add(m); }
    if (lod === 'hi') {
      const cal = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.12, 0.2), mats.caliper);
      cal.position.set(side * spec.tw * 0.05, spec.wR * 0.42 * 0.0 + 0.05, w.front ? 0.19 : -0.19); cal.position.y = 0.14;
      pivot.add(cal);
    }
    body.add(pivot);
    wheels.push({ pivot, spin, front: w.front, side, x: w.x, z: w.z });
  }
  const car = { group, body, wheels, spec, mats, geo, paintMesh, lod };
  car.setColor = (c) => mats.paint.color.set(c);
  if (opts.interior) car.interior = buildInterior(spec, body);
  return car;
}

// ------------------------------------------------------------------ interior (visível só na câmera interna)
function buildInterior(spec, parent) {
  const g = new THREE.Group(); parent.add(g);
  const dark = new THREE.MeshStandardMaterial({ color: 0x0f1012, roughness: 0.75 });
  const leather = new THREE.MeshStandardMaterial({ color: 0x1a1512, roughness: 0.6 });
  const soft = new THREE.MeshStandardMaterial({ color: 0x24262a, roughness: 0.9 });
  const m = (geo, mat, x, y, z) => { const o = new THREE.Mesh(geo, mat); o.position.set(x, y, z); g.add(o); return o; };
  const W = spec.W, bh = spec.bh;
  const zd = spec.cabF - 0.12;
  // painel
  const dash = new THREE.BoxGeometry(W * 1.52, 0.2, 0.42);
  m(dash, dark, 0, bh + 0.06, zd - 0.14).rotation.x = -0.15;
  m(new THREE.BoxGeometry(W * 1.5, 0.08, 0.22), soft, 0, bh + 0.17, zd - 0.12);
  // console central
  m(new THREE.BoxGeometry(0.22, 0.2, 1.1), dark, 0, bh - 0.28, zd - 0.62);
  m(new THREE.BoxGeometry(0.2, 0.12, 0.4), soft, 0, bh - 0.12, zd - 0.7);
  // bancos
  const sx = 0.36;
  for (const x of [sx, -sx]) {
    m(new THREE.BoxGeometry(0.5, 0.14, 0.52), leather, x, bh - 0.3, zd - 0.95);
    const back = m(new THREE.BoxGeometry(0.48, 0.62, 0.12), leather, x, bh + 0.0, zd - 1.22); back.rotation.x = -0.18;
    m(new THREE.BoxGeometry(0.28, 0.14, 0.1), leather, x, bh + 0.38, zd - 1.28);
  }
  m(new THREE.BoxGeometry(1.2, 0.14, 0.5), leather, 0, bh - 0.3, spec.cabR + 0.55);
  m(new THREE.BoxGeometry(1.2, 0.5, 0.12), leather, 0, bh - 0.02, spec.cabR + 0.3).rotation.x = -0.25;
  // painel de instrumentos (canvas)
  const cv = document.createElement('canvas'); cv.width = 512; cv.height = 192;
  const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace;
  const gauge = new THREE.Mesh(new THREE.PlaneGeometry(0.34, 0.127), new THREE.MeshBasicMaterial({ map: tex, toneMapped: false }));
  gauge.position.set(sx, bh + 0.2, zd - 0.28); gauge.rotation.x = -0.55; gauge.rotation.y = Math.PI; gauge.rotation.set(-0.5, Math.PI, 0);
  g.add(gauge);
  // volante
  const sw = new THREE.Group(); sw.position.set(sx, bh + 0.16, zd - 0.42); sw.rotation.x = 0.42; g.add(sw);
  const rimG = new THREE.Mesh(new THREE.TorusGeometry(0.17, 0.018, 8, 28), leather); sw.add(rimG);
  const sp = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.025, 0.02), dark); sw.add(sp);
  const sp2 = new THREE.Mesh(new THREE.BoxGeometry(0.025, 0.15, 0.02), dark); sp2.position.y = -0.07; sw.add(sp2);
  // moldura de teto / colunas
  m(new THREE.BoxGeometry(W * 1.4, 0.03, 1.4), soft, 0, spec.roofH - 0.05, 0.0).visible = false;
  g.visible = false;
  const ctx = cv.getContext('2d');
  return {
    group: g, wheel: sw, eye: new THREE.Vector3(sx, bh + 0.37, zd - 0.62),
    drawGauge(kmh, rpm, gear) {
      ctx.fillStyle = '#05070a'; ctx.fillRect(0, 0, 512, 192);
      const dial = (cx, max, val, label, major) => {
        ctx.strokeStyle = 'rgba(255,255,255,0.25)'; ctx.lineWidth = 4;
        ctx.beginPath(); ctx.arc(cx, 100, 78, Math.PI * 0.75, Math.PI * 2.25); ctx.stroke();
        const a = Math.PI * 0.75 + clamp(val / max, 0, 1) * Math.PI * 1.5;
        ctx.strokeStyle = '#ff7a3a'; ctx.lineWidth = 6; ctx.beginPath(); ctx.arc(cx, 100, 78, Math.PI * 0.75, a); ctx.stroke();
        ctx.fillStyle = '#fff'; ctx.font = '600 20px Arial'; ctx.textAlign = 'center';
        for (let v = 0; v <= max; v += major) { const aa = Math.PI * 0.75 + (v / max) * Math.PI * 1.5; ctx.fillText(String(label === 'rpm' ? v / 1000 : v), cx + Math.cos(aa) * 58, 106 + Math.sin(aa) * 58); }
      };
      dial(120, 280, kmh, 'kmh', 40); dial(392, 8000, rpm, 'rpm', 1000);
      ctx.fillStyle = '#fff'; ctx.font = '700 46px Arial'; ctx.textAlign = 'center'; ctx.fillText(String(Math.round(kmh)), 120, 112);
      ctx.font = '700 40px Arial'; ctx.fillStyle = '#ffd9a0'; ctx.fillText(gear, 256, 150);
      tex.needsUpdate = true;
    },
  };
}
