// Geração procedural da cidade: ruas, quarteirões, prédios, mobiliário urbano, árvores e colisores.
import * as THREE from 'three';
import { mergeGeometries, mergeVertices } from 'three/addons/utils/BufferGeometryUtils.js';
import { WORLD } from './config.js';
import * as T from './textures.js';
import { mulberry32, clamp, lerp, smoothstep } from './util.js';

const { N, BLOCK: B, ROAD_STD, ROAD_AVE, SIDEWALK: SW, CURB } = WORLD;

// ------------------------------------------------------------------ acumuladores de geometria
class Acc {
  constructor() { this.pos = []; this.nor = []; this.uv = []; this.col = []; this.idx = []; this.n = 0; }
  quad(a, b, c, d, uvs, col, nrm) {
    // a,b,c,d anti-horário visto de fora. uvs: [u0,v0,u1,v1,u2,v2,u3,v3]
    let nx, ny, nz;
    if (nrm) { [nx, ny, nz] = nrm; } else {
      const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2];
      const vx = d[0] - a[0], vy = d[1] - a[1], vz = d[2] - a[2];
      nx = uy * vz - uz * vy; ny = uz * vx - ux * vz; nz = ux * vy - uy * vx;
      const l = Math.hypot(nx, ny, nz) || 1; nx /= l; ny /= l; nz /= l;
    }
    const p = [a, b, c, d];
    for (let i = 0; i < 4; i++) {
      this.pos.push(p[i][0], p[i][1], p[i][2]);
      this.nor.push(nx, ny, nz);
      this.uv.push(uvs[i * 2], uvs[i * 2 + 1]);
      this.col.push(col[0], col[1], col[2]);
    }
    const n = this.n;
    this.idx.push(n, n + 1, n + 2, n, n + 2, n + 3);
    this.n += 4;
  }
  tri(a, b, c, uvs, col) {
    const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2];
    const vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
    let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
    const l = Math.hypot(nx, ny, nz) || 1; nx /= l; ny /= l; nz /= l;
    [a, b, c].forEach((p, i) => {
      this.pos.push(p[0], p[1], p[2]); this.nor.push(nx, ny, nz);
      this.uv.push(uvs[i * 2], uvs[i * 2 + 1]); this.col.push(col[0], col[1], col[2]);
    });
    const n = this.n; this.idx.push(n, n + 1, n + 2); this.n += 3;
  }
  geometry() {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(this.pos, 3));
    g.setAttribute('normal', new THREE.Float32BufferAttribute(this.nor, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(this.uv, 2));
    g.setAttribute('color', new THREE.Float32BufferAttribute(this.col, 3));
    g.setIndex(this.n > 65535 ? new THREE.Uint32BufferAttribute(this.idx, 1) : new THREE.Uint16BufferAttribute(this.idx, 1));
    g.computeBoundingSphere(); g.computeBoundingBox();
    return g;
  }
}

class Chunk {
  constructor() { this.m = new Map(); }
  acc(k) { let a = this.m.get(k); if (!a) { a = new Acc(); this.m.set(k, a); } return a; }
}

const WHITE = [1, 1, 1];

/** Caixa com UV métrico. Lados -> accS; topo -> accT (opcional). tw/th: tamanho do tile em metros. */
function addBox(accS, accT, x0, z0, x1, z1, y0, y1, o = {}) {
  const tw = o.tw ?? 16, th = o.th ?? 16, u0 = o.u0 ?? 0, v0 = o.v0 ?? 0, col = o.col ?? WHITE, vb = o.vb ?? y0;
  const V = (y) => (y - vb) / th + v0;
  if (accS) {
    accS.quad([x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1],
      [x0 / tw + u0, V(y0), x1 / tw + u0, V(y0), x1 / tw + u0, V(y1), x0 / tw + u0, V(y1)], col, [0, 0, 1]);
    accS.quad([x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0],
      [-x1 / tw + u0, V(y0), -x0 / tw + u0, V(y0), -x0 / tw + u0, V(y1), -x1 / tw + u0, V(y1)], col, [0, 0, -1]);
    accS.quad([x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1],
      [-z1 / tw + u0, V(y0), -z0 / tw + u0, V(y0), -z0 / tw + u0, V(y1), -z1 / tw + u0, V(y1)], col, [1, 0, 0]);
    accS.quad([x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0],
      [z0 / tw + u0, V(y0), z1 / tw + u0, V(y0), z1 / tw + u0, V(y1), z0 / tw + u0, V(y1)], col, [-1, 0, 0]);
  }
  if (accT) {
    const s = o.ts ?? 4;
    accT.quad([x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0],
      [x0 / s, z1 / s, x1 / s, z1 / s, x1 / s, z0 / s, x0 / s, z0 / s], o.tcol ?? col, [0, 1, 0]);
  }
}

function flatQuad(acc, x0, z0, x1, z1, y, uvf, col = WHITE) {
  acc.quad([x0, y, z1], [x1, y, z1], [x1, y, z0], [x0, y, z0],
    [...uvf(x0, z1), ...uvf(x1, z1), ...uvf(x1, z0), ...uvf(x0, z0)], col, [0, 1, 0]);
}

const FLOORH = { glass: 4, office: 4, modern: 4, brick: 3.2 };
const FLOORS_PER_TILE = { glass: 4, office: 4, modern: 4, brick: 5 };
const BAY = { glass: 2, office: 4, modern: 4, brick: 4 };

export class City {
  constructor(scene, Q, renderer, onProgress = () => {}) {
    this.scene = scene; this.Q = Q; this.renderer = renderer;
    this.rng = mulberry32(20241024);
    this.time = 0;
    this.colliderBoxes = []; this.colliderCircles = [];
    this.grid = new Map();
    this.lamps = []; this.trees = []; this.tlHeads = [];
    this.facadeMats = []; this.wetMats = [];
    this.night = 0;
    this.group = new THREE.Group(); scene.add(this.group);
    this.onProgress = onProgress;
    this.layout();
    this.makeMaterials();
  }

  // -------------------------------------------------------------- layout
  layout() {
    const w = [], c = [];
    for (let i = 0; i <= N; i++) w.push(i % 5 === 2 ? ROAD_AVE : ROAD_STD);
    c[0] = 0;
    for (let i = 1; i <= N; i++) c[i] = c[i - 1] + w[i - 1] / 2 + B + w[i] / 2;
    const mid = c[N] / 2;
    for (let i = 0; i <= N; i++) c[i] -= mid;
    this.rw = w; this.rc = c;
    this.ext = c[N] + w[N] / 2;           // meia-extensão da cidade
    this.bounds = this.ext + 34;
    this.blockMin = (i) => c[i] + w[i] / 2;
    this.blockMax = (i) => c[i + 1] - w[i + 1] / 2;
  }

  roadIndexAt(v) {
    for (let i = 0; i <= N; i++) if (Math.abs(v - this.rc[i]) <= this.rw[i] / 2) return i;
    return -1;
  }
  groundHeight(x, z) {
    const ix = this.roadIndexAt(x), iz = this.roadIndexAt(z);
    if (ix >= 0 && iz >= 0) return 0;
    if (ix >= 0) { return (this.rw[ix] > 20 && Math.abs(x - this.rc[ix]) < 2) ? CURB : 0; }
    if (iz >= 0) { return (this.rw[iz] > 20 && Math.abs(z - this.rc[iz]) < 2) ? CURB : 0; }
    return Math.abs(x) > this.ext || Math.abs(z) > this.ext ? 0 : CURB;
  }

  // -------------------------------------------------------------- materiais
  makeMaterials() {
    const Q = this.Q;
    T.setTexQuality(Q.aniso, Q.texSize);
    const std = (o) => new THREE.MeshStandardMaterial(o);
    const M = (this.mats = {});
    const fac = (tex, extra = {}) => {
      const m = std({ map: tex.map, roughnessMap: tex.orm, metalnessMap: tex.orm, roughness: 1, metalness: 1,
        emissive: 0xffffff, emissiveMap: tex.emissive, emissiveIntensity: 0, vertexColors: true, ...extra });
      this.facadeMats.push(m); return m;
    };
    for (const [k, s] of [['glass', 1], ['office', 2], ['brick', 3], ['modern', 4]]) M[k] = fac(T.makeFacade(k, s));
    M.brick2 = fac(T.makeFacade('brick', 11));
    M.brick3 = fac(T.makeFacade('brick', 23));
    M.shop0 = fac(T.makeShopfront(1)); M.shop1 = fac(T.makeShopfront(2)); M.shop2 = fac(T.makeShopfront(3));
    const concrete = T.makeConcrete();
    M.sidewalk = std({ map: concrete, bumpMap: concrete, bumpScale: 1.2, roughness: 0.92, color: 0xd8d6d0 });
    M.grass = std({ map: T.makeGrass(), roughness: 1, vertexColors: true });
    M.grass.map.repeat.set(1, 1);
    const roof = T.makeRoof();
    M.roof = std({ map: roof, roughness: 0.95 });
    M.tile = std({ map: T.makeRoofTiles(), roughness: 0.85 });
    M.plain = std({ roughness: 0.7, metalness: 0.2, vertexColors: true });
    // ruas
    const bump = T.makeAsphaltBump();
    const mkRoad = (wm, ave) => {
      const { map, rough } = T.makeRoadTexture(wm, ave);
      const b = bump.clone(); b.needsUpdate = true; b.repeat.set(wm / 2, 8);
      const m = std({ map, roughnessMap: rough, roughness: 1, bumpMap: b, bumpScale: 0.9, metalness: 0 });
      this.wetMats.push({ m, dry: 1, wet: 0.32 });
      return m;
    };
    M.roadStd = mkRoad(ROAD_STD, false); M.roadAve = mkRoad(ROAD_AVE, true);
    const at = T.makeAsphaltTile(); const bump2 = bump.clone(); bump2.needsUpdate = true; bump2.repeat.set(4, 4);
    M.inter = std({ map: at, bumpMap: bump2, bumpScale: 0.9, roughness: 0.95 });
    this.wetMats.push({ m: M.inter, dry: 0.95, wet: 0.3 });
    M.cross = std({ map: T.makeCrosswalk(), transparent: true, alphaTest: 0.4, roughness: 0.75, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
    M.paint = std({ color: 0xe6e6de, roughness: 0.75, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
    this.wetMats.push({ m: M.cross, dry: 0.75, wet: 0.35 }, { m: M.paint, dry: 0.75, wet: 0.35 });
    this.wetMats.push({ m: M.sidewalk, dry: 0.92, wet: 0.55 });
    // terreno
    const gt = T.makeGrass(9); gt.repeat.set(900, 900);
    M.ground = std({ map: gt, roughness: 1, color: 0x9aa88a, polygonOffset: true, polygonOffsetFactor: 3, polygonOffsetUnits: 3 });
    this.glowTex = T.makeGlow();
  }

  matFor(key) { return this.mats[key]; }

  // -------------------------------------------------------------- colisores
  addBoxCollider(x0, z0, x1, z1) {
    const id = this.colliderBoxes.length;
    this.colliderBoxes.push([x0, z0, x1, z1]);
    const C = 32;
    for (let cx = Math.floor(x0 / C); cx <= Math.floor(x1 / C); cx++)
      for (let cz = Math.floor(z0 / C); cz <= Math.floor(z1 / C); cz++) this.cell(cx, cz).boxes.push(id);
  }
  addCircleCollider(x, z, r) {
    const id = this.colliderCircles.length;
    this.colliderCircles.push([x, z, r]);
    this.cell(Math.floor(x / 32), Math.floor(z / 32)).circles.push(id);
  }
  cell(cx, cz) {
    const k = cx * 100003 + cz;
    let c = this.grid.get(k);
    if (!c) { c = { boxes: [], circles: [] }; this.grid.set(k, c); }
    return c;
  }
  /** Chama cb para caixas e círculos próximos de (x,z) dentro de radius. */
  queryColliders(x, z, radius, onBox, onCircle) {
    const C = 32;
    const seen = this._seen || (this._seen = new Set()); seen.clear();
    for (let cx = Math.floor((x - radius) / C); cx <= Math.floor((x + radius) / C); cx++)
      for (let cz = Math.floor((z - radius) / C); cz <= Math.floor((z + radius) / C); cz++) {
        const c = this.grid.get(cx * 100003 + cz); if (!c) continue;
        for (const id of c.boxes) { if (seen.has(id)) continue; seen.add(id); onBox(this.colliderBoxes[id]); }
        for (const id of c.circles) { onCircle(this.colliderCircles[id]); }
      }
  }
  pointBlocked(x, z, margin = 0.3) {
    let hit = false;
    this.queryColliders(x, z, margin + 1, (b) => {
      if (x > b[0] - margin && x < b[2] + margin && z > b[1] - margin && z < b[3] + margin) hit = true;
    }, () => {});
    return hit;
  }
  /** Retorna t∈[0,1] mais distante livre ao longo do segmento (a->b). */
  freeAlong(ax, az, bx, bz, margin = 0.5) {
    let lo = 0, hi = 1;
    if (!this.pointBlocked(bx, bz, margin)) return 1;
    for (let i = 0; i < 8; i++) {
      const m = (lo + hi) / 2;
      if (this.pointBlocked(lerp(ax, bx, m), lerp(az, bz, m), margin)) hi = m; else lo = m;
    }
    return lo;
  }

  // -------------------------------------------------------------- semáforos
  lightState(axis, t = this.time) {
    const p = t % 37;
    if (axis === 'z') { if (p < 14) return 'g'; if (p < 16.5) return 'y'; return 'r'; }
    const q = (p + 37 - 18.5) % 37;
    if (q < 14) return 'g'; if (q < 16.5) return 'y'; return 'r';
  }

  // -------------------------------------------------------------- construção
  async build() {
    const rng = this.rng;
    const chunks = new Map();
    const chunkOf = (i, j) => { const k = `${i >> 1}_${j >> 1}`; let c = chunks.get(k); if (!c) { c = new Chunk(); chunks.set(k, c); } return c; };
    const rc = this.rc, rw = this.rw;
    const yield_ = () => new Promise((r) => setTimeout(r, 0));
    const world = new Chunk(); // geometria global: ruas, etc. dividido por chunk

    // ---------- ruas e cruzamentos
    this.onProgress(0.05, 'Asfaltando as ruas…');
    for (let i = 0; i <= N; i++) for (let j = 0; j <= N; j++) {
      const ch = chunkOf(i, j);
      const xc = rc[i], zc = rc[j], wB = rw[i], wA = rw[j];
      // cruzamento
      flatQuad(ch.acc('inter'), xc - wB / 2, zc - wA / 2, xc + wB / 2, zc + wA / 2, 0, (x, z) => [x / 8, z / 8]);
      // segmentos para +x (rua ao longo de x na linha j)
      if (i < N) {
        const xa = xc + wB / 2, xb = rc[i + 1] - rw[i + 1] / 2;
        const key = wA > 20 ? 'roadAve' : 'roadStd';
        flatQuad(ch.acc(key), xa, zc - wA / 2, xb, zc + wA / 2, 0, (x, z) => [(z - (zc - wA / 2)) / wA, x / 16]);
        if (wA > 20) { // canteiro central
          const acc = ch.acc('sidewalk'), grass = ch.acc('grass');
          addBox(acc, null, xa + 5, zc - 2, xb - 5, zc + 2, 0, CURB, { tw: 8, th: 8 });
          flatQuad(grass, xa + 5, zc - 2, xb - 5, zc + 2, CURB + 0.005, (x, z) => [x / 6, z / 6], [0.8, 0.85, 0.75]);
          this.addMedianTrees(xa + 9, xb - 9, zc, 'x', rng);
        }
        this.addSegmentFurniture('x', xa, xb, zc, wA, i, j, rng);
      }
      if (j < N) {
        const za = zc + wA / 2, zb = rc[j + 1] - rw[j + 1] / 2;
        const key = wB > 20 ? 'roadAve' : 'roadStd';
        flatQuad(ch.acc(key), xc - wB / 2, za, xc + wB / 2, zb, 0, (x, z) => [(x - (xc - wB / 2)) / wB, z / 16]);
        if (wB > 20) {
          const acc = ch.acc('sidewalk'), grass = ch.acc('grass');
          addBox(acc, null, xc - 2, za + 5, xc + 2, zb - 5, 0, CURB, { tw: 8, th: 8 });
          flatQuad(grass, xc - 2, za + 5, xc + 2, zb - 5, CURB + 0.005, (x, z) => [x / 6, z / 6], [0.8, 0.85, 0.75]);
          this.addMedianTrees(za + 9, zb - 9, xc, 'z', rng);
        }
        this.addSegmentFurniture('z', za, zb, xc, wB, i, j, rng);
      }
      // faixas de pedestres + linhas de retenção
      const arms = [];
      if (j < N) arms.push([0, -1]); // vem de +z, anda -z
      if (j > 0) arms.push([0, 1]);
      if (i < N) arms.push([-1, 0]);
      if (i > 0) arms.push([1, 0]);
      for (const d of arms) {
        const cw = ch.acc('cross'), pa = ch.acc('paint');
        const y = 0.014;
        if (d[0] === 0) { // aproximando ao longo de z
          const s = -d[1]; // lado onde está o braço (+1 => +z)
          const e = zc + s * wA / 2;
          const z0 = e + s * 0.9, z1 = e + s * 3.7;
          const xa = xc - wB / 2 + 1.2, xb = xc + wB / 2 - 1.2;
          const [za, zb] = z0 < z1 ? [z0, z1] : [z1, z0];
          flatQuad(cw, xa, za, xb, zb, y, (x, z) => [x, (z - za) / (zb - za)]);
          // linha de retenção na metade direita do sentido d
          const zl = e + s * 4.6;
          const right = [-d[1], d[0]]; // direita do sentido
          const xr0 = xc + (right[0] > 0 ? 0.35 : -wB / 2 + 0.5), xr1 = xc + (right[0] > 0 ? wB / 2 - 0.5 : -0.35);
          flatQuad(pa, xr0, zl - 0.2, xr1, zl + 0.2, y, () => [0, 0]);
        } else {
          const s = -d[0];
          const e = xc + s * wB / 2;
          const x0 = e + s * 0.9, x1 = e + s * 3.7;
          const za = zc - wA / 2 + 1.2, zb = zc + wA / 2 - 1.2;
          const [xa, xb] = x0 < x1 ? [x0, x1] : [x1, x0];
          flatQuad(cw, xa, za, xb, zb, y, (x, z) => [z, (x - xa) / (xb - xa)]);
          const xl = e + s * 4.6;
          const right = [-d[1], d[0]];
          const zr0 = zc + (right[1] > 0 ? 0.35 : -wA / 2 + 0.5), zr1 = zc + (right[1] > 0 ? wA / 2 - 0.5 : -0.35);
          flatQuad(pa, xl - 0.2, zr0, xl + 0.2, zr1, y, () => [0, 0]);
        }
      }
      this.addTrafficLights(i, j);
    }
    await yield_();

    // ---------- quarteirões
    this.onProgress(0.2, 'Construindo prédios…');
    let count = 0;
    for (let i = 0; i < N; i++) {
      for (let j = 0; j < N; j++) {
        const ch = chunkOf(i, j);
        const x0 = this.blockMin(i), x1 = this.blockMax(i), z0 = this.blockMin(j), z1 = this.blockMax(j);
        addBox(ch.acc('sidewalk'), null, x0, z0, x1, z1, -0.4, CURB, { tw: 8, th: 8 });
        flatQuad(ch.acc('sidewalk'), x0, z0, x1, z1, CURB, (x, z) => [x / 8, z / 8]);
        this.buildBlock(ch, i, j, x0, z0, x1, z1);
        if (++count % 14 === 0) { this.onProgress(0.2 + 0.45 * count / (N * N), 'Construindo prédios…'); await yield_(); }
      }
    }

    // ---------- meshes finais
    this.onProgress(0.7, 'Montando a geometria…');
    const keyMat = (k) => this.mats[k];
    for (const [id, ch] of chunks) {
      for (const [k, acc] of ch.m) {
        if (!acc.n) continue;
        const mesh = new THREE.Mesh(acc.geometry(), keyMat(k));
        const noShadow = (k === 'inter' || k === 'roadStd' || k === 'roadAve' || k === 'cross' || k === 'paint');
        mesh.castShadow = !noShadow; mesh.receiveShadow = true;
        mesh.matrixAutoUpdate = false; mesh.updateMatrix();
        this.group.add(mesh);
      }
    }
    chunks.clear();
    await yield_();

    // ---------- terreno externo
    const gg = new THREE.PlaneGeometry(9000, 9000); gg.rotateX(-Math.PI / 2);
    const ground = new THREE.Mesh(gg, this.mats.ground); ground.position.y = -0.4; ground.receiveShadow = true;
    this.group.add(ground);
    this.buildOuterRing();
    this.buildInstances();
    this.onProgress(0.9, 'Plantando árvores…');
    await yield_();
    return this;
  }

  // -------------------------------------------------------------- quarteirão
  zoneAt(x, z) { return Math.max(Math.abs(x), Math.abs(z)) / this.ext; }

  buildBlock(ch, i, j, bx0, bz0, bx1, bz1) {
    const rng = this.rng;
    const cx = (bx0 + bx1) / 2, cz = (bz0 + bz1) / 2;
    const dn = this.zoneAt(cx, cz);
    const inner = { x0: bx0 + SW, z0: bz0 + SW, x1: bx1 - SW, z1: bz1 - SW };
    // parque?
    const park = dn > 0.12 && rng() < 0.085;
    if (park || (i === 6 && j === 6 && N === 14)) { this.buildPark(ch, inner, rng); return; }
    const outer = dn > 0.62;
    if (outer) flatQuad(ch.acc('grass'), inner.x0, inner.z0, inner.x1, inner.z1, CURB + 0.004, (x, z) => [x / 6, z / 6], [0.85, 0.9, 0.8]);
    let minS, maxS;
    if (dn < 0.28) { minS = 26; maxS = 46; } else if (dn < 0.62) { minS = 18; maxS = 34; } else { minS = 12; maxS = 22; }
    const lots = [];
    this.splitLots(inner, minS, maxS, rng, lots);
    for (const lot of lots) this.buildLot(ch, lot, dn, rng);
  }

  splitLots(r, minS, maxS, rng, out) {
    const w = r.x1 - r.x0, d = r.z1 - r.z0;
    if ((w <= maxS && d <= maxS) || (w < minS * 2 && d < minS * 2)) { out.push(r); return; }
    if (w >= d && w >= minS * 2) {
      const s = r.x0 + w * (0.4 + rng() * 0.2);
      this.splitLots({ ...r, x1: s }, minS, maxS, rng, out); this.splitLots({ ...r, x0: s }, minS, maxS, rng, out);
    } else if (d >= minS * 2) {
      const s = r.z0 + d * (0.4 + rng() * 0.2);
      this.splitLots({ ...r, z1: s }, minS, maxS, rng, out); this.splitLots({ ...r, z0: s }, minS, maxS, rng, out);
    } else out.push(r);
  }

  buildPark(ch, r, rng) {
    flatQuad(ch.acc('grass'), r.x0 - SW + 0.2, r.z0 - SW + 0.2, r.x1 + SW - 0.2, r.z1 + SW - 0.2, CURB + 0.004, (x, z) => [x / 6, z / 6], [0.95, 1, 0.9]);
    const sw = ch.acc('sidewalk');
    const cx = (r.x0 + r.x1) / 2, cz = (r.z0 + r.z1) / 2;
    flatQuad(sw, cx - 2, r.z0 - SW, cx + 2, r.z1 + SW, CURB + 0.012, (x, z) => [x / 8, z / 8]);
    flatQuad(sw, r.x0 - SW, cz - 2, r.x1 + SW, cz + 2, CURB + 0.012, (x, z) => [x / 8, z / 8]);
    const n = Math.floor(48 * this.Q.trees);
    for (let k = 0; k < n; k++) {
      const x = lerp(r.x0 - 2, r.x1 + 2, rng()), z = lerp(r.z0 - 2, r.z1 + 2, rng());
      if (Math.abs(x - cx) < 3.5 || Math.abs(z - cz) < 3.5) continue;
      this.addTree(x, z, 0.9 + rng() * 0.7, rng() * 6.28);
    }
  }

  buildLot(ch, lot, dn, rng) {
    const m = 0.7 + rng() * 1.0;
    const x0 = lot.x0 + m, z0 = lot.z0 + m, x1 = lot.x1 - m, z1 = lot.z1 - m;
    const w = x1 - x0, d = z1 - z0;
    if (w < 6 || d < 6) return;
    this.addBoxCollider(x0, z0, x1, z1);
    const roofAcc = ch.acc('roof'), plain = ch.acc('plain');
    // tipo
    let kind, floors, house = false;
    const r = rng();
    if (dn < 0.28) {
      kind = r < 0.62 ? 'glass' : r < 0.82 ? 'office' : 'modern';
      floors = 14 + Math.floor(rng() * rng() * 38);
      if (rng() < 0.18) floors = 5 + Math.floor(rng() * 8);
    } else if (dn < 0.62) {
      kind = r < 0.3 ? 'brick' : r < 0.55 ? 'modern' : r < 0.8 ? 'office' : 'glass';
      floors = 5 + Math.floor(rng() * rng() * 16);
    } else {
      kind = r < 0.5 ? 'brick' : r < 0.85 ? 'modern' : 'office';
      floors = 2 + Math.floor(rng() * 5);
      if (w < 20 && d < 24 && rng() < 0.45) house = true;
    }
    const brickKey = kind === 'brick' ? ['brick', 'brick2', 'brick3'][Math.floor(rng() * 3)] : kind;
    const fh = FLOORH[kind];
    const shopKey = 'shop' + Math.floor(rng() * 3);
    const tintFor = () => {
      if (kind === 'glass') return pickT(rng, [[0.85, 0.98, 1.1], [0.8, 1.0, 0.95], [1.0, 0.9, 0.72], [0.9, 0.92, 1.0], [0.7, 0.8, 0.95]]);
      if (kind === 'brick') return pickT(rng, [[1, 1, 1], [1.1, 0.95, 0.85], [0.9, 0.95, 1.05], [1.05, 1.05, 1.0]]);
      const g = 0.88 + rng() * 0.2; return [g, g, g * (0.96 + rng() * 0.08)];
    };
    const tint = tintFor();
    const upOffs = () => ({ u0: Math.floor(rng() * 16 / BAY[kind]) * (BAY[kind] / 16), v0: Math.floor(rng() * FLOORS_PER_TILE[kind]) / FLOORS_PER_TILE[kind] });

    if (house) {
      const wallKey = rng() < 0.5 ? 'brick' : 'modern';
      const hf = rng() < 0.5 ? 1 : 2;
      const hh = hf * (wallKey === 'brick' ? 3.2 : 4);
      const hx0 = x0 + 1, hx1 = x1 - 1, hz0 = z0 + 1, hz1 = z1 - 1;
      const col = rng() < 0.5 ? [1, 1, 1] : [1.1, 1.05, 0.95];
      addBox(ch.acc(wallKey), null, hx0, hz0, hx1, hz1, CURB, CURB + hh, { col, ...upOffs(), vb: CURB });
      this.addGable(ch.acc('tile'), plain, hx0 - 0.4, hz0 - 0.4, hx1 + 0.4, hz1 + 0.4, CURB + hh, 2.2 + rng() * 1.2, hx1 - hx0 > hz1 - hz0);
      // muro baixo
      return;
    }

    const shopH = 4.5;
    const yShop = CURB + shopH;
    const hasShop = floors >= 3;
    const base = CURB;
    if (hasShop) addBox(ch.acc(shopKey), null, x0, z0, x1, z1, base, yShop, { tw: 16, th: shopH, u0: rng(), v0: 0, col: [1, 1, 1], vb: base });
    const yStart = hasShop ? yShop : base;
    const nUp = hasShop ? floors - 1 : floors;
    const totalH = nUp * fh;

    // podium + torre (downtown)
    if (dn < 0.28 && floors > 18 && w > 28 && d > 28) {
      const podF = 2 + Math.floor(rng() * 4);
      const yPod = yStart + podF * fh;
      addBox(ch.acc(brickKey), roofAcc, x0, z0, x1, z1, yStart, yPod, { col: tint, tw: 16, th: 16, ts: 4, ...upOffs(), vb: yStart, tcol: [1, 1, 1] });
      const ix = Math.min(w * 0.18, 4 + rng() * 5), iz = Math.min(d * 0.18, 4 + rng() * 5);
      const tx0 = x0 + ix, tx1 = x1 - ix, tz0 = z0 + iz, tz1 = z1 - iz;
      const yTop = yPod + (nUp - podF) * fh;
      addBox(ch.acc(brickKey), roofAcc, tx0, tz0, tx1, tz1, yPod, yTop, { col: tint, ...upOffs(), vb: yPod, tcol: [1, 1, 1] });
      this.roofGear(plain, tx0, tz0, tx1, tz1, yTop, rng, floors > 30);
      this.roofGear(plain, x0, z0, x1, z1, yPod, rng, false, 0.3);
    } else {
      const yTop = yStart + totalH;
      addBox(ch.acc(brickKey), roofAcc, x0, z0, x1, z1, yStart, yTop, { col: tint, ...upOffs(), vb: yStart, tcol: [1, 1, 1] });
      // coroamento recuado em prédios médios
      let yRoof = yTop;
      if (floors > 8 && rng() < 0.4 && w > 16 && d > 16) {
        const i2 = 3 + rng() * 3;
        const yT2 = yTop + fh * (1 + Math.floor(rng() * 2));
        addBox(ch.acc(brickKey), roofAcc, x0 + i2, z0 + i2, x1 - i2, z1 - i2, yTop, yT2, { col: tint, ...upOffs(), vb: yTop, tcol: [1, 1, 1] });
        yRoof = yT2;
        this.roofGear(plain, x0 + i2, z0 + i2, x1 - i2, z1 - i2, yRoof, rng, false);
      } else this.roofGear(plain, x0, z0, x1, z1, yRoof, rng, floors > 20);
    }
    // árvore ou poste no recuo (raro)
  }

  roofGear(acc, x0, z0, x1, z1, y, rng, antenna, density = 1) {
    const w = x1 - x0, d = z1 - z0;
    const n = Math.floor((1 + rng() * 4) * density * Math.min(1.5, w * d / 600 + 0.6));
    for (let k = 0; k < n; k++) {
      const sx = 1.2 + rng() * 3.5, sz = 1.2 + rng() * 3.5, sh = 0.8 + rng() * 2.2;
      const px = lerp(x0 + 1, x1 - 1 - sx, rng()), pz = lerp(z0 + 1, z1 - 1 - sz, rng());
      if (px + sx > x1 || pz + sz > z1) continue;
      const g = 0.35 + rng() * 0.3;
      addBox(acc, acc, px, pz, px + sx, pz + sz, y, y + sh, { col: [g, g, g * 1.04], tw: 8, th: 8, ts: 8 });
    }
    // casa de máquinas
    if (rng() < 0.5 && w > 10 && d > 10) {
      const sx = Math.min(w * 0.3, 7), sz = Math.min(d * 0.3, 7), sh = 3 + rng() * 2;
      const px = lerp(x0 + 1, x1 - 1 - sx, rng()), pz = lerp(z0 + 1, z1 - 1 - sz, rng());
      addBox(acc, acc, px, pz, px + sx, pz + sz, y, y + sh, { col: [0.62, 0.62, 0.6], tw: 8, th: 8, ts: 8 });
    }
    if (antenna) {
      const px = (x0 + x1) / 2 + (rng() - 0.5) * (w * 0.4), pz = (z0 + z1) / 2 + (rng() - 0.5) * (d * 0.4);
      const h = 12 + rng() * 26;
      addBox(acc, acc, px - 0.25, pz - 0.25, px + 0.25, pz + 0.25, y, y + h, { col: [0.7, 0.7, 0.72], tw: 4, th: 4, ts: 4 });
      addBox(acc, acc, px - 0.4, pz - 0.4, px + 0.4, pz + 0.4, y + h, y + h + 0.8, { col: [1, 0.05, 0.05], tw: 4, th: 4, ts: 4 });
    }
  }

  addGable(accTile, accPlain, x0, z0, x1, z1, y, h, ridgeAlongX) {
    const col = [1, 1, 1], s = 4;
    const gc = [0.92, 0.9, 0.84];
    if (ridgeAlongX) {
      const zm = (z0 + z1) / 2;
      accTile.quad([x0, y, z1], [x1, y, z1], [x1, y + h, zm], [x0, y + h, zm], [x0 / s, z1 / s, x1 / s, z1 / s, x1 / s, zm / s, x0 / s, zm / s], col);
      accTile.quad([x1, y, z0], [x0, y, z0], [x0, y + h, zm], [x1, y + h, zm], [x1 / s, z0 / s, x0 / s, z0 / s, x0 / s, zm / s, x1 / s, zm / s], col);
      accPlain.tri([x1, y, z1], [x1, y, z0], [x1, y + h, zm], [0, 0, 1, 0, 0.5, 1], gc);
      accPlain.tri([x0, y, z0], [x0, y, z1], [x0, y + h, zm], [0, 0, 1, 0, 0.5, 1], gc);
    } else {
      const xm = (x0 + x1) / 2;
      accTile.quad([x1, y, z1], [x1, y, z0], [xm, y + h, z0], [xm, y + h, z1], [x1 / s, z1 / s, x1 / s, z0 / s, xm / s, z0 / s, xm / s, z1 / s], col);
      accTile.quad([x0, y, z0], [x0, y, z1], [xm, y + h, z1], [xm, y + h, z0], [x0 / s, z0 / s, x0 / s, z1 / s, xm / s, z1 / s, xm / s, z0 / s], col);
      accPlain.tri([x0, y, z1], [x1, y, z1], [xm, y + h, z1], [0, 0, 1, 0, 0.5, 1], gc);
      accPlain.tri([x1, y, z0], [x0, y, z0], [xm, y + h, z0], [0, 0, 1, 0, 0.5, 1], gc);
    }
  }

  // -------------------------------------------------------------- mobiliário
  addSegmentFurniture(axis, a, b, c, width, i, j, rng) {
    // axis 'x': rua ao longo de x em z=c ; 'z': ao longo de z em x=c
    const len = b - a;
    const spacing = 30;
    const n = Math.max(1, Math.floor((len - 16) / spacing));
    for (let k = 0; k < n; k++) {
      const t = a + 8 + (len - 16) * ((k + 0.5) / n);
      const side = (k + i + j) % 2 === 0 ? 1 : -1;
      const off = width / 2 + 1.35;
      let x, z, ax, az;
      if (axis === 'x') { x = t; z = c + side * off; ax = 0; az = -side; } else { x = c + side * off; z = t; ax = -side; az = 0; }
      this.lamps.push({ x, z, ax, az });
      this.addCircleCollider(x, z, 0.2);
    }
    // árvores nas calçadas
    const tn = Math.floor(len / 14);
    for (let k = 0; k < tn; k++) {
      for (const side of [-1, 1]) {
        if (rng() < 0.28) continue;
        const t = a + 6 + (len - 12) * ((k + 0.5 + (rng() - 0.5) * 0.4) / tn);
        const off = width / 2 + 2.9;
        const x = axis === 'x' ? t : c + side * off, z = axis === 'x' ? c + side * off : t;
        if (rng() > this.Q.trees) continue;
        // evita postes
        let near = false;
        for (let q = this.lamps.length - 1; q >= Math.max(0, this.lamps.length - n); q--) if (Math.hypot(this.lamps[q].x - x, this.lamps[q].z - z) < 3) near = true;
        if (near) continue;
        this.addTree(x, z, 0.85 + rng() * 0.5, rng() * 6.28);
      }
    }
  }
  addMedianTrees(a, b, c, axis, rng) {
    const step = 11;
    for (let t = a; t < b; t += step * (0.8 + rng() * 0.4)) {
      if (rng() > this.Q.trees + 0.2) continue;
      const x = axis === 'x' ? t : c, z = axis === 'x' ? c : t;
      this.addTree(x, z, 1.0 + rng() * 0.4, rng() * 6.28);
    }
  }
  addTree(x, z, s, rot) {
    this.trees.push({ x, z, s, rot });
    this.addCircleCollider(x, z, 0.32 * s);
  }
  addTrafficLights(i, j) {
    const xc = this.rc[i], zc = this.rc[j], wB = this.rw[i], wA = this.rw[j];
    const arms = [];
    if (j < N) arms.push([0, -1]); if (j > 0) arms.push([0, 1]);
    if (i < N) arms.push([-1, 0]); if (i > 0) arms.push([1, 0]);
    for (const d of arms) {
      const right = [-d[1], d[0]];
      const perpHalf = d[0] === 0 ? wA / 2 : wB / 2;
      const roadHalf = d[0] === 0 ? wB / 2 : wA / 2;
      // poste no canto de aproximação à direita, antes da faixa de pedestres
      const px = xc - d[0] * (perpHalf + 5.8) + right[0] * (roadHalf + 1.0);
      const pz = zc - d[1] * (perpHalf + 5.8) + right[1] * (roadHalf + 1.0);
      this.tlHeads.push({ x: px, z: pz, dx: d[0], dz: d[1], axis: d[0] === 0 ? 'z' : 'x', i, j });
      this.addCircleCollider(px, pz, 0.2);
    }
  }

  // -------------------------------------------------------------- anel externo (floresta e colinas)
  buildOuterRing() {
    const rng = mulberry32(777);
    const e = this.ext;
    const nTrees = Math.floor(1800 * this.Q.trees);
    for (let k = 0; k < nTrees; k++) {
      const a = rng() * 4;
      const t = (rng() * 2 - 1) * (e + 40), dist = e + 6 + Math.pow(rng(), 1.6) * 90;
      let x, z;
      if (a < 1) { x = t; z = -dist; } else if (a < 2) { x = t; z = dist; } else if (a < 3) { x = -dist; z = t; } else { x = dist; z = t; }
      this.trees.push({ x, z, s: 1.1 + rng() * 0.9, rot: rng() * 6.28 });
    }
    // colinas distantes
    const R0 = 1700, segs = 128;
    const pos = [], col = [], idx = [];
    for (let r = 0; r < 4; r++) {
      for (let s = 0; s <= segs; s++) {
        const a = (s / segs) * Math.PI * 2;
        const rad = R0 + r * 220;
        const hgt = (r === 3 ? 0 : 1) * (50 + 90 * (0.5 + 0.5 * Math.sin(a * 5 + 1.3)) * (0.5 + 0.5 * Math.sin(a * 11 + 2.1)) + 30 * Math.sin(a * 23)) * (r === 0 ? 0.9 : 1);
        pos.push(Math.cos(a) * rad, r === 3 ? -2 : Math.max(2, hgt), Math.sin(a) * rad);
        const g = 0.5 - r * 0.06;
        col.push(0.2 * g * 2, 0.32 * g * 2, 0.16 * g * 2);
      }
    }
    for (let r = 0; r < 3; r++) for (let s = 0; s < segs; s++) {
      const a = r * (segs + 1) + s, b = a + 1, c = a + segs + 1, d = c + 1;
      idx.push(a, c, b, b, c, d);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    g.setIndex(idx); g.computeVertexNormals();
    this.hills = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1, side: THREE.DoubleSide }));
    this.hills.frustumCulled = false;
    this.group.add(this.hills);
  }

  // -------------------------------------------------------------- instâncias (postes, árvores, semáforos)
  buildInstances() {
    const rng = mulberry32(99);
    const dummy = new THREE.Object3D();
    const metal = new THREE.MeshStandardMaterial({ color: 0x4b5157, roughness: 0.55, metalness: 0.75 });

    // ---- postes
    const pole = new THREE.CylinderGeometry(0.09, 0.14, 8.6, 8); pole.translate(0, 4.3, 0);
    const arm = new THREE.BoxGeometry(2.6, 0.1, 0.1); arm.translate(1.2, 8.45, 0);
    const poleG = mergeGeometries([pole.toNonIndexed(), arm.toNonIndexed()]);
    const L = this.lamps.length;
    this.lampPoles = new THREE.InstancedMesh(poleG, metal, L);
    this.lampPoles.castShadow = false; this.lampPoles.receiveShadow = false;
    const headG = new THREE.BoxGeometry(1.0, 0.14, 0.38); headG.translate(2.35, 8.38, 0);
    this.lampHeadMat = new THREE.MeshStandardMaterial({ color: 0x777777, roughness: 0.4, metalness: 0.6, emissive: 0xffc27a, emissiveIntensity: 0 });
    this.lampHeads = new THREE.InstancedMesh(headG, this.lampHeadMat, L);
    const glowPos = new Float32Array(L * 3), poolG = new THREE.PlaneGeometry(15, 15); poolG.rotateX(-Math.PI / 2);
    this.lampPools = new THREE.InstancedMesh(poolG, new THREE.MeshBasicMaterial({
      map: this.glowTex, color: 0xffb865, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, fog: false,
    }), L);
    this.lampPools.frustumCulled = false; this.lampPools.renderOrder = 2;
    this.lampHeadPos = [];
    for (let k = 0; k < L; k++) {
      const l = this.lamps[k];
      dummy.position.set(l.x, CURB, l.z); dummy.rotation.set(0, Math.atan2(-l.az, l.ax), 0); dummy.scale.set(1, 1, 1); dummy.updateMatrix();
      this.lampPoles.setMatrixAt(k, dummy.matrix); this.lampHeads.setMatrixAt(k, dummy.matrix);
      const hx = l.x + l.ax * 2.35, hz = l.z + l.az * 2.35, hy = CURB + 8.3;
      glowPos[k * 3] = hx; glowPos[k * 3 + 1] = hy - 0.15; glowPos[k * 3 + 2] = hz;
      this.lampHeadPos.push([hx, hy, hz]);
      dummy.position.set(hx, 0.22, hz); dummy.rotation.set(0, 0, 0); dummy.updateMatrix();
      this.lampPools.setMatrixAt(k, dummy.matrix);
    }
    this.group.add(this.lampPoles, this.lampHeads, this.lampPools);
    // brilho em pontos
    const pg = new THREE.BufferGeometry();
    pg.setAttribute('position', new THREE.BufferAttribute(glowPos, 3));
    this.glowUniforms = { uNight: { value: 0 }, uMap: { value: this.glowTex }, uScale: { value: 1 } };
    this.lampGlow = new THREE.Points(pg, new THREE.ShaderMaterial({
      uniforms: this.glowUniforms, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      vertexShader: `uniform float uNight; uniform float uScale; varying float vA;
        void main(){ vec4 mv = modelViewMatrix*vec4(position,1.0); float d=-mv.z;
          gl_PointSize = clamp(520.0*uScale/max(d,1.0), 3.0, 70.0);
          vA = uNight*(1.0-smoothstep(260.0,520.0,d))*step(0.0,d);
          gl_Position = projectionMatrix*mv; }`,
      fragmentShader: `uniform sampler2D uMap; varying float vA;
        void main(){ vec4 t = texture2D(uMap, gl_PointCoord); gl_FragColor = vec4(vec3(1.0,0.74,0.42)*t.a*vA*1.8, t.a*vA); }`,
    }));
    this.lampGlow.frustumCulled = false; this.lampGlow.renderOrder = 3;
    this.group.add(this.lampGlow);
    // grade de postes (para luzes dinâmicas)
    this.lampGrid = new Map();
    this.lampHeadPos.forEach((p, k) => { const key = Math.floor(p[0] / 40) * 10007 + Math.floor(p[2] / 40); (this.lampGrid.get(key) || this.lampGrid.set(key, []).get(key)).push(k); });

    // ---- árvores
    const treeG = this.makeTreeGeometry(rng);
    const treeMat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.92, metalness: 0 });
    this.treeUniforms = { uTime: { value: 0 } };
    treeMat.onBeforeCompile = (sh) => {
      sh.uniforms.uTime = this.treeUniforms.uTime;
      sh.fragmentShader = 'varying vec3 vLoc;\n' + sh.fragmentShader.replace('#include <color_fragment>', `#include <color_fragment>
        { vec3 q = vLoc*3.2; vec3 f = fract(q)-0.5; vec3 id = floor(q);
          float h = fract(sin(dot(id, vec3(12.9898,78.233,37.719)))*43758.5453);
          float leaf = smoothstep(0.55, 0.15, length(f));
          diffuseColor.rgb *= (0.78 + 0.35*h) * (0.88 + 0.22*leaf); }`);
      sh.vertexShader = 'uniform float uTime; varying vec3 vLoc;\n' + sh.vertexShader.replace('#include <begin_vertex>', `#include <begin_vertex>
        vLoc = position;
        #ifdef USE_INSTANCING
        float sw = max(position.y - 3.2, 0.0) * 0.045;
        transformed.x += sin(uTime*1.4 + instanceMatrix[3].x*0.31 + position.y*0.7) * sw;
        transformed.z += cos(uTime*1.1 + instanceMatrix[3].z*0.27 + position.y*0.6) * sw;
        #endif`);
    };
    const cells = new Map();
    for (const t of this.trees) { const k = Math.floor(t.x / 160) * 1000 + Math.floor(t.z / 160); (cells.get(k) || cells.set(k, []).get(k)).push(t); }
    const col = new THREE.Color();
    this.treeMeshes = [];
    for (const arr of cells.values()) {
      const im = new THREE.InstancedMesh(treeG, treeMat, arr.length);
      arr.forEach((t, k) => {
        const y = Math.abs(t.x) > this.ext || Math.abs(t.z) > this.ext ? -0.4 : CURB;
        dummy.position.set(t.x, y, t.z); dummy.rotation.set(0, t.rot, 0);
        const sy = t.s * (0.9 + rng() * 0.25); dummy.scale.set(t.s, sy, t.s); dummy.updateMatrix();
        im.setMatrixAt(k, dummy.matrix);
        col.setHSL(0.25 + (rng() - 0.5) * 0.05, 0.5 + rng() * 0.15, 0.62 + rng() * 0.3);
        im.setColorAt(k, col);
      });
      im.castShadow = true; im.receiveShadow = true;
      im.computeBoundingSphere();
      this.group.add(im); this.treeMeshes.push(im);
    }

    // ---- semáforos
    const H = this.tlHeads.length;
    const sPole = new THREE.CylinderGeometry(0.07, 0.09, 4.2, 8); sPole.translate(0, 2.1 + CURB, 0);
    const sBox = new THREE.BoxGeometry(0.34, 1.05, 0.28); sBox.translate(0, 4.15 + CURB, 0);
    this.tlPoles = new THREE.InstancedMesh(mergeGeometries([sPole.toNonIndexed(), sBox.toNonIndexed()]), metal, H);
    const lampG = new THREE.CircleGeometry(0.115, 14);
    this.tlLamps = new THREE.InstancedMesh(lampG, new THREE.MeshBasicMaterial({ toneMapped: false }), H * 3);
    this.tlLamps.frustumCulled = false;
    this.tlHeads.forEach((h, k) => {
      // frente do semáforo virada para os carros que chegam (-d)
      const ry = Math.atan2(-h.dx, -h.dz);
      dummy.position.set(h.x, 0, h.z); dummy.rotation.set(0, ry, 0); dummy.scale.set(1, 1, 1); dummy.updateMatrix();
      this.tlPoles.setMatrixAt(k, dummy.matrix);
      for (let q = 0; q < 3; q++) {
        dummy.position.set(h.x, CURB + 4.15 + (1 - q) * 0.33, h.z);
        dummy.translateZ(0.145);
        dummy.updateMatrix();
        this.tlLamps.setMatrixAt(k * 3 + q, dummy.matrix);
        dummy.position.set(h.x, 0, h.z);
      }
    });
    this.tlPoles.castShadow = false;
    this.group.add(this.tlPoles, this.tlLamps);
    this.lastPhase = '';
    this.updateTrafficLights(true);
  }

  makeTreeGeometry(rng) {
    const parts = [];
    const cl = new THREE.Color();
    const trunk = new THREE.CylinderGeometry(0.15, 0.27, 3.6, 7, 3); trunk.translate(0, 1.8, 0);
    const setCol = (g, fn) => {
      const p = g.attributes.position, c = new Float32Array(p.count * 3);
      for (let i = 0; i < p.count; i++) { fn(p.getX(i), p.getY(i), p.getZ(i), cl); c[i * 3] = cl.r; c[i * 3 + 1] = cl.g; c[i * 3 + 2] = cl.b; }
      g.setAttribute('color', new THREE.BufferAttribute(c, 3));
    };
    setCol(trunk, (x, y, z, c) => c.setRGB(0.2 + y * 0.01, 0.13, 0.08));
    parts.push(trunk.toNonIndexed());
    const blobs = [[0, 5.1, 0, 2.5], [1.3, 4.2, 0.4, 1.7], [-1.2, 4.4, -0.6, 1.8], [0.2, 4.3, 1.4, 1.6], [-0.4, 6.1, -0.3, 1.5]];
    blobs.forEach(([bx, by, bz, br], bi) => {
      let g = new THREE.IcosahedronGeometry(1, 1);
      g.deleteAttribute('uv'); g = mergeVertices(g);
      const p = g.attributes.position;
      for (let i = 0; i < p.count; i++) {
        const x = p.getX(i), y = p.getY(i), z = p.getZ(i);
        const n = 1 + 0.22 * Math.sin(x * 5.1 + bi) * Math.cos(z * 4.3 + y * 3.1) + 0.1 * Math.sin(y * 9 + x * 7);
        p.setXYZ(i, bx + x * br * n, by + y * br * 0.82 * n, bz + z * br * n);
      }
      g.computeVertexNormals();
      setCol(g, (x, y, z, c) => {
        const h = (y - 3) / 4;
        const v = 0.55 + 0.5 * Math.sin(x * 3.7 + z * 2.9 + y * 4.1) * 0.35;
        c.setRGB(0.10 + v * 0.1 + h * 0.07, 0.24 + v * 0.17 + h * 0.1, 0.07 + v * 0.05);
      });
      g = g.toNonIndexed(); g.deleteAttribute('uv'); parts.push(g);
    });
    parts.forEach((g) => { if (g.attributes.uv) g.deleteAttribute('uv'); });
    return mergeGeometries(parts);
  }

  // -------------------------------------------------------------- atualização
  updateTrafficLights(force = false) {
    const zs = this.lightState('z'), xs = this.lightState('x');
    const key = zs + xs;
    if (!force && key === this.lastPhase) return;
    this.lastPhase = key;
    const c = new THREE.Color();
    const on = { r: [6, 0.3, 0.3], y: [6, 3.8, 0.2], g: [0.2, 5, 1.4] };
    const off = [0.05, 0.05, 0.05];
    this.tlHeads.forEach((h, k) => {
      const st = h.axis === 'z' ? zs : xs;
      const set = (q, lit, rgb) => { const v = lit ? rgb : off; c.setRGB(v[0], v[1], v[2]); this.tlLamps.setColorAt(k * 3 + q, c); };
      set(0, st === 'r', on.r); set(1, st === 'y', on.y); set(2, st === 'g', on.g);
    });
    if (this.tlLamps.instanceColor) this.tlLamps.instanceColor.needsUpdate = true;
  }

  setNight(n) {
    this.night = n;
    for (const m of this.facadeMats) m.emissiveIntensity = n * 1.7;
    this.lampHeadMat.emissiveIntensity = n * 7;
    this.lampPools.material.opacity = n * 0.5;
    this.glowUniforms.uNight.value = n;
  }
  setWet(w) {
    for (const o of this.wetMats) o.m.roughness = lerp(o.dry, o.wet, w);
    for (const m of this.facadeMats) m.roughness = lerp(1, 0.78, w);
  }

  update(dt, playerPos) {
    this.time += dt;
    this.treeUniforms.uTime.value = this.time;
    this.updateTrafficLights();
  }

  /** Índices dos postes mais próximos de (x,z). */
  nearestLamps(x, z, k, ahead = null) {
    const cx = Math.floor(x / 40), cz = Math.floor(z / 40);
    const cand = [];
    for (let i = -2; i <= 2; i++) for (let j = -2; j <= 2; j++) {
      const arr = this.lampGrid.get((cx + i) * 10007 + (cz + j)); if (!arr) continue;
      for (const id of arr) { const p = this.lampHeadPos[id]; cand.push([id, (p[0] - x) ** 2 + (p[2] - z) ** 2]); }
    }
    cand.sort((a, b) => a[1] - b[1]);
    return cand.slice(0, k).map((c) => c[0]);
  }
}

function pickT(rng, arr) { return arr[Math.floor(rng() * arr.length) % arr.length]; }
