// Presets de qualidade gráfica.
export const QUALITY = {
  baixo: {
    nome: 'Baixo', pixelRatio: 0.75, maxDpr: 1, shadows: false, shadowSize: 1024, shadowRange: 70,
    composer: false, bloom: false, msaa: 0, smaa: false, gtao: false,
    traffic: 10, parked: 20, texSize: 512, aniso: 2, lampLights: 0, envInterval: 0, envSize: 64,
    far: 900, fogMul: 1.5, rain: 1500, trees: 0.5, grade: false,
  },
  medio: {
    nome: 'Médio', pixelRatio: 1, maxDpr: 1.25, shadows: true, shadowSize: 2048, shadowRange: 110,
    composer: true, bloom: true, msaa: 0, smaa: true, gtao: false,
    traffic: 22, parked: 70, texSize: 1024, aniso: 8, lampLights: 3, envInterval: 12, envSize: 128,
    far: 1500, fogMul: 1.0, rain: 4000, trees: 0.8, grade: true,
  },
  alto: {
    nome: 'Alto', pixelRatio: 1, maxDpr: 2, shadows: true, shadowSize: 4096, shadowRange: 140,
    composer: true, bloom: true, msaa: 4, smaa: false, gtao: true,
    traffic: 40, parked: 130, texSize: 1024, aniso: 16, lampLights: 6, envInterval: 6, envSize: 256,
    far: 2200, fogMul: 0.8, rain: 8000, trees: 1.0, grade: true,
  },
};

// Dimensões do mundo
export const WORLD = {
  N: 14,            // blocos por eixo (N+1 ruas por eixo)
  BLOCK: 88,        // lado do quarteirão (m)
  ROAD_STD: 18,
  ROAD_AVE: 28,
  SIDEWALK: 4.5,
  CURB: 0.18,
};
