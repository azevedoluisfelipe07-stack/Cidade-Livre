// Entrada: teclado, mouse (órbita da câmera) e gamepad.
import { clamp, lerp } from './util.js';

export class Input {
  constructor(canvas) {
    this.keys = new Set(); this.pressed = new Set();
    this.throttle = 0; this.brake = 0; this.steer = 0; this.hand = false;
    this.orbitYaw = 0; this.orbitPitch = 0; this.dragging = false; this.lookBack = false;
    this.gp = null; this.gpPrev = [];
    this.pad = { throttle: 0, brake: 0, steer: 0, hand: false, active: false };
    addEventListener('keydown', (e) => {
      if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Tab'].includes(e.code)) e.preventDefault();
      if (!this.keys.has(e.code)) this.pressed.add(e.code);
      this.keys.add(e.code);
    });
    addEventListener('keyup', (e) => this.keys.delete(e.code));
    addEventListener('blur', () => this.keys.clear());
    canvas.addEventListener('mousedown', (e) => { this.dragging = true; this.lx = e.clientX; this.ly = e.clientY; });
    addEventListener('mouseup', () => { this.dragging = false; });
    addEventListener('mousemove', (e) => {
      if (!this.dragging) return;
      this.orbitYaw -= (e.clientX - this.lx) * 0.006; this.orbitPitch = clamp(this.orbitPitch + (e.clientY - this.ly) * 0.004, -0.35, 0.9);
      this.lx = e.clientX; this.ly = e.clientY;
    });
  }
  wasPressed(code) { return this.pressed.has(code); }
  readPad() {
    const pads = navigator.getGamepads ? navigator.getGamepads() : [];
    let gp = null; for (const p of pads) if (p && p.connected) { gp = p; break; }
    const P = this.pad; P.active = !!gp;
    if (!gp) return;
    const dz = (v) => (Math.abs(v) < 0.12 ? 0 : Math.sign(v) * (Math.abs(v) - 0.12) / 0.88);
    const sx = dz(gp.axes[0] || 0);
    P.steer = -Math.sign(sx) * Math.pow(Math.abs(sx), 1.35);
    const btn = (i) => (gp.buttons[i] ? gp.buttons[i].value : 0);
    P.throttle = btn(7); P.brake = btn(6); P.hand = btn(0) > 0.5;
    const edge = (i, code) => { const d = btn(i) > 0.5; if (d && !this.gpPrev[i]) this.pressed.add(code); this.gpPrev[i] = d; };
    edge(3, 'KeyC'); edge(1, 'KeyR'); edge(2, 'KeyH'); edge(4, 'KeyF'); edge(5, 'KeyT'); edge(12, 'KeyY'); edge(9, 'Escape'); edge(13, 'KeyM');
    const rx = dz(gp.axes[2] || 0), ry = dz(gp.axes[3] || 0);
    if (rx || ry) { this.orbitYaw -= rx * 0.04; this.orbitPitch = clamp(this.orbitPitch + ry * 0.03, -0.35, 0.9); this.padLook = true; } else this.padLook = false;
  }
  update(dt, speed) {
    this.readPad();
    const k = this.keys;
    const up = k.has('KeyW') || k.has('ArrowUp'), down = k.has('KeyS') || k.has('ArrowDown');
    const left = k.has('KeyA') || k.has('ArrowLeft'), right = k.has('KeyD') || k.has('ArrowRight');
    // pedais digitais com rampa
    this.throttle = lerp(this.throttle, up ? 1 : 0, 1 - Math.exp(-dt * (up ? 7 : 12)));
    this.brake = lerp(this.brake, down ? 1 : 0, 1 - Math.exp(-dt * (down ? 9 : 14)));
    // direção digital com rampa (mais lenta em alta velocidade)
    const target = (left ? 1 : 0) - (right ? 1 : 0);
    const rate = target === 0 ? 5.5 : lerp(4.2, 2.4, clamp(speed / 40, 0, 1));
    this.steer += clamp(target - this.steer, -rate * dt, rate * dt);
    this.hand = k.has('Space');
    this.lookBack = k.has('KeyB');
    const P = this.pad;
    let out = { throttle: this.throttle, brake: this.brake, steer: this.steer, hand: this.hand };
    if (P.active && (P.throttle > 0.02 || P.brake > 0.02 || Math.abs(P.steer) > 0.02 || P.hand)) {
      out = { throttle: Math.max(this.throttle, P.throttle), brake: Math.max(this.brake, P.brake), steer: Math.abs(P.steer) > 0.02 ? P.steer : this.steer, hand: this.hand || P.hand };
    }
    // retorno da órbita da câmera
    if (!this.dragging && !this.padLook) { this.orbitYaw *= Math.exp(-dt * 2.2); this.orbitPitch *= Math.exp(-dt * 2.2); }
    return out;
  }
  endFrame() { this.pressed.clear(); }
}
