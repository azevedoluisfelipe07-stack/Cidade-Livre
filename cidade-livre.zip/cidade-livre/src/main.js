// Cidade Livre — ponto de entrada: menu, laço principal, integração de todos os sistemas.
import * as THREE from 'three';
import { QUALITY, WORLD } from './config.js';
import { City } from './city.js';
import { Atmosphere } from './sky.js';
import { Post } from './post.js';
import { createCar, makeSpec } from './car.js';
import { Vehicle, obbOf, boxObb, collideObb, collideCircle } from './physics.js';
import { CameraRig } from './camera.js';
import { Input } from './input.js';
import { GameAudio } from './audio.js';
import { Traffic, laneOffsets } from './traffic.js';
import { clamp, lerp } from './util.js';

const $ = (id) => document.getElementById(id);
const params = new URLSearchParams(location.search);
const COLORS = [0xb3141b, 0x1c3f7a, 0xe8e8ea, 0x14151a, 0x8d9299, 0xd49a1e, 0x2e5a3c, 0x6a2c91];
const WEATHER = ['Céu limpo', 'Nublado', 'Chuva'];
let settings = { q: 'medio', t: 17.4, w: 0, cy: 1, color: 0 };
try { Object.assign(settings, JSON.parse(sessionStorage.getItem('cl-settings') || '{}')); } catch (e) { /* ignore */ }
for (const k of ['q', 't', 'w', 'cy', 'color']) if (params.has(k)) settings[k] = isNaN(+params.get(k)) ? params.get(k) : +params.get(k);

// ------------------------------------------------------------------ menu
const colorsEl = $('colors');
COLORS.forEach((c, i) => {
  const el = document.createElement('i');
  el.style.background = '#' + c.toString(16).padStart(6, '0');
  el.onclick = () => { settings.color = i; refreshColors(); if (G) G.car.setColor(COLORS[i]); };
  colorsEl.appendChild(el);
});
function refreshColors() { [...colorsEl.children].forEach((e, i) => e.classList.toggle('sel', i === settings.color)); }
refreshColors();
$('q').value = settings.q; $('t').value = String(settings.t); $('w').value = String(settings.w); $('cy').value = String(settings.cy);
$('t').onchange = () => { settings.t = +$('t').value; if (G) G.atm.setTime(settings.t); };
$('w').onchange = () => { settings.w = +$('w').value; if (G) G.atm.setWeather(settings.w); };
$('cy').onchange = () => { settings.cy = +$('cy').value; };
$('q').onchange = () => { settings.q = $('q').value; if (G) { sessionStorage.setItem('cl-settings', JSON.stringify({ ...settings, auto: 1 })); location.search = ''; } };

let G = null; // estado do jogo
$('start').onclick = () => { if (!G) boot(); else resume(); };
if (params.get('auto') === '1' || (sessionStorage.getItem('cl-settings') && JSON.parse(sessionStorage.getItem('cl-settings')).auto)) {
  try { const s = JSON.parse(sessionStorage.getItem('cl-settings') || '{}'); delete s.auto; sessionStorage.setItem('cl-settings', JSON.stringify(s)); } catch (e) { /* */ }
  setTimeout(boot, 50);
}

function progress(f, txt) { $('loadfill').style.width = (f * 100) + '%'; $('loadtxt').textContent = txt; }

// ------------------------------------------------------------------ inicialização
async function boot() {
  $('start').disabled = true; $('loadbar').classList.remove('hidden');
  const Q = { ...QUALITY[settings.q] };
  progress(0.02, 'Iniciando o motor gráfico…');
  const canvas = $('c');
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
  const basePR = Math.min(devicePixelRatio, Q.maxDpr) * Math.min(1, Q.pixelRatio);
  renderer.setPixelRatio(basePR);
  renderer.setSize(innerWidth, innerHeight, false);
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1;
  renderer.shadowMap.enabled = Q.shadows;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(60, innerWidth / innerHeight, 0.3, 4000);
  scene.add(camera);

  await new Promise((r) => setTimeout(r, 30));
  const atm = new Atmosphere(scene, renderer, camera, Q);
  atm.setTime(+settings.t); atm.setWeather(+settings.w);
  if (+settings.w === 2) { atm.rain = 1; atm.wet = 1; atm.cloud = 0.88; }
  else if (+settings.w === 1) atm.cloud = 0.62;

  const city = new City(scene, Q, renderer, progress);
  await city.build();
  progress(0.92, 'Preparando o carro…');
  await new Promise((r) => setTimeout(r, 10));

  const carObj = createCar('coupe', COLORS[settings.color], { lod: 'hi', interior: true });
  scene.add(carObj.group);
  const veh = new Vehicle(carObj.spec);
  // posição inicial: avenida central
  const ai = 7;
  veh.place(city.rc[ai] - 7.3, (city.rc[6] + city.rc[7]) / 2, 0);
  veh.y = 0;

  // faróis do jogador
  const heads = [];
  if (Q.lampLights >= 0) for (const sx of [-1, 1]) {
    const sp = new THREE.SpotLight(0xfff0d8, 0, 90, 0.5, 0.55, 1.4);
    sp.position.set(sx * 0.62, 0.72, carObj.spec.zf - 0.2);
    const tg = new THREE.Object3D(); tg.position.set(sx * 0.5, 0.2, carObj.spec.zf + 30);
    carObj.body.add(sp, tg); sp.target = tg; heads.push(sp);
  }
  // luzes de postes
  const lamps = [];
  for (let i = 0; i < Q.lampLights; i++) {
    const l = new THREE.SpotLight(0xffc680, 0, 42, 1.25, 0.9, 2);
    scene.add(l, l.target); lamps.push(l);
  }

  const post = new Post(renderer, scene, camera, Q);
  const input = new Input(canvas);
  const rig = new CameraRig(camera, city);
  const audio = new GameAudio();
  const traffic = new Traffic(scene, city, Q);
  progress(0.97, 'Chamando o tráfego…');
  traffic.start({ x: veh.x, z: veh.z });
  traffic.updateParked({ x: veh.x, z: veh.z });

  G = { renderer, scene, camera, atm, city, car: carObj, veh, post, input, rig, audio, traffic, Q, heads, lamps, t: 0, hour: +settings.t,
    lightsOn: false, lightsAuto: true, paused: false, minimap: false, wasNight: 0, impactSound: 0, lampTimer: 0, hudTimer: 0, force: null, gaugeT: 0,
    weather: +settings.w, boundsToast: 0, started: false, basePR, scale: 1, ema: 0.016, adaptT: 0 };
  window.__G = G;
  G.step = (n, dt = 1 / 30) => { for (let i = 0; i < n; i++) simulate(dt, true); };
  G.settle = (n = 90) => { for (let i = 0; i < n; i++) { updateVisuals(1 / 30, {}); } };
  G.renderOnce = (dt = 1 / 30) => { simulate(dt); G.post.render(dt, G.t, 0, G.atm.night, G.atm.over); return canvas.toDataURL('image/png'); };

  addEventListener('resize', onResize); onResize();
  audio.start(); audio.setMuted(false);
  progress(1, 'Pronto!');
  $('menu').classList.add('hide'); $('hud').classList.remove('hidden');
  $('start').textContent = 'CONTINUAR'; $('start').disabled = false; $('loadbar').classList.add('hidden');
  G.started = true;
  toast('Bem-vindo! Dirija com W A S D ou setas');
  setTimeout(() => $('hints').classList.add('off'), 14000);
  buildMinimap();
  last = performance.now();
  requestAnimationFrame(frame);
}

function onResize() {
  if (!G) return;
  G.renderer.setSize(innerWidth, innerHeight, false);
  G.camera.aspect = innerWidth / innerHeight; G.camera.updateProjectionMatrix();
  G.post.setSize(innerWidth, innerHeight);
  G.city.glowUniforms.uScale.value = innerHeight / 1000;
}

function resume() { G.paused = false; $('menu').classList.add('hide'); $('hud').classList.remove('hidden'); G.audio.start(); }
function pause() { G.paused = true; $('menu').classList.remove('hide'); $('hud').classList.add('hidden'); }

let toastT = 0;
function toast(txt, ms = 2200) {
  const el = $('toast'); el.textContent = txt; el.classList.add('on');
  clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove('on'), ms);
}

// ------------------------------------------------------------------ minimapa
let mapBg = null;
function buildMinimap() {
  const { city } = G;
  const S = 600, k = S / (city.ext * 2.2);
  mapBg = document.createElement('canvas'); mapBg.width = mapBg.height = S;
  const x = mapBg.getContext('2d');
  x.fillStyle = '#12161c'; x.fillRect(0, 0, S, S);
  x.translate(S / 2, S / 2);
  for (let i = 0; i <= WORLD.N; i++) {
    const w = city.rw[i] * k, c = city.rc[i] * k, e = city.ext * k;
    x.fillStyle = city.rw[i] > 20 ? '#8b95a3' : '#5c6572';
    x.fillRect(c - w / 2, -e, w, e * 2); x.fillRect(-e, c - w / 2, e * 2, w);
  }
  mapBg.k = k;
}
function drawMinimap() {
  const cv = $('minimap'), x = cv.getContext('2d'), { veh, city } = G;
  const k = mapBg.k, view = 200 / 400; // 400 m de largura visível
  x.clearRect(0, 0, 200, 200);
  x.save(); x.beginPath(); x.arc(100, 100, 100, 0, 7); x.clip();
  x.fillStyle = '#12161c'; x.fillRect(0, 0, 200, 200);
  x.translate(100, 100);
  const sc = view / k;
  x.save(); x.rotate(veh.yaw - Math.PI); // frente do carro para cima
  x.scale(sc, sc);
  x.drawImage(mapBg, -veh.x * k - 300, -veh.z * k - 300);
  x.restore();
  // jogador
  x.fillStyle = '#ffb04a'; x.beginPath(); x.moveTo(0, -9); x.lineTo(6, 7); x.lineTo(0, 3); x.lineTo(-6, 7); x.closePath(); x.fill();
  x.restore();
}

// ------------------------------------------------------------------ simulação
function simulate(dt, headless = false) {
  const g = G, { veh, city, input, atm, traffic, car, rig } = g;
  g.t += dt;
  const inp = g.force || input.update(dt, veh.speed);
  if (g.force) input.update(dt, veh.speed);
  veh.step(dt, inp);

  // colisões do jogador
  let impact = 0;
  const cx = veh.x + Math.sin(veh.yaw) * veh.cOff, cz = veh.z + Math.cos(veh.yaw) * veh.cOff;
  for (let pass = 0; pass < 2; pass++) {
    city.queryColliders(cx, cz, 6, (b) => { impact = Math.max(impact, collideObb(veh, obbOf(veh), null, boxObb(b), 0.18)); },
      (c) => { impact = Math.max(impact, collideCircle(veh, obbOf(veh), c[0], c[1], c[2], 0.18)); });
    for (const o of traffic.parked.obbs) {
      if ((o.x - cx) ** 2 + (o.z - cz) ** 2 < 49) impact = Math.max(impact, collideObb(veh, obbOf(veh), null, o, 0.2));
    }
  }
  // limites do mundo
  const bd = city.bounds;
  if (Math.abs(veh.x) > bd) { veh.x = Math.sign(veh.x) * bd; veh.vx *= -0.3; if (g.t - g.boundsToast > 4) { toast('Limite da cidade'); g.boundsToast = g.t; } }
  if (Math.abs(veh.z) > bd) { veh.z = Math.sign(veh.z) * bd; veh.vz *= -0.3; if (g.t - g.boundsToast > 4) { toast('Limite da cidade'); g.boundsToast = g.t; } }
  // tráfego (colide com o jogador)
  impact = Math.max(impact, traffic.update(dt, veh, veh, atm.night, g.audio));
  veh.impact = impact;
  if (impact > 1.2) { rig.kick(clamp(impact / 12, 0.1, 1)); if (!headless && g.t - g.impactSound > 0.12) { g.audio.crash(impact); g.impactSound = g.t; } }

  // altura sob as rodas
  const fx = Math.sin(veh.yaw), fz = Math.cos(veh.yaw), lx = fz, lz = -fx;
  const hs = car.spec;
  let hy = 0;
  for (const [a, b] of [[hs.wzF, 0.7], [hs.wzF, -0.7], [hs.wzR, 0.7], [hs.wzR, -0.7]]) {
    const px = cx + fx * a + lx * b, pz = cz + fz * a + lz * b; hy += city.groundHeight(px, pz);
  }
  hy /= 4;
  veh.yV += ((hy - veh.y) * 380 - veh.yV * 30) * dt; veh.y += veh.yV * dt;
  if (veh.y < -0.05) { veh.y = -0.05; veh.yV = 0; }

  // atmosfera e cidade
  g.hour += dt * [0, 1 / 60, 1 / 15][settings.cy];
  if (settings.cy > 0) atm.setTime(g.hour);
  atm.update(dt, { x: cx, z: cz });
  city.setNight(atm.night); city.setWet(atm.wet);
  city.update(dt);
  traffic.updateParked({ x: cx, z: cz });

  // faróis automáticos
  if (g.lightsAuto) g.lightsOn = atm.night > 0.35 || (atm.over > 0.8 && atm.dayF < 0.6);
  g.lampTimer += dt;
  if (g.lampTimer > 0.2 && g.lamps.length) {
    g.lampTimer = 0;
    const idx = city.nearestLamps(cx, cz, g.lamps.length);
    g.lamps.forEach((l, i) => {
      const p = city.lampHeadPos[idx[i]]; if (!p) { l.intensity = 0; return; }
      l.position.set(p[0], p[1] - 0.3, p[2]); l.target.position.set(p[0], 0, p[2]); l.target.updateMatrixWorld();
      l.intensity = atm.night * 70;
    });
  }
  if (!headless) updateVisuals(dt, inp);
}

function updateVisuals(dt, inp) {
  const { veh, car, atm, input, rig, audio, city } = G;
  const cx = veh.x + Math.sin(veh.yaw) * veh.cOff, cz = veh.z + Math.cos(veh.yaw) * veh.cOff;
  car.group.position.set(cx, veh.y, cz); car.group.rotation.y = veh.yaw;
  car.body.rotation.x = veh.pitch; car.body.rotation.z = veh.roll;
  for (const w of car.wheels) {
    if (w.front) w.pivot.rotation.y = veh.wheelAngle;
    w.spin.rotation.x += (veh.fwdSpeed * dt) / car.spec.wR;
  }
  const U = car.mats.paint.userData.U;
  U.uLights.value = G.lightsOn ? 1 : 0;
  U.uBrake.value = veh.brakeOn ? 1 : 0;
  U.uCockpit.value = rig.mode;
  const cockpit = rig.mode === 1;
  if (car.interior) {
    car.interior.group.visible = cockpit;
    car.interior.wheel.rotation.z = -veh.wheelAngle * 5;
    G.gaugeT += dt;
    if (cockpit && G.gaugeT > 0.06) { G.gaugeT = 0; car.interior.drawGauge(veh.speed * 3.6, veh.rpm, veh.gear === 0 ? 'R' : String(veh.gear)); }
  }
  for (const h of G.heads) h.intensity = G.lightsOn ? 900 : 0;
  rig.update(dt, veh, car, input, G.t);
  audio.update(dt, { rpm: veh.rpm, throttle: veh.throttleApplied, skid: veh.skid, speed: veh.speed, rain: atm.rain, cockpit, horn: input.keys.has('KeyH') });
  // HUD
  G.hudTimer += dt;
  if (G.hudTimer > 0.08) {
    G.hudTimer = 0;
    $('spd').textContent = Math.round(veh.speed * 3.6);
    $('gear').textContent = veh.reversing && veh.fwdSpeed < 0.5 ? 'R' : (Math.abs(veh.fwdSpeed) < 0.3 && veh.throttleApplied < 0.05 ? 'N' : String(Math.max(1, veh.gear)));
    $('rpmfill').style.width = clamp((veh.rpm - 900) / 6300, 0, 1) * 100 + '%';
    if (G.minimap) drawMinimap();
  }
  // sombras seguem o jogador / glow
}

// ------------------------------------------------------------------ laço principal
let last = 0;
function frame(now) {
  requestAnimationFrame(frame);
  const g = G; if (!g || g.hold) return;
  const raw = (now - last) / 1000;
  let dt = Math.min(0.05, raw); last = now;
  if (dt <= 0) return;
  // resolução dinâmica: mantém a fluidez em computadores mais fracos
  if (!g.paused && raw < 0.5) {
    g.ema += (raw - g.ema) * 0.05; g.adaptT += raw;
    if (g.adaptT > 3) {
      g.adaptT = 0;
      let ns = g.scale;
      if (g.ema > 0.026 && g.scale > 0.55) ns = Math.max(0.55, g.scale - 0.1);
      else if (g.ema < 0.0135 && g.scale < 1) ns = Math.min(1, g.scale + 0.05);
      if (ns !== g.scale) { g.scale = ns; g.renderer.setPixelRatio(g.basePR * ns); onResize(); }
    }
  }
  const input = g.input;
  // teclas de ação
  if (input.wasPressed('Escape') || input.wasPressed('KeyP')) { if (g.paused) resume(); else pause(); }
  if (!g.paused) {
    if (input.wasPressed('KeyC')) { const m = g.rig.toggle(); toast(m ? 'Câmera interna' : 'Câmera externa'); }
    if (input.wasPressed('KeyF')) { g.lightsAuto = false; g.lightsOn = !g.lightsOn; toast(g.lightsOn ? 'Faróis ligados' : 'Faróis desligados'); }
    if (input.wasPressed('KeyT')) { g.hour = (g.hour + 3) % 24; g.atm.setTime(g.hour); settings.t = g.hour; toast('Horário: ' + fmtHour(g.hour)); }
    if (input.wasPressed('KeyY')) { g.weather = (g.weather + 1) % 3; settings.w = g.weather; g.atm.setWeather(g.weather); toast(WEATHER[g.weather]); }
    if (input.wasPressed('KeyM')) { g.minimap = !g.minimap; $('minimap').classList.toggle('hidden', !g.minimap); if (g.minimap) drawMinimap(); }
    if (input.wasPressed('KeyN')) { g.audio.setMuted(!g.audio.muted); toast(g.audio.muted ? 'Som desligado' : 'Som ligado'); }
    if (input.wasPressed('KeyR')) resetCar();
    simulate(dt);
  }
  input.endFrame();
  const sp01 = clamp((g.veh.speed - 15) / 50, 0, 1);
  g.post.render(dt, g.t, g.rig.mode === 0 ? sp01 : sp01 * 0.5, g.atm.night, g.atm.over);
}

function fmtHour(h) { const hh = Math.floor(h), mm = Math.floor((h - hh) * 60); return String(hh).padStart(2, '0') + ':' + String(mm).padStart(2, '0'); }

function resetCar() {
  const { veh, city } = G;
  const cx = veh.x, cz = veh.z;
  let ix = 0, iz = 0, bx = 1e9, bz = 1e9;
  for (let i = 0; i <= WORLD.N; i++) { const d = Math.abs(city.rc[i] - cx); if (d < bx) { bx = d; ix = i; } const e = Math.abs(city.rc[i] - cz); if (e < bz) { bz = e; iz = i; } }
  const fwx = Math.sin(veh.yaw), fwz = Math.cos(veh.yaw);
  if (bx <= bz) { const off = laneOffsets(city.rw[ix])[0] + (city.rw[ix] > 20 ? 3.5 : 3.5); const s = fwz >= 0 ? 1 : -1; veh.place(city.rc[ix] - s * off, clamp(cz, -city.ext, city.ext), s > 0 ? 0 : Math.PI); }
  else { const off = laneOffsets(city.rw[iz])[0] + 3.5; const s = fwx >= 0 ? 1 : -1; veh.place(clamp(cx, -city.ext, city.ext), city.rc[iz] + s * off, s > 0 ? Math.PI / 2 : -Math.PI / 2); }
  veh.y = 0; veh.pitch = veh.roll = 0;
  G.rig.init = false;
  toast('Carro reposicionado');
}
