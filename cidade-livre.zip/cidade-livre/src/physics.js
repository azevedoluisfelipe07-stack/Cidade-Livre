// Dinâmica veicular semirrealista (modelo bicicleta com pneus tipo Pacejka + motor/câmbio) e colisões 2D.
import { clamp, lerp, smoothstep } from './util.js';

const G = 9.81;
const GEARS = [0, 3.55, 2.3, 1.68, 1.32, 1.06, 0.87];
const FINAL = 3.3, REV = 3.4;

export class Vehicle {
  constructor(spec) {
    this.spec = spec;
    this.m = spec.mass;
    const L = spec.wzF - spec.wzR;
    this.L = L; this.a = L * 0.48; this.b = L * 0.52;
    this.zCg = spec.wzR + this.b;           // posição do CG no eixo z do modelo
    this.cOff = -this.zCg;
    this.Iz = this.m * this.a * this.b * 1.05;
    this.hcg = 0.52; this.R = spec.wR;
    this.hl = spec.L / 2 - 0.02; this.hw = spec.W - 0.0;
    this.invM = 1 / this.m; this.invI = 1 / this.Iz;
    this.x = 0; this.z = 0; this.yaw = 0; this.vx = 0; this.vz = 0; this.omega = 0;
    this.delta = 0; this.rpm = 900; this.gear = 1; this.shiftT = 0; this.reverse = false;
    this.ax = 0; this.ay = 0; this.axS = 0; this.ayS = 0;
    this.pitch = 0; this.pitchV = 0; this.roll = 0; this.rollV = 0;
    this.skid = 0; this.wheelSpin = 0; this.speed = 0; this.fwdSpeed = 0;
    this.brakeOn = false; this.impact = 0; this.y = 0; this.yV = 0; this.hand = 0;
    this.wheelAngle = 0; this.reversing = false; this.throttleApplied = 0;
  }
  place(x, z, yaw) { this.x = x; this.z = z; this.yaw = yaw; this.vx = this.vz = this.omega = 0; this.delta = 0; this.gear = 1; this.rpm = 900; }
  get fwx() { return Math.sin(this.yaw); }
  get fwz() { return Math.cos(this.yaw); }

  torque(rpm) {
    const x = clamp((rpm - 900) / 6300, 0, 1.1);
    return 440 * Math.max(0.15, 0.62 + 1.1 * x - 1.2 * x * x);
  }

  step(dt, inp) {
    const H = 1 / 180;
    let t = dt;
    while (t > 1e-6) { const h = Math.min(H, t); this.sub(h, inp); t -= h; }
    // molas visuais de pitch/roll
    const tp = clamp(-this.axS * 0.0085, -0.07, 0.07), tr = clamp(this.ayS * 0.0075, -0.09, 0.09);
    const k = 120, c = 14;
    this.pitchV += (-k * (this.pitch - tp) - c * this.pitchV) * dt; this.pitch += this.pitchV * dt;
    this.rollV += (-k * (this.roll - tr) - c * this.rollV) * dt; this.roll += this.rollV * dt;
    this.axS = lerp(this.axS, this.ax, 1 - Math.exp(-dt * 8)); this.ayS = lerp(this.ayS, this.ay, 1 - Math.exp(-dt * 8));
    this.wheelAngle = this.delta;
  }

  sub(h, inp) {
    const m = this.m, a = this.a, b = this.b, L = this.L;
    const fx = Math.sin(this.yaw), fz = Math.cos(this.yaw), lx = fz, lz = -fx;
    let u = this.vx * fx + this.vz * fz, v = this.vx * lx + this.vz * lz;
    const sp = Math.hypot(this.vx, this.vz);
    this.speed = sp; this.fwdSpeed = u;

    // ----- direção
    const aMax = 16;
    const dMax = clamp((aMax * L) / (sp * sp + 4) + 0.03, 0.05, 0.56);
    const dT = inp.steer * dMax;
    const rate = 4.5 * h;
    this.delta += clamp(dT - this.delta, -rate, rate);

    // ----- pedais / marcha
    let drive = 0, brake = 0;
    const th = inp.throttle, br = inp.brake;
    if (u > 0.8) { drive = th; brake = br; this.reversing = false; }
    else if (u < -0.8) { drive = -br; brake = th; this.reversing = true; }
    else {
      if (th > 0.05 && br < 0.05) { drive = th; this.reversing = false; }
      else if (br > 0.05 && th < 0.05) { drive = -br * 0.85; this.reversing = true; }
      else if (th > 0.05 && br > 0.05) brake = 1;
    }
    this.brakeOn = brake > 0.05 || (drive < 0 && u > 0.8);
    this.throttleApplied = Math.abs(drive);

    // câmbio automático
    const wheelRpm = (Math.abs(u) / this.R) * 60 / (2 * Math.PI);
    if (drive < 0 || (this.reversing && u < 0.5)) this.gear = 0;
    else if (this.gear === 0) this.gear = 1;
    const ratio = this.gear === 0 ? REV : GEARS[this.gear] * FINAL;
    let rpmWheel = wheelRpm * ratio;
    const launch = this.gear <= 1 && Math.abs(u) < 5 ? 1800 + Math.abs(drive) * 1900 : 0;
    this.rpm = Math.max(950, rpmWheel, launch * (1 - clamp(Math.abs(u) / 5, 0, 1)) + 0);
    this.shiftT = Math.max(0, this.shiftT - h);
    if (this.gear > 0 && this.shiftT <= 0) {
      if (this.rpm > (Math.abs(drive) > 0.8 ? 6600 : 5200) && this.gear < 6) { this.gear++; this.shiftT = 0.22; }
      else if (this.gear > 1 && this.rpm < (Math.abs(drive) > 0.9 ? 3000 : 1900)) { this.gear--; this.shiftT = 0.18; }
    }
    // força motriz
    const ratio2 = this.gear === 0 ? REV : GEARS[this.gear] * FINAL;
    const rpmE = Math.max(this.rpm, 1500);
    let Fdrive = 0;
    if (this.shiftT <= 0 && Math.abs(drive) > 0.001) {
      const lim = 1 - smoothstep(62, 69, Math.abs(u)) ;
      const rpmCut = this.rpm > 7200 ? 0 : 1;
      Fdrive = this.torque(rpmE) * Math.abs(drive) * ratio2 * 0.9 / this.R * lim * rpmCut * (this.gear === 0 ? 0.55 : 1);
      Fdrive *= Math.sign(drive);
    }

    // ----- cargas verticais
    const Fzf = clamp(m * G * (b / L) - m * this.ax * this.hcg / L, m * G * 0.15, m * G * 0.85);
    const Fzr = m * G - Fzf;
    const mu = 1.12;

    // ----- freio / freio de mão
    const sgnU = Math.abs(u) < 0.15 ? 0 : Math.sign(u);
    let Fbf = 0, Fbr = 0;
    if (brake > 0) { Fbf = 0.62 * brake * m * G * 1.05; Fbr = 0.38 * brake * m * G * 1.05; }
    const hand = inp.hand ? 1 : 0; this.hand = lerp(this.hand, hand, 1 - Math.exp(-h * 30));
    if (hand) Fbr += 7200;
    // Fx por eixo (sinal: + para frente)
    let Fxf = -sgnU * Math.min(Fbf, mu * Fzf);
    let Fxr = Fdrive - sgnU * Math.min(Fbr, mu * Fzr * (hand ? 1.0 : 1));
    if (sgnU === 0 && (brake > 0 || hand)) { Fxf = 0; Fxr = 0; this.vx *= 0.9; this.vz *= 0.9; }
    // limites de tração
    const muR = mu * (hand ? 0.55 : 1) * (inp.grip ?? 1);
    const muF = mu * (inp.grip ?? 1);
    let fxr = Fxr / (muR * Fzr), fxf = Fxf / (muF * Fzf);
    this.wheelSpin = Math.max(0, Math.abs(fxr) - 0.95);
    fxr = clamp(fxr, -1, 1); fxf = clamp(fxf, -1, 1);
    Fxr = fxr * muR * Fzr; Fxf = fxf * muF * Fzf;

    // ----- forças laterais (Pacejka simplificado)
    const ua = Math.max(Math.abs(u), 1.4);
    const sgn = u >= 0 ? 1 : -1;
    const alF = Math.atan2(v + a * this.omega, ua) - this.delta * sgn;
    const alR = Math.atan2(v - b * this.omega, ua);
    const B = 10.5, C = 1.6;
    const pac = (al, D) => -D * Math.sin(C * Math.atan(B * al));
    const sfF = Math.sqrt(Math.max(0.04, 1 - fxf * fxf)), sfR = Math.sqrt(Math.max(0.04, 1 - fxr * fxr));
    let Fyf = pac(alF, muF * Fzf * sfF);
    let Fyr = pac(alR, muR * Fzr * sfR);
    // amortecimento lateral em baixa velocidade
    if (Math.abs(u) < 3) { const k = (1 - Math.abs(u) / 3) * 1800; Fyf -= k * (v + a * this.omega); Fyr -= k * (v - b * this.omega); }
    this.skid = clamp(Math.max(Math.abs(alF) - 0.12, Math.abs(alR) - 0.1) * 5 + (hand && Math.abs(u) > 4 ? 0.8 : 0) + this.wheelSpin * 0.8, 0, 1) * (Math.abs(u) > 2 ? 1 : 0);

    // ----- resistências
    const cdA = 0.74;
    const drag = 0.5 * 1.2 * cdA;
    const Frr = 0.013 * m * G;
    let Fdx = -drag * sp * this.vx - (sp > 0.05 ? Frr * this.vx / sp : 0);
    let Fdz = -drag * sp * this.vz - (sp > 0.05 ? Frr * this.vz / sp : 0);

    // ----- soma (frame carro -> mundo)
    const cd = Math.cos(this.delta), sd = Math.sin(this.delta);
    const Fx = Fxr + Fxf * cd - Fyf * sd;
    const Fy = Fyr + Fyf * cd + Fxf * sd;
    const Ax = (Fx * fx + Fy * lx + Fdx) * this.invM;
    const Az = (Fx * fz + Fy * lz + Fdz) * this.invM;
    const torque = a * (Fyf * cd + Fxf * sd) - b * Fyr;
    this.vx += Ax * h; this.vz += Az * h;
    this.omega += (torque / this.Iz) * h;
    this.omega *= 1 - 0.25 * h; // amortecimento de guinada
    // trava em parada total
    if (!drive && !inp.throttle && Math.hypot(this.vx, this.vz) < 0.12 && (brake > 0 || hand)) { this.vx = this.vz = 0; this.omega *= 0.5; }
    this.ax = lerp(this.ax, (Ax * fx + Az * fz), 1 - Math.exp(-h * 12));
    this.ay = lerp(this.ay, (Ax * lx + Az * lz), 1 - Math.exp(-h * 12));
    this.x += this.vx * h; this.z += this.vz * h; this.yaw += this.omega * h;
  }
}

// ------------------------------------------------------------------ colisões OBB
export function obbOf(b) {
  const fx = Math.sin(b.yaw), fz = Math.cos(b.yaw);
  const off = b.cOff || 0;
  return { x: b.x + fx * off, z: b.z + fz * off, fx, fz, lx: fz, lz: -fx, hl: b.hl, hw: b.hw };
}
export function boxObb(c) {
  return { x: (c[0] + c[2]) / 2, z: (c[1] + c[3]) / 2, fx: 0, fz: 1, lx: 1, lz: 0, hl: (c[3] - c[1]) / 2, hw: (c[2] - c[0]) / 2 };
}
const MU_C = 0.3;

/** Colide A (dinâmico) contra B (qualquer). bodyB pode ser null (estático). Retorna intensidade do impacto (m/s) ou 0. */
export function collideObb(bodyA, A, bodyB, B, restitution = 0.2) {
  const axes = [[A.fx, A.fz, 0], [A.lx, A.lz, 0], [B.fx, B.fz, 1], [B.lx, B.lz, 1]];
  let best = 1e9, bn = null, bowner = 0;
  const dx = A.x - B.x, dz = A.z - B.z;
  for (const [nx, nz, own] of axes) {
    const rA = A.hl * Math.abs(A.fx * nx + A.fz * nz) + A.hw * Math.abs(A.lx * nx + A.lz * nz);
    const rB = B.hl * Math.abs(B.fx * nx + B.fz * nz) + B.hw * Math.abs(B.lx * nx + B.lz * nz);
    const d = dx * nx + dz * nz;
    const ov = rA + rB - Math.abs(d);
    if (ov <= 0) return 0;
    if (ov < best) { best = ov; bn = d >= 0 ? [nx, nz] : [-nx, -nz]; bowner = own; }
  }
  const n = bn;
  // ponto de contato
  let px, pz;
  if (bowner === 0) { // face de A atingida por vértice de B
    let bestV = -1e9;
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
      const cx = B.x + B.fx * B.hl * sz + B.lx * B.hw * sx, cz = B.z + B.fz * B.hl * sz + B.lz * B.hw * sx;
      const pr = -(cx * n[0] + cz * n[1]);
      if (pr > bestV) { bestV = pr; px = cx; pz = cz; }
    }
  } else {
    let bestV = 1e9;
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
      const cx = A.x + A.fx * A.hl * sz + A.lx * A.hw * sx, cz = A.z + A.fz * A.hl * sz + A.lz * A.hw * sx;
      const pr = cx * n[0] + cz * n[1];
      if (pr < bestV) { bestV = pr; px = cx; pz = cz; }
    }
  }
  return resolve(bodyA, bodyB, n, best, px, pz, restitution);
}

export function collideCircle(bodyA, A, cx, cz, r, restitution = 0.2) {
  const dx = cx - A.x, dz = cz - A.z;
  const lx_ = clamp(dx * A.fx + dz * A.fz, -A.hl, A.hl), ly_ = clamp(dx * A.lx + dz * A.lz, -A.hw, A.hw);
  const qx = A.x + A.fx * lx_ + A.lx * ly_, qz = A.z + A.fz * lx_ + A.lz * ly_;
  const ex = qx - cx, ez = qz - cz; const d = Math.hypot(ex, ez);
  if (d >= r) return 0;
  let nx, nz;
  if (d < 1e-4) { nx = A.x - cx; nz = A.z - cz; const l = Math.hypot(nx, nz) || 1; nx /= l; nz /= l; }
  else { nx = ex / d; nz = ez / d; }
  return resolve(bodyA, null, [nx, nz], r - d, qx, qz, restitution);
}

function resolve(A, B, n, pen, px, pz, e) {
  const iA = A.invM, iIA = A.invI, iB = B ? B.invM : 0, iIB = B ? B.invI : 0;
  // posição
  const tot = iA + iB;
  const cA = iA / tot, cB = iB / tot;
  A.x += n[0] * pen * cA * 1.0; A.z += n[1] * pen * cA;
  if (B) { B.x -= n[0] * pen * cB; B.z -= n[1] * pen * cB; }
  const rax = px - A.x, raz = pz - A.z;
  const rbx = B ? px - B.x : 0, rbz = B ? pz - B.z : 0;
  const vax = A.vx + A.omega * raz, vaz = A.vz - A.omega * rax;
  const vbx = B ? B.vx + B.omega * rbz : 0, vbz = B ? B.vz - B.omega * rbx : 0;
  const rvx = vax - vbx, rvz = vaz - vbz;
  const vn = rvx * n[0] + rvz * n[1];
  if (vn >= 0) return 0;
  const ra_n = raz * n[0] - rax * n[1], rb_n = B ? rbz * n[0] - rbx * n[1] : 0;
  const den = iA + iB + ra_n * ra_n * iIA + rb_n * rb_n * iIB;
  const j = (-(1 + e) * vn) / den;
  A.vx += j * n[0] * iA; A.vz += j * n[1] * iA; A.omega += j * ra_n * iIA;
  if (B) { B.vx -= j * n[0] * iB; B.vz -= j * n[1] * iB; B.omega -= j * rb_n * iIB; }
  // atrito
  const tx = -n[1], tz = n[0];
  const vt = rvx * tx + rvz * tz;
  const ra_t = raz * tx - rax * tz, rb_t = B ? rbz * tx - rbx * tz : 0;
  const dt_ = iA + iB + ra_t * ra_t * iIA + rb_t * rb_t * iIB;
  const jt = clamp(-vt / dt_, -MU_C * j, MU_C * j);
  A.vx += jt * tx * iA; A.vz += jt * tz * iA; A.omega += jt * ra_t * iIA;
  if (B) { B.vx -= jt * tx * iB; B.vz -= jt * tz * iB; B.omega -= jt * rb_t * iIB; }
  return -vn;
}
