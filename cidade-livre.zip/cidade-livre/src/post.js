// Pipeline de pós-processamento: AO, bloom, tone mapping, AA e gradação final.
import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { SMAAPass } from 'three/addons/postprocessing/SMAAPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { GTAOPass } from 'three/addons/postprocessing/GTAOPass.js';

const GradeShader = {
  uniforms: {
    tDiffuse: { value: null }, uTime: { value: 0 }, uSpeed: { value: 0 }, uVig: { value: 0.35 },
    uGrain: { value: 0.03 }, uSat: { value: 1.05 }, uCon: { value: 1.04 }, uCA: { value: 0.0012 }, uTint: { value: new THREE.Vector3(1, 1, 1) },
  },
  vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0); }`,
  fragmentShader: `
    uniform sampler2D tDiffuse; uniform float uTime, uSpeed, uVig, uGrain, uSat, uCon, uCA; uniform vec3 uTint;
    varying vec2 vUv;
    float h(vec2 p){ return fract(sin(dot(p, vec2(12.9898,78.233)))*43758.5453); }
    void main(){
      vec2 c = vUv - 0.5; float r2 = dot(c,c);
      vec2 dirv = c * (0.012 * uSpeed);
      vec3 col = vec3(0.0);
      // desfoque radial leve com velocidade + aberração cromática nas bordas
      float ca = uCA * (0.4 + r2*6.0);
      const int S = 5;
      for(int i=0;i<S;i++){
        float k = float(i)/float(S-1);
        vec2 o = -dirv * k * (0.4 + r2*3.0);
        col.r += texture2D(tDiffuse, vUv + o + c*ca).r;
        col.g += texture2D(tDiffuse, vUv + o).g;
        col.b += texture2D(tDiffuse, vUv + o - c*ca).b;
      }
      col /= float(S);
      col *= uTint;
      float l = dot(col, vec3(0.2126,0.7152,0.0722));
      col = mix(vec3(l), col, uSat);
      col = (col - 0.5) * uCon + 0.5;
      col *= 1.0 - uVig * smoothstep(0.15, 0.85, r2*2.2);
      col += (h(vUv*vec2(1920.0,1080.0) + uTime) - 0.5) * uGrain;
      gl_FragColor = vec4(max(col, 0.0), 1.0);
    }`,
};

export class Post {
  constructor(renderer, scene, camera, Q) {
    this.renderer = renderer; this.scene = scene; this.camera = camera; this.Q = Q;
    this.enabled = Q.composer;
    if (!this.enabled) return;
    const size = renderer.getDrawingBufferSize(new THREE.Vector2());
    const rt = new THREE.WebGLRenderTarget(size.x, size.y, { type: THREE.HalfFloatType, samples: Q.msaa, colorSpace: THREE.LinearSRGBColorSpace });
    this.composer = new EffectComposer(renderer, rt);
    this.composer.setPixelRatio(renderer.getPixelRatio());
    this.composer.addPass(new RenderPass(scene, camera));
    if (Q.gtao) {
      this.gtao = new GTAOPass(scene, camera, size.x, size.y);
      this.gtao.output = GTAOPass.OUTPUT.Default;
      this.gtao.blendIntensity = 0.9;
      this.gtao.updateGtaoMaterial({ radius: 1.6, distanceExponent: 1.5, thickness: 2, scale: 1.2, samples: 12, distanceFallOff: 1, screenSpaceRadius: false });
      this.gtao.updatePdMaterial({ lumaPhi: 10, depthPhi: 2, normalPhi: 3, radius: 6, rings: 2, samples: 12 });
      this.composer.addPass(this.gtao);
    }
    if (Q.bloom) {
      this.bloom = new UnrealBloomPass(new THREE.Vector2(size.x, size.y), 0.35, 0.65, 0.95);
      this.composer.addPass(this.bloom);
    }
    this.composer.addPass(new OutputPass());
    if (Q.smaa) { this.smaa = new SMAAPass(); this.composer.addPass(this.smaa); }
    if (Q.grade) { this.grade = new ShaderPass(GradeShader); this.composer.addPass(this.grade); }
  }
  setSize(w, h) { if (this.enabled) { this.composer.setPixelRatio(this.renderer.getPixelRatio()); this.composer.setSize(w, h); } }
  render(dt, t, speed01, night, over) {
    if (!this.enabled) { this.renderer.render(this.scene, this.camera); return; }
    if (this.bloom) { this.bloom.strength = 0.22 + night * 0.38 + over * 0.05; this.bloom.threshold = 0.9 - night * 0.2; }
    if (this.grade) {
      const u = this.grade.uniforms;
      u.uTime.value = t % 100; u.uSpeed.value = speed01;
      u.uSat.value = 1.06 - over * 0.12; u.uVig.value = 0.3 + night * 0.15;
    }
    this.composer.render(dt);
  }
}
