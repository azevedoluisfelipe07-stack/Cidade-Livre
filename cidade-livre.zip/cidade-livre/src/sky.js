// Atmosfera: céu físico, noite estrelada, sol/lua, ciclo dia-noite, nevoeiro, clima e chuva.
import * as THREE from 'three';
import { Sky } from 'three/addons/objects/Sky.js';
import { clamp, lerp, smoothstep } from './util.js';

const DOME_VERT = `
varying vec3 vDir;
void main(){
  vDir = normalize(position);
  vec4 p = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  gl_Position = p; gl_Position.z = p.w * 0.99999;
}`;
const DOME_FRAG = `
uniform vec3 uSunDir; uniform vec3 uMoonDir; uniform float uNight; uniform vec3 uFog;
uniform float uOver; uniform float uTime; uniform float uHorizon;
varying vec3 vDir;
float hash(vec3 p){ p = fract(p*0.3183099+0.1); p*=17.0; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }
void main(){
  vec3 d = normalize(vDir);
  vec3 col = vec3(0.0); float a = 0.0;
  float up = max(d.y, 0.0);
  // gradiente noturno + brilho da cidade no horizonte
  vec3 ng = mix(vec3(0.012,0.02,0.05), vec3(0.002,0.004,0.014), pow(up, 0.45));
  ng += vec3(0.10,0.055,0.03) * exp(-up*9.0) * 0.55;
  col += ng * uNight * (1.0 - 0.6*uOver);
  // estrelas
  vec3 sd = d * 260.0; vec3 id = floor(sd); vec3 fr = fract(sd) - 0.5;
  float h = hash(id);
  float star = step(0.9965, h) * smoothstep(0.35, 0.0, length(fr));
  float tw = 0.65 + 0.35*sin(uTime*2.0 + h*60.0);
  col += vec3(0.8,0.85,1.0) * star * tw * (0.4 + 2.2*hash(id+7.0)) * uNight * (1.0-uOver) * smoothstep(0.0,0.12,d.y);
  // lua
  float md = dot(d, uMoonDir);
  float disc = smoothstep(0.99985, 0.99992, md);
  float halo = pow(max(md,0.0), 400.0) * 0.5 + pow(max(md,0.0), 40.0) * 0.06;
  vec3 moonC = vec3(0.85,0.9,1.0) * (disc * (1.6 - 0.35*hash(floor(d*40.0))) + halo);
  col += moonC * uNight * (1.0-0.9*uOver) * step(0.0, uMoonDir.y + 0.05);
  a = clamp(disc*uNight*0.0, 0.0, 1.0);
  // nevoeiro no horizonte: combina o céu ao nevoeiro da cena
  float hz = 1.0 - smoothstep(0.0, uHorizon, d.y);
  hz = pow(hz, 1.6);
  col = mix(col, uFog, hz);
  a = mix(a, 1.0, hz);
  gl_FragColor = vec4(col, a);
}`;

function makeDomeMaterial(U) {
  return new THREE.ShaderMaterial({
    uniforms: U, vertexShader: DOME_VERT, fragmentShader: DOME_FRAG,
    side: THREE.BackSide, transparent: true, depthWrite: false, depthTest: true, fog: false,
    blending: THREE.CustomBlending, blendEquation: THREE.AddEquation,
    blendSrc: THREE.OneFactor, blendDst: THREE.OneMinusSrcAlphaFactor,
  });
}

const RAIN_VERT = `
uniform float uTime; uniform vec3 uCam; uniform float uAlpha;
attribute vec3 aSeed; attribute float aEnd;
varying float vA;
void main(){
  vec3 box = vec3(70.0, 45.0, 70.0);
  float speed = 22.0 + aSeed.x * 6.0;
  vec3 p = aSeed * box;
  p.y -= uTime * speed;
  p.x -= uTime * 3.0;
  vec3 w = mod(p - uCam, box) - box*0.5 + uCam;
  vec3 dir = normalize(vec3(0.13,-1.0,0.0));
  vec3 pos = w - dir * aEnd * 0.75;
  vec4 mv = viewMatrix * vec4(pos, 1.0);
  gl_Position = projectionMatrix * mv;
  float d = length(mv.xyz);
  vA = uAlpha * (1.0 - smoothstep(25.0, 38.0, d)) * (0.55 + 0.45*aEnd);
}`;
const RAIN_FRAG = `varying float vA; void main(){ gl_FragColor = vec4(0.78,0.84,0.95,vA*0.4); }`;

export class Atmosphere {
  constructor(scene, renderer, camera, Q) {
    this.scene = scene; this.renderer = renderer; this.camera = camera; this.Q = Q;
    this.hour = 17.2; this.weatherTarget = 0; this.cloud = 0.2; this.rain = 0; this.wet = 0;
    this.sunDir = new THREE.Vector3(); this.moonDir = new THREE.Vector3();
    this.t = 0; this.envTimer = 99; this.envDirty = true;
    this.sunColor = new THREE.Color(); this.fogColor = new THREE.Color();

    this.U = {
      uSunDir: { value: this.sunDir }, uMoonDir: { value: this.moonDir }, uNight: { value: 0 },
      uFog: { value: this.fogColor }, uOver: { value: 0 }, uTime: { value: 0 }, uHorizon: { value: 0.16 },
    };
    this.sky = new Sky(); this.sky.scale.setScalar(450000); this.sky.frustumCulled = false; this.sky.renderOrder = -2;
    scene.add(this.sky);
    this.dome = new THREE.Mesh(new THREE.SphereGeometry(1, 32, 16), makeDomeMaterial(this.U));
    this.dome.scale.setScalar(3000); this.dome.frustumCulled = false; this.dome.renderOrder = -1;
    scene.add(this.dome);

    // luzes
    this.sun = new THREE.DirectionalLight(0xffffff, 3);
    this.sun.castShadow = Q.shadows;
    const s = this.sun.shadow;
    s.mapSize.set(Q.shadowSize, Q.shadowSize);
    const R = Q.shadowRange;
    Object.assign(s.camera, { left: -R, right: R, top: R, bottom: -R, near: 1, far: 1100 });
    s.camera.updateProjectionMatrix();
    s.bias = -0.0004; s.normalBias = 0.06; s.radius = 1.5;
    scene.add(this.sun, this.sun.target);
    this.hemi = new THREE.HemisphereLight(0x9ab8e8, 0x444038, 0.2);
    scene.add(this.hemi);
    scene.fog = new THREE.FogExp2(0xaabbcc, 0.0008);

    // ambiente para reflexos (PMREM)
    this.pmrem = new THREE.PMREMGenerator(renderer);
    this.envScene = new THREE.Scene();
    this.envSky = new Sky(); this.envSky.scale.setScalar(450000); this.envSky.frustumCulled = false;
    this.envSky.material.uniforms.showSunDisc.value = 0;
    this.envDome = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 12), makeDomeMaterial(this.U));
    this.envDome.scale.setScalar(50);
    this.groundMat = new THREE.MeshBasicMaterial({ color: 0x333333, side: THREE.DoubleSide });
    const gp = new THREE.Mesh(new THREE.CircleGeometry(60, 24), this.groundMat);
    gp.rotation.x = -Math.PI / 2; gp.position.y = -0.4;
    this.envScene.add(this.envSky, this.envDome, gp);
    this.envRT = null;

    this.buildStarsAndRain();
    this.setTime(this.hour);
    this.update(0.01, new THREE.Vector3(), true);
  }

  buildStarsAndRain() {
    const n = this.Q.rain;
    const seed = new Float32Array(n * 2 * 3), end = new Float32Array(n * 2);
    for (let i = 0; i < n; i++) {
      const a = Math.random(), b = Math.random(), c = Math.random();
      for (let k = 0; k < 2; k++) { seed.set([a, b, c], (i * 2 + k) * 3); end[i * 2 + k] = k; }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(n * 2 * 3), 3));
    g.setAttribute('aSeed', new THREE.BufferAttribute(seed, 3));
    g.setAttribute('aEnd', new THREE.BufferAttribute(end, 1));
    this.rainU = { uTime: { value: 0 }, uCam: { value: new THREE.Vector3() }, uAlpha: { value: 0 } };
    this.rainMesh = new THREE.LineSegments(g, new THREE.ShaderMaterial({
      uniforms: this.rainU, vertexShader: RAIN_VERT, fragmentShader: RAIN_FRAG,
      transparent: true, depthWrite: false, fog: false,
    }));
    this.rainMesh.frustumCulled = false; this.rainMesh.renderOrder = 10; this.rainMesh.visible = false;
    this.scene.add(this.rainMesh);
  }

  setTime(h) {
    this.hour = ((h % 24) + 24) % 24;
    const a = ((this.hour - 6) / 24) * Math.PI * 2;
    this.sunDir.set(Math.cos(a) * 0.93, Math.sin(a), 0.36).normalize();
    this.moonDir.set(-Math.cos(a) * 0.8 + 0.1, -Math.sin(a) * 0.95 + 0.05, -0.3).normalize();
    this.envDirty = true;
  }
  setWeather(w) { this.weatherTarget = w; this.envDirty = true; } // 0 limpo, 1 nublado, 2 chuva

  /** Valores atuais calculados para uso por outros sistemas */
  get nightFactor() { return this.night; }

  update(dt, playerPos, force = false) {
    this.t += dt;
    const wt = this.weatherTarget;
    const cloudT = wt === 0 ? 0.22 : wt === 1 ? 0.62 : 0.88;
    const rainT = wt === 2 ? 1 : 0;
    this.cloud = lerp(this.cloud, cloudT, 1 - Math.exp(-dt * 0.5));
    this.rain = lerp(this.rain, rainT, 1 - Math.exp(-dt * (rainT > this.rain ? 0.25 : 0.12)));
    this.wet = rainT > 0 ? Math.min(1, this.wet + dt * 0.1) : Math.max(0, this.wet - dt * 0.015);
    const over = clamp((this.cloud - 0.22) / 0.66, 0, 1);
    this.over = over;

    const s = this.sunDir.y;
    const dayF = smoothstep(-0.1, 0.12, s);
    const night = 1 - smoothstep(-0.16, 0.02, s);
    this.night = night; this.dayF = dayF;

    // céu físico
    const su = this.sky.material.uniforms;
    const turb = lerp(2.2, 7, over) + (1 - smoothstep(0, 0.35, s)) * 3;
    su.turbidity.value = turb; su.rayleigh.value = lerp(1.1, 0.4, over) + (1 - smoothstep(0, 0.25, s)) * 1.4;
    su.mieCoefficient.value = lerp(0.004, 0.012, over); su.mieDirectionalG.value = 0.82;
    su.sunPosition.value.copy(this.sunDir);
    su.cloudCoverage.value = this.cloud; su.cloudDensity.value = lerp(0.35, 0.85, over);
    su.time.value = this.t * 40; su.cloudScale.value = 0.00022;
    this.U.uNight.value = night; this.U.uOver.value = over; this.U.uTime.value = this.t;
    this.rainU.uTime.value = this.t;

    // cor do sol e luz principal
    const warm = 1 - smoothstep(0.04, 0.45, s);
    this.sunColor.setRGB(1.0, lerp(0.97, 0.5, warm), lerp(0.92, 0.25, warm));
    const sunI = 3.6 * smoothstep(-0.02, 0.2, s) * lerp(1, 0.16, over);
    const moonI = 0.34 * night * lerp(1, 0.4, over);
    const useSun = s > -0.045;
    const dir = useSun ? this.sunDir : this.moonDir;
    this.lightDir = dir;
    if (useSun) { this.sun.color.copy(this.sunColor); this.sun.intensity = sunI; }
    else { this.sun.color.setRGB(0.55, 0.65, 1.0); this.sun.intensity = moonI; }
    this.sun.visible = this.sun.intensity > 0.001;
    this.hemi.intensity = lerp(0.04, 0.22, dayF) * lerp(1, 1.6, over);
    this.hemi.color.setRGB(lerp(0.12, 0.6, dayF), lerp(0.16, 0.72, dayF), lerp(0.3, 0.95, dayF));
    this.hemi.groundColor.setRGB(lerp(0.03, 0.28, dayF), lerp(0.03, 0.26, dayF), lerp(0.04, 0.22, dayF));
    this.scene.environmentIntensity = lerp(0.22, 1.0, dayF) * lerp(1, 0.85, over);
    this.scene.backgroundIntensity = 1;

    // nevoeiro
    const dusk = 1 - smoothstep(0.05, 0.4, s);
    const dayCol = new THREE.Color(0.62, 0.74, 0.88), duskCol = new THREE.Color(0.8, 0.55, 0.42), nightCol = new THREE.Color(0.02, 0.028, 0.055), grey = new THREE.Color(0.45, 0.5, 0.55);
    this.fogColor.copy(dayCol).lerp(duskCol, dusk * (1 - over * 0.6)).lerp(nightCol, night).lerp(grey.multiplyScalar(lerp(0.25, 1, dayF)), over * 0.75);
    this.scene.fog.color.copy(this.fogColor);
    this.scene.fog.density = lerp(0.00055, 0.0011, over) * this.Q.fogMul + this.rain * 0.0012 + night * 0.00015;
    this.groundMat.color.setRGB(lerp(0.02, 0.2, dayF), lerp(0.02, 0.2, dayF), lerp(0.025, 0.19, dayF)).multiplyScalar(lerp(1, 0.5, over));

    // chuva
    const rv = this.rain > 0.02;
    this.rainMesh.visible = rv;
    if (rv) { this.rainU.uAlpha.value = this.rain; this.rainU.uCam.value.copy(this.camera.position); }

    // exposição
    this.renderer.toneMappingExposure = lerp(1.25, 0.95, dayF) * lerp(1, 1.1, over);
    this.exposureNight = night;

    // posiciona luz com texel snapping
    this.placeSun(playerPos);
    this.sky.position.copy(this.camera.position);
    this.dome.position.copy(this.camera.position);

    // ambiente PMREM
    this.envTimer += dt;
    if (this.Q.envInterval > 0 && (force || (this.envDirty && this.envTimer > 1.0) || this.envTimer > this.Q.envInterval)) this.updateEnv();
    else if (this.Q.envInterval === 0 && (force || this.envDirty) && this.envTimer > 1.5) this.updateEnv();
  }

  placeSun(p) {
    const R = this.Q.shadowRange, size = this.Q.shadowSize;
    const d = this.lightDir;
    const tx = p.x, ty = 0, tz = p.z;
    const fwd = d.clone().negate();
    const right = new THREE.Vector3().crossVectors(fwd, new THREE.Vector3(0, 1, 0)).normalize();
    const up = new THREE.Vector3().crossVectors(right, fwd).normalize();
    const texel = (2 * R) / size;
    const T = new THREE.Vector3(tx, ty, tz);
    const tr = T.dot(right), tu = T.dot(up);
    T.addScaledVector(right, Math.round(tr / texel) * texel - tr).addScaledVector(up, Math.round(tu / texel) * texel - tu);
    this.sun.target.position.copy(T);
    this.sun.position.copy(T).addScaledVector(d, 450);
    this.sun.target.updateMatrixWorld(); this.sun.updateMatrixWorld();
  }

  updateEnv() {
    this.envTimer = 0; this.envDirty = false;
    const su = this.envSky.material.uniforms, src = this.sky.material.uniforms;
    for (const k of ['turbidity', 'rayleigh', 'mieCoefficient', 'mieDirectionalG', 'cloudCoverage', 'cloudDensity', 'time', 'cloudScale', 'cloudSpeed', 'cloudElevation']) su[k].value = src[k].value;
    su.sunPosition.value.copy(this.sunDir);
    const rt = this.pmrem.fromScene(this.envScene, 0.02, 0.1, 100);
    if (this.envRT) this.envRT.dispose();
    this.envRT = rt;
    this.scene.environment = rt.texture;
  }

  dispose() { if (this.envRT) this.envRT.dispose(); }
}
