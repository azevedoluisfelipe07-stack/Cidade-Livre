// Texturas procedurais (canvas) — asfalto, calçadas, fachadas, lojas, placa etc.
import * as THREE from 'three';
import { mulberry32 } from './util.js';

function mk(w, h) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return [c, c.getContext('2d', { willReadFrequently: true })];
}

let ANISO = 8;
let SIZE = 1024;
export function setTexQuality(aniso, size) { ANISO = aniso; SIZE = size; }

function finalize(canvas, srgb = true, size = null) {
  let c = canvas;
  if (size && size !== canvas.width) {
    const [c2, x2] = mk(size, Math.round(size * canvas.height / canvas.width));
    x2.imageSmoothingQuality = 'high';
    x2.drawImage(canvas, 0, 0, c2.width, c2.height);
    c = c2;
  }
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = ANISO;
  t.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  t.minFilter = THREE.LinearMipmapLinearFilter;
  t.magFilter = THREE.LinearFilter;
  t.generateMipmaps = true;
  return t;
}

function noiseFill(ctx, w, h, r, g, b, amp, rng) {
  const id = ctx.createImageData(w, h);
  const d = id.data;
  for (let i = 0; i < d.length; i += 4) {
    const n = (rng() - 0.5) * 2 * amp;
    d[i] = r + n; d[i + 1] = g + n; d[i + 2] = b + n; d[i + 3] = 255;
  }
  ctx.putImageData(id, 0, 0);
}

function blotches(ctx, w, h, count, rng, light = 255, dark = 0, aMax = 0.06, rMin = 8, rMax = 80) {
  for (let i = 0; i < count; i++) {
    const x = rng() * w, y = rng() * h, r = rMin + rng() * (rMax - rMin);
    const v = rng() < 0.5 ? dark : light;
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, `rgba(${v},${v},${v},${aMax * rng()})`);
    g.addColorStop(1, `rgba(${v},${v},${v},0)`);
    ctx.fillStyle = g;
    // desenha com wrap horizontal/vertical para tile contínuo
    for (const ox of [-w, 0, w]) for (const oy of [-h, 0, h]) {
      if (x + ox + r < 0 || x + ox - r > w || y + oy + r < 0 || y + oy - r > h) continue;
      ctx.save(); ctx.translate(ox, oy); ctx.fillRect(x - r, y - r, r * 2, r * 2); ctx.restore();
    }
  }
}

// ---------------------------------------------------------------- ASFALTO / RUAS
function asphaltBase(ctx, w, h, rng) {
  noiseFill(ctx, w, h, 54, 55, 58, 13, rng);
  blotches(ctx, w, h, 220, rng, 120, 20, 0.07, 10, 90);
  ctx.globalAlpha = 0.5;
  for (let i = 0; i < w * h / 180; i++) {
    const v = 90 + rng() * 80;
    ctx.fillStyle = `rgb(${v},${v},${v + 4})`;
    ctx.fillRect(rng() * w, rng() * h, 1 + rng(), 1 + rng());
  }
  ctx.globalAlpha = 1;
}

export function makeAsphaltTile(seed = 1) {
  const rng = mulberry32(seed);
  const [c, x] = mk(512, 512);
  asphaltBase(x, 512, 512, rng);
  return finalize(c, true);
}

export function makeAsphaltBump(seed = 2) {
  const rng = mulberry32(seed);
  const [c, x] = mk(512, 512);
  noiseFill(x, 512, 512, 128, 128, 128, 70, rng);
  blotches(x, 512, 512, 100, rng, 200, 60, 0.12, 4, 40);
  return finalize(c, false);
}

/** Textura de uma rua: u atravessa a largura, v ao longo (16 m por repetição). */
export function makeRoadTexture(widthM, avenue, seed = 3) {
  const rng = mulberry32(seed + (avenue ? 100 : 0));
  const W = 512, H = 1024;
  const [c, x] = mk(W, H);
  asphaltBase(x, W, H, rng);
  const half = widthM / 2;
  const X = (m) => ((m + half) / widthM) * W;
  const MW = (m) => (m / widthM) * W;
  const Y = (m) => (m / 16) * H;

  // trilhas dos pneus
  const lanes = avenue ? [3.75, 7.25, 10.75] : [1.75, 5.25];
  x.globalAlpha = 0.16;
  for (const sgn of [-1, 1]) for (const l of lanes) {
    for (const off of [-0.8, 0.8]) {
      const gx = x.createLinearGradient(X(sgn * l + off - 0.35), 0, X(sgn * l + off + 0.35), 0);
      gx.addColorStop(0, 'rgba(0,0,0,0)'); gx.addColorStop(0.5, 'rgba(0,0,0,1)'); gx.addColorStop(1, 'rgba(0,0,0,0)');
      x.fillStyle = gx;
      x.fillRect(X(sgn * l + off - 0.35), 0, MW(0.7), H);
    }
  }
  x.globalAlpha = 1;
  // remendos de asfalto
  for (let i = 0; i < 9; i++) {
    const v = 40 + rng() * 22;
    x.fillStyle = `rgba(${v},${v},${v + 3},0.55)`;
    x.fillRect(rng() * W, rng() * H, 30 + rng() * 120, 20 + rng() * 150);
  }
  // rachaduras
  x.strokeStyle = 'rgba(15,15,16,0.55)'; x.lineWidth = 1.2;
  for (let i = 0; i < 14; i++) {
    let px = rng() * W, py = rng() * H;
    x.beginPath(); x.moveTo(px, py);
    for (let k = 0; k < 12; k++) { px += (rng() - 0.5) * 30; py += (rng() - 0.3) * 26; x.lineTo(px, py); }
    x.stroke();
  }

  // marcações em camada separada para desgaste
  const [lc, lx] = mk(W, H);
  const white = '#e9e9e2', yellow = '#dcaa1e';
  const solid = (m, wm, col) => { lx.fillStyle = col; lx.fillRect(X(m - wm / 2), 0, MW(wm), H); };
  const dashed = (m, wm, col, len = 3, period = 8) => {
    lx.fillStyle = col;
    for (let s = 0; s < 16; s += period) lx.fillRect(X(m - wm / 2), Y(s + 0.5), MW(wm), Y(len));
  };
  if (!avenue) {
    solid(-0.14, 0.13, yellow); solid(0.14, 0.13, yellow);
    for (const s of [-1, 1]) { dashed(s * 3.5, 0.13, white); solid(s * 7.4, 0.15, white); }
  } else {
    // canteiro central cobre ±2; faixas
    for (const s of [-1, 1]) {
      solid(s * 2.25, 0.13, yellow);
      dashed(s * 5.5, 0.13, white); dashed(s * 9.0, 0.13, white);
      solid(s * 12.6, 0.15, white);
    }
  }
  // desgaste
  lx.globalCompositeOperation = 'destination-out';
  for (let i = 0; i < 5200; i++) {
    lx.fillStyle = `rgba(0,0,0,${0.3 + rng() * 0.6})`;
    lx.fillRect(rng() * W, rng() * H, 1 + rng() * 4, 1 + rng() * 5);
  }
  for (let i = 0; i < 40; i++) {
    lx.fillStyle = `rgba(0,0,0,${0.15 + rng() * 0.35})`;
    lx.fillRect(rng() * W, rng() * H, 4 + rng() * 14, 20 + rng() * 80);
  }
  lx.globalCompositeOperation = 'source-over';
  x.drawImage(lc, 0, 0);
  const map = finalize(c, true);

  // rugosidade (G): trilhas mais lisas, tinta levemente mais lisa
  const [rc, rx] = mk(256, 512);
  noiseFill(rx, 256, 512, 226, 226, 226, 14, rng);
  rx.globalAlpha = 0.5; rx.drawImage(lc, 0, 0, 256, 512); rx.globalAlpha = 1;
  rx.globalCompositeOperation = 'multiply';
  rx.fillStyle = 'rgba(210,210,210,0.35)'; rx.fillRect(0, 0, 256, 512);
  const rough = finalize(rc, false);
  return { map, rough };
}

// ---------------------------------------------------------------- CALÇADA / GRAMA / TELHADO
export function makeConcrete(seed = 4) {
  const rng = mulberry32(seed);
  const S = 1024;
  const [c, x] = mk(S, S);
  noiseFill(x, S, S, 168, 166, 160, 9, rng);
  const tile = S / 4; // lajes de 2 m
  for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) {
    const v = (rng() - 0.5) * 18;
    x.fillStyle = `rgba(${v > 0 ? 255 : 0},${v > 0 ? 255 : 0},${v > 0 ? 255 : 0},${Math.abs(v) / 255})`;
    x.fillRect(i * tile, j * tile, tile, tile);
  }
  blotches(x, S, S, 260, rng, 255, 40, 0.07, 14, 120);
  x.strokeStyle = 'rgba(40,40,38,0.55)'; x.lineWidth = 3;
  for (let i = 0; i <= 4; i++) {
    x.beginPath(); x.moveTo(i * tile, 0); x.lineTo(i * tile, S); x.stroke();
    x.beginPath(); x.moveTo(0, i * tile); x.lineTo(S, i * tile); x.stroke();
  }
  x.strokeStyle = 'rgba(40,40,38,0.35)'; x.lineWidth = 1;
  for (let i = 0; i < 22; i++) {
    let px = rng() * S, py = rng() * S;
    x.beginPath(); x.moveTo(px, py);
    for (let k = 0; k < 8; k++) { px += (rng() - 0.5) * 40; py += (rng() - 0.5) * 40; x.lineTo(px, py); }
    x.stroke();
  }
  return finalize(c, true, SIZE >= 1024 ? 1024 : 512);
}

export function makeGrass(seed = 5) {
  const rng = mulberry32(seed);
  const S = 512;
  const [c, x] = mk(S, S);
  noiseFill(x, S, S, 70, 104, 44, 14, rng);
  blotches(x, S, S, 160, rng, 150, 20, 0.12, 10, 90);
  for (let i = 0; i < 9000; i++) {
    const g = 70 + rng() * 80;
    x.strokeStyle = `rgba(${g * 0.6},${g},${g * 0.35},0.5)`;
    x.lineWidth = 1;
    const px = rng() * S, py = rng() * S;
    x.beginPath(); x.moveTo(px, py); x.lineTo(px + (rng() - 0.5) * 4, py - 2 - rng() * 5); x.stroke();
  }
  return finalize(c, true);
}

export function makeRoof(seed = 6) {
  const rng = mulberry32(seed);
  const S = 256;
  const [c, x] = mk(S, S);
  noiseFill(x, S, S, 86, 86, 84, 26, rng);
  blotches(x, S, S, 40, rng, 160, 20, 0.1, 6, 50);
  return finalize(c, true);
}

export function makeRoofTiles(seed = 7) {
  const rng = mulberry32(seed);
  const S = 256;
  const [c, x] = mk(S, S);
  x.fillStyle = '#9a4a32'; x.fillRect(0, 0, S, S);
  for (let r = 0; r < 16; r++) for (let k = 0; k < 16; k++) {
    const v = (rng() - 0.5) * 36;
    x.fillStyle = `rgb(${154 + v},${74 + v * 0.6},${50 + v * 0.5})`;
    x.fillRect(k * 16 + (r % 2) * 8 - 8, r * 16, 15, 14);
    x.fillStyle = 'rgba(0,0,0,0.25)'; x.fillRect(k * 16 + (r % 2) * 8 - 8, r * 16 + 13, 15, 3);
  }
  return finalize(c, true);
}

// ---------------------------------------------------------------- FAIXA DE PEDESTRES
export function makeCrosswalk() {
  const rng = mulberry32(11);
  const [c, x] = mk(256, 128);
  x.clearRect(0, 0, 256, 128);
  x.fillStyle = '#ecece4';
  x.fillRect(0, 0, 128, 128);
  x.globalCompositeOperation = 'destination-out';
  for (let i = 0; i < 1400; i++) {
    x.fillStyle = `rgba(0,0,0,${0.3 + rng() * 0.6})`;
    x.fillRect(rng() * 256, rng() * 128, 1 + rng() * 3, 1 + rng() * 4);
  }
  return finalize(c, true);
}

// ---------------------------------------------------------------- FACHADAS
const WARM = ['255,216,150', '255,226,176', '255,236,200', '255,200,130', '230,240,255'];

/** Cada fachada cobre 16 m x 16 m. Retorna {map, orm, emissive}. */
export function makeFacade(kind, seed = 1) {
  const rng = mulberry32(seed * 977 + kind.length * 31);
  const S = 1024, P = 64; // 64 px/m
  const [c, x] = mk(S, S);
  const [oc, ox] = mk(S, S); // R=ao, G=rugosidade, B=metal
  const [ec, ex] = mk(S, S);
  ex.fillStyle = '#000'; ex.fillRect(0, 0, S, S);
  const orm = (r, g, b) => `rgb(${r * 255 | 0},${g * 255 | 0},${b * 255 | 0})`;
  const fillBoth = (px, py, w, h, col, o) => {
    x.fillStyle = col; x.fillRect(px, py, w, h);
    ox.fillStyle = o; ox.fillRect(px, py, w, h);
  };
  const lit = (px, py, w, h) => {
    const col = WARM[Math.floor(rng() * WARM.length)];
    const a = 0.45 + rng() * 0.55;
    const g = ex.createLinearGradient(0, py, 0, py + h);
    g.addColorStop(0, `rgba(${col},${a})`); g.addColorStop(1, `rgba(${col},${a * 0.55})`);
    ex.fillStyle = g; ex.fillRect(px, py, w, h);
  };

  if (kind === 'glass') {
    const floorH = 4 * P, bay = 2 * P;
    noiseFill(x, S, S, 80, 90, 100, 5, rng);
    ox.fillStyle = orm(1, 0.5, 0.4); ox.fillRect(0, 0, S, S);
    for (let f = 0; f < 4; f++) {
      const y0 = f * floorH;
      // spandrel
      fillBoth(0, y0 + floorH - 1.15 * P, S, 1.15 * P, 'rgb(112,124,134)', orm(0.9, 0.42, 0.55));
      for (let b = 0; b < 8; b++) {
        const px = b * bay;
        const gy = y0, gh = floorH - 1.15 * P;
        const tint = (rng() - 0.5) * 18;
        const g = x.createLinearGradient(px, gy, px + bay, gy + gh);
        g.addColorStop(0, `rgb(${70 + tint},${106 + tint},${130 + tint})`);
        g.addColorStop(0.55, `rgb(${34 + tint},${58 + tint},${78 + tint})`);
        g.addColorStop(1, `rgb(${22 + tint},${38 + tint},${54 + tint})`);
        x.fillStyle = g; x.fillRect(px + 3, gy + 3, bay - 6, gh - 3);
        ox.fillStyle = orm(1, 0.05, 0.92); ox.fillRect(px + 3, gy + 3, bay - 6, gh - 3);
        if (rng() < 0.16) { // persiana
          x.fillStyle = `rgba(${200 + rng() * 40},${190 + rng() * 30},${165},0.88)`;
          const hh = gh * (0.35 + rng() * 0.6);
          x.fillRect(px + 3, gy + 3, bay - 6, hh);
          ox.fillStyle = orm(1, 0.7, 0); ox.fillRect(px + 3, gy + 3, bay - 6, hh);
        } else if (rng() < 0.3) lit(px + 3, gy + 3, bay - 6, gh - 3);
      }
      // mainéis
      x.fillStyle = '#4a525a'; ox.fillStyle = orm(1, 0.35, 0.85);
      for (let b = 0; b <= 8; b++) { x.fillRect(b * bay - 3, y0, 6, floorH); ox.fillRect(b * bay - 3, y0, 6, floorH); }
      x.fillRect(0, y0, S, 5); ox.fillRect(0, y0, S, 5);
    }
  } else if (kind === 'office') {
    const floorH = 4 * P, col = 4 * P;
    noiseFill(x, S, S, 166, 164, 158, 7, rng);
    blotches(x, S, S, 60, rng, 255, 40, 0.07, 10, 90);
    ox.fillStyle = orm(1, 0.85, 0); ox.fillRect(0, 0, S, S);
    for (let f = 0; f < 4; f++) {
      const y0 = f * floorH;
      for (let b = 0; b < 4; b++) {
        const px = b * col + 0.45 * P, w = col - 0.9 * P, gy = y0 + 1.15 * P, gh = 2.35 * P;
        const g = x.createLinearGradient(px, gy, px + w, gy + gh);
        const t = (rng() - 0.5) * 14;
        g.addColorStop(0, `rgb(${96 + t},${120 + t},${136 + t})`);
        g.addColorStop(0.6, `rgb(${38 + t},${52 + t},${64 + t})`);
        g.addColorStop(1, `rgb(${26 + t},${34 + t},${44 + t})`);
        x.fillStyle = g; x.fillRect(px, gy, w, gh);
        ox.fillStyle = orm(1, 0.07, 0.8); ox.fillRect(px, gy, w, gh);
        x.fillStyle = '#2b2f33'; x.fillRect(px, gy + gh * 0.5 - 2, w, 4); // travessa
        if (rng() < 0.3) lit(px, gy, w, gh);
        else if (rng() < 0.15) { x.fillStyle = 'rgba(210,205,190,0.8)'; x.fillRect(px, gy, w, gh * 0.5); }
      }
      x.fillStyle = 'rgba(0,0,0,0.12)'; x.fillRect(0, y0 + floorH - 4, S, 4); // junta da laje
    }
  } else if (kind === 'brick') {
    const floorH = 3.2 * P, bay = 4 * P;
    const hue = rng();
    const base = hue < 0.5 ? [150, 84, 64] : hue < 0.8 ? [196, 170, 130] : [184, 176, 168];
    noiseFill(x, S, S, base[0], base[1], base[2], 6, rng);
    const bh = 5, bw = 15;
    for (let r = 0; r < S / bh; r++) for (let k = -1; k < S / bw + 1; k++) {
      const v = (rng() - 0.5) * 30;
      x.fillStyle = `rgb(${base[0] + v},${base[1] + v * 0.8},${base[2] + v * 0.7})`;
      x.fillRect(k * bw + (r % 2) * (bw / 2), r * bh, bw - 1, bh - 1);
    }
    ox.fillStyle = orm(1, 0.92, 0); ox.fillRect(0, 0, S, S);
    for (let f = 0; f < 5; f++) {
      const y0 = f * floorH;
      for (let b = 0; b < 4; b++) {
        const cx = b * bay + bay / 2;
        const ww = 1.4 * P, wh = 1.7 * P, wx = cx - ww / 2, wy = y0 + 0.75 * P;
        // moldura clara + vidro
        x.fillStyle = '#e6e2d8'; x.fillRect(wx - 6, wy - 6, ww + 12, wh + 12);
        const g = x.createLinearGradient(wx, wy, wx + ww, wy + wh);
        g.addColorStop(0, '#5d7486'); g.addColorStop(1, '#1c2630');
        x.fillStyle = g; x.fillRect(wx, wy, ww, wh);
        ox.fillStyle = orm(1, 0.08, 0.5); ox.fillRect(wx, wy, ww, wh);
        x.fillStyle = '#e6e2d8'; x.fillRect(wx + ww / 2 - 2, wy, 4, wh);
        const r = rng();
        if (r < 0.4) lit(wx, wy, ww, wh);
        else if (r < 0.6) { x.fillStyle = `rgba(${220 + rng() * 30},${200 + rng() * 40},${170},0.85)`; x.fillRect(wx, wy, ww, wh * (0.3 + rng() * 0.6)); }
        // soleira
        x.fillStyle = '#cfcac0'; x.fillRect(wx - 10, wy + wh + 6, ww + 20, 8);
        // sacada em andares alternados
        if ((f + b) % 2 === 0 && f > 0) {
          x.fillStyle = '#d6d2c8'; x.fillRect(cx - 1.1 * P, y0 - 0.1 * P, 2.2 * P, 10);
          x.fillStyle = 'rgba(30,30,30,0.7)';
          for (let k = 0; k <= 11; k++) x.fillRect(cx - 1.1 * P + k * (2.2 * P / 11), y0 - 0.1 * P - 32, 3, 32);
          x.fillRect(cx - 1.1 * P, y0 - 0.1 * P - 34, 2.2 * P, 4);
        }
      }
      x.fillStyle = 'rgba(0,0,0,0.18)'; x.fillRect(0, y0 + floorH - 3, S, 3);
    }
  } else { // 'modern'
    const floorH = 4 * P;
    noiseFill(x, S, S, 218, 218, 214, 4, rng);
    ox.fillStyle = orm(1, 0.7, 0.05); ox.fillRect(0, 0, S, S);
    x.strokeStyle = 'rgba(0,0,0,0.12)'; x.lineWidth = 2;
    for (let i = 0; i <= 8; i++) { x.beginPath(); x.moveTo(i * 2 * P, 0); x.lineTo(i * 2 * P, S); x.stroke(); }
    for (let i = 0; i <= 16; i++) { x.beginPath(); x.moveTo(0, i * P); x.lineTo(S, i * P); x.stroke(); }
    for (let f = 0; f < 4; f++) {
      const y0 = f * floorH;
      for (let b = 0; b < 4; b++) {
        const px = b * 4 * P;
        const wood = rng() < 0.22;
        if (wood) {
          x.fillStyle = '#8a5d3a'; x.fillRect(px + 0.2 * P, y0 + 0.3 * P, 3.6 * P, 3.4 * P);
          for (let k = 0; k < 30; k++) { x.fillStyle = `rgba(40,20,5,${0.1 + rng() * 0.1})`; x.fillRect(px + 0.2 * P + k * 7.7, y0 + 0.3 * P, 2, 3.4 * P); }
          ox.fillStyle = orm(1, 0.7, 0); ox.fillRect(px + 0.2 * P, y0 + 0.3 * P, 3.6 * P, 3.4 * P);
        }
        const wx = px + 0.9 * P, wy = y0 + 0.7 * P, ww = 2.2 * P, wh = 2.6 * P;
        x.fillStyle = '#23272b'; x.fillRect(wx - 5, wy - 5, ww + 10, wh + 10);
        const g = x.createLinearGradient(wx, wy, wx + ww, wy + wh);
        g.addColorStop(0, '#7f9aae'); g.addColorStop(0.5, '#33485a'); g.addColorStop(1, '#161f28');
        x.fillStyle = g; x.fillRect(wx, wy, ww, wh);
        ox.fillStyle = orm(1, 0.06, 0.8); ox.fillRect(wx, wy, ww, wh);
        x.fillStyle = '#23272b'; x.fillRect(wx + ww / 2 - 2, wy, 4, wh);
        const r = rng();
        if (r < 0.35) lit(wx, wy, ww, wh);
        else if (r < 0.5) { x.fillStyle = 'rgba(235,228,214,0.85)'; x.fillRect(wx, wy, ww, wh * (0.4 + rng() * 0.5)); }
      }
    }
  }
  return {
    map: finalize(c, true, SIZE),
    orm: finalize(oc, false, SIZE),
    emissive: finalize(ec, true, SIZE),
  };
}

// ---------------------------------------------------------------- LOJAS (térreo)
const LOJAS = ['PADARIA', 'FARMÁCIA', 'CAFÉ', 'MERCADO', 'BARBEARIA', 'PIZZARIA', 'LIVRARIA', 'ÓTICA', 'BANCO', 'ACADEMIA',
  'SORVETES', 'LANCHES', 'PAPELARIA', 'RESTAURANTE', 'SAPATARIA', 'MODA', 'CELULARES', 'PET SHOP', 'AÇAÍ', 'HORTIFRUTI',
  'LAVANDERIA', 'BAR DO ZÉ', 'CONFEITARIA', 'ESPETINHO', 'CLÍNICA'];
const SIGNCOL = [['#c8202a', '#fff'], ['#12418a', '#fff'], ['#f2b705', '#1b1b1b'], ['#1e7a46', '#fff'], ['#222', '#ffd84a'],
  ['#f4f0e6', '#7a1020'], ['#6a2c91', '#fff'], ['#0f8b8d', '#fff'], ['#e8672a', '#fff']];

export function makeShopfront(seed = 1) {
  const rng = mulberry32(seed * 131 + 9);
  const W = 1024, H = 288, P = 64;
  const [c, x] = mk(W, H);
  const [oc, ox] = mk(W, H);
  const [ec, ex] = mk(W, H);
  ex.fillStyle = '#000'; ex.fillRect(0, 0, W, H);
  const wall = [[190, 184, 172], [150, 150, 148], [210, 200, 180], [120, 96, 80], [92, 100, 110]][Math.floor(rng() * 5)];
  noiseFill(x, W, H, wall[0], wall[1], wall[2], 6, rng);
  ox.fillStyle = 'rgb(255,215,0)'; ox.fillRect(0, 0, W, H);
  for (let b = 0; b < 4; b++) {
    const px = b * 4 * P;
    const garage = rng() < 0.16;
    if (garage) {
      x.fillStyle = '#4f5559'; x.fillRect(px + 0.4 * P, 0.6 * P, 3.2 * P, H - 0.6 * P);
      for (let k = 0; k < 14; k++) { x.fillStyle = 'rgba(0,0,0,0.25)'; x.fillRect(px + 0.4 * P, 0.6 * P + k * 15, 3.2 * P, 2); }
      continue;
    }
    // vitrine
    const wx = px + 0.3 * P, ww = 3.4 * P, wy = 0.95 * P, wh = 2.6 * P - 0.1 * P;
    x.fillStyle = '#1d2024'; x.fillRect(wx - 6, wy - 6, ww + 12, wh + 6);
    const g = x.createLinearGradient(wx, wy, wx + ww, wy + wh);
    g.addColorStop(0, '#6f8798'); g.addColorStop(0.5, '#2c3a46'); g.addColorStop(1, '#161d24');
    x.fillStyle = g; x.fillRect(wx, wy, ww, wh);
    ox.fillStyle = 'rgb(255,14,150)'; ox.fillRect(wx, wy, ww, wh);
    // interior iluminado
    const interior = `rgba(${WARM[Math.floor(rng() * 3)]},1)`;
    ex.fillStyle = interior; ex.globalAlpha = 0.35 + rng() * 0.4; ex.fillRect(wx, wy, ww, wh); ex.globalAlpha = 1;
    // prateleiras visíveis
    for (let k = 0; k < 9; k++) {
      const hue = Math.floor(rng() * 360);
      const rx = wx + 8 + rng() * (ww - 60), ry = wy + 0.7 * P + rng() * (wh - 1.2 * P);
      x.fillStyle = `hsla(${hue},45%,45%,0.55)`; x.fillRect(rx, ry, 18 + rng() * 40, 10 + rng() * 26);
      ex.fillStyle = `hsla(${hue},60%,60%,0.6)`; ex.fillRect(rx, ry, 18 + rng() * 40, 10 + rng() * 26);
    }
    // porta
    const dx = wx + (rng() < 0.5 ? 0.15 : 2.2) * P;
    x.fillStyle = '#16191c'; x.fillRect(dx, wy, 1.0 * P, wh);
    x.fillStyle = 'rgba(160,190,210,0.25)'; x.fillRect(dx + 5, wy + 5, 1.0 * P - 10, wh - 5);
    // letreiro
    const [bg, fg] = SIGNCOL[Math.floor(rng() * SIGNCOL.length)];
    const sy = 0.2 * P, sh = 0.62 * P;
    x.fillStyle = bg; x.fillRect(px + 0.15 * P, sy, 3.7 * P, sh);
    ex.fillStyle = bg; ex.globalAlpha = 0.9; ex.fillRect(px + 0.15 * P, sy, 3.7 * P, sh); ex.globalAlpha = 1;
    ox.fillStyle = 'rgb(255,120,0)'; ox.fillRect(px + 0.15 * P, sy, 3.7 * P, sh);
    const name = LOJAS[Math.floor(rng() * LOJAS.length)];
    x.font = `bold ${Math.round(sh * 0.62)}px Arial, Helvetica, sans-serif`;
    x.textAlign = 'center'; x.textBaseline = 'middle';
    let fs = Math.round(sh * 0.62);
    while (x.measureText(name).width > 3.5 * P && fs > 12) { fs -= 2; x.font = `bold ${fs}px Arial, Helvetica, sans-serif`; }
    x.fillStyle = fg; x.fillText(name, px + 2 * P, sy + sh / 2 + 2);
    ex.font = x.font; ex.textAlign = 'center'; ex.textBaseline = 'middle';
    ex.fillStyle = fg; ex.fillText(name, px + 2 * P, sy + sh / 2 + 2);
    // toldo
    if (rng() < 0.4) {
      const col = SIGNCOL[Math.floor(rng() * SIGNCOL.length)][0];
      for (let k = 0; k < 17; k++) {
        x.fillStyle = k % 2 ? col : '#f2efe8';
        x.fillRect(wx + k * (ww / 17), wy - 0.05 * P, ww / 17 + 1, 0.42 * P);
      }
    }
  }
  x.fillStyle = 'rgba(0,0,0,0.3)'; x.fillRect(0, H - 4, W, 4);
  return { map: finalize(c, true, SIZE), orm: finalize(oc, false, SIZE), emissive: finalize(ec, true, SIZE) };
}

// ---------------------------------------------------------------- PLACA (Mercosul)
export function makePlate() {
  const [c, x] = mk(512, 128);
  x.fillStyle = '#f3f3f0'; x.fillRect(0, 0, 512, 128);
  x.fillStyle = '#17458f'; x.fillRect(0, 0, 512, 28);
  x.fillStyle = '#fff'; x.font = 'bold 20px Arial'; x.textAlign = 'center'; x.textBaseline = 'middle';
  x.fillText('BRASIL', 256, 15);
  x.fillStyle = '#16181a'; x.font = 'bold 84px "Arial Narrow", Arial, sans-serif';
  x.fillText('LIV3R4', 256, 78);
  x.strokeStyle = '#222'; x.lineWidth = 5; x.strokeRect(2, 2, 508, 124);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  return t;
}

// ---------------------------------------------------------------- brilho radial (lâmpadas / poças de luz)
export function makeGlow() {
  const [c, x] = mk(128, 128);
  const g = x.createRadialGradient(64, 64, 0, 64, 64, 64);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.15, 'rgba(255,255,255,0.55)');
  g.addColorStop(0.5, 'rgba(255,255,255,0.12)');
  g.addColorStop(1, 'rgba(255,255,255,0)');
  x.fillStyle = g; x.fillRect(0, 0, 128, 128);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
