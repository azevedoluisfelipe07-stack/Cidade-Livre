// Tráfego de IA (segue as faixas, respeita semáforos, reage a colisões) e carros estacionados instanciados.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { WORLD } from './config.js';
import { CAR_TYPES, makeSpec, buildCarGeometry, makeCarMaterials, createCar } from './car.js';
import { mulberry32, clamp, lerp, angleDiff } from './util.js';
import { obbOf, collideObb, collideCircle } from './physics.js';

const N = WORLD.N;
const COLORS = [0xe8e8ea, 0x1a1c20, 0x8d9299, 0xb3141b, 0x1c3f7a, 0xd8d3c4, 0x2e5a3c, 0x5c1d2a, 0xc9a24a, 0x4a4f57, 0x0d0d0f, 0xf0f0f2];
const hash3 = (a, b, c) => { let h = (a * 374761393 + b * 668265263 + c * 2147483647) | 0; h = (h ^ (h >>> 13)) * 1274126177; h = h ^ (h >>> 16); return ((h >>> 0) % 100000) / 100000; };

export function laneOffsets(w) { return w > 20 ? [3.8, 7.3, 10.8] : [1.9, 5.4]; }

export class Traffic {
  constructor(scene, city, Q) {
    this.scene = scene; this.city = city; this.Q = Q;
    this.rng = mulberry32(4242);
    this.cars = [];
    this.group = new THREE.Group(); scene.add(this.group);
    this.geoCache = {};
    for (const t of CAR_TYPES) { const spec = makeSpec(t); this.geoCache[t] = { spec, geo: buildCarGeometry(spec, 'lo') }; }
    this.night = 0;
    this.initParked();
  }

  // ------------------------------------------------------------ IA
  start(playerPos) {
    for (let i = 0; i < this.Q.traffic; i++) this.spawn(playerPos, true);
  }
  makeCar() {
    const r = this.rng;
    const type = CAR_TYPES[Math.floor(r() * CAR_TYPES.length)];
    const { spec, geo } = this.geoCache[type];
    const color = COLORS[Math.floor(r() * COLORS.length)];
    const mats = makeCarMaterials(spec, color, 'lo');
    const obj = createCar(type, color, { lod: 'lo', geo, mats });
    obj.group.traverse((o) => { if (o.isMesh) o.castShadow = o === obj.paintMesh; });
    this.group.add(obj.group);
    const m = spec.mass;
    return { obj, spec, body: { x: 0, z: 0, yaw: 0, vx: 0, vz: 0, omega: 0, invM: 1 / m, invI: 1 / (m * 3.4), hl: spec.L / 2, hw: spec.W, cOff: 0 },
      mode: 'lane', v: 0, vmax: 11 + r() * 5, lane: 0, dx: 0, dz: 1, ix: 0, iz: 0, move: null, wreckT: 0, tpath: null, u: 0, brake: false, steerAng: 0 };
  }
  spawn(pp, initial = false, car = null) {
    const r = this.rng, city = this.city;
    for (let attempt = 0; attempt < 40; attempt++) {
      // interseção aleatória num anel ao redor do jogador
      const ang = r() * Math.PI * 2, rad = (initial ? 60 : 160) + r() * (initial ? 220 : 120);
      const px = pp.x + Math.cos(ang) * rad, pz = pp.z + Math.sin(ang) * rad;
      let ix = 0, iz = 0, bx = 1e9, bz = 1e9;
      for (let i = 0; i <= N; i++) { const d = Math.abs(city.rc[i] - px); if (d < bx) { bx = d; ix = i; } const e = Math.abs(city.rc[i] - pz); if (e < bz) { bz = e; iz = i; } }
      const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]];
      const d = dirs[Math.floor(r() * 4)];
      // cidade: intersecção alvo (ix,iz); precisa de interseção anterior válida
      const px_ = ix - d[0], pz_ = iz - d[1];
      if (px_ < 0 || px_ > N || pz_ < 0 || pz_ > N) continue;
      const wRoad = d[0] === 0 ? city.rw[ix] : city.rw[iz];
      const lanes = laneOffsets(wRoad);
      const lane = Math.floor(r() * lanes.length);
      const off = lanes[lane];
      const perpHalf = d[0] === 0 ? city.rw[iz] / 2 : city.rw[ix] / 2;
      const segLen = Math.hypot(city.rc[ix] - city.rc[px_], city.rc[iz] - city.rc[pz_]);
      const dist = perpHalf + 6 + r() * Math.max(10, segLen - 2 * perpHalf - 30);
      const right = [-d[1], d[0]];
      const x = city.rc[ix] - d[0] * dist + right[0] * off, z = city.rc[iz] - d[1] * dist + right[1] * off;
      if (Math.hypot(x - pp.x, z - pp.z) < (initial ? 25 : 120)) continue;
      // evita sobreposição
      let bad = false;
      for (const c of this.cars) if (c !== car && Math.hypot(c.body.x - x, c.body.z - z) < 9) { bad = true; break; }
      if (bad) continue;
      const c = car || this.makeCar();
      Object.assign(c, { mode: 'lane', lane, dx: d[0], dz: d[1], ix, iz, move: null, wreckT: 0, u: 0, tpath: null, v: 6 + r() * 4 });
      c.vmax = (wRoad > 20 ? 14 : 11) + r() * 4;
      const b = c.body; b.x = x; b.z = z; b.yaw = Math.atan2(d[0], d[1]); b.vx = b.vz = b.omega = 0;
      if (!car) this.cars.push(c);
      c.obb = null; this.syncVisual(c, 0);
      return c;
    }
    return null;
  }

  chooseMove(c) {
    const city = this.city, r = this.rng;
    const lanes = laneOffsets(c.dx === 0 ? city.rw[c.ix] : city.rw[c.iz]);
    const opts = [];
    const valid = (dx, dz) => { const nx = c.ix + dx, nz = c.iz + dz; return nx >= 0 && nx <= N && nz >= 0 && nz <= N; };
    const left = [c.dz, -c.dx], rightD = [-c.dz, c.dx]; // esquerda = -right
    // left = rotaciona: left(d) = (dz, -dx)
    if (valid(c.dx, c.dz)) opts.push([c.dx, c.dz, 0.6]);
    const isInner = c.lane === 0, isOuter = c.lane === lanes.length - 1;
    if (valid(left[0], left[1]) && isInner) opts.push([left[0], left[1], 0.2]);
    if (valid(rightD[0], rightD[1]) && isOuter) opts.push([rightD[0], rightD[1], 0.25]);
    if (!opts.length) { if (valid(left[0], left[1])) opts.push([left[0], left[1], 1]); if (valid(rightD[0], rightD[1])) opts.push([rightD[0], rightD[1], 1]); }
    if (!opts.length) opts.push([-c.dx, -c.dz, 1]);
    let tot = 0; for (const o of opts) tot += o[2];
    let k = r() * tot, sel = opts[0];
    for (const o of opts) { k -= o[2]; if (k <= 0) { sel = o; break; } }
    // não vira à esquerda se houver tráfego contrário próximo
    if (sel[0] === left[0] && sel[1] === left[1] && (left[0] !== c.dx || left[1] !== c.dz)) {
      const cx = city.rc[c.ix], cz = city.rc[c.iz];
      for (const o of this.cars) if (o !== c && o.dx === -c.dx && o.dz === -c.dz && Math.hypot(o.body.x - cx, o.body.z - cz) < 45) { sel = valid(c.dx, c.dz) ? [c.dx, c.dz, 1] : sel; break; }
    }
    c.move = [sel[0], sel[1]];
  }

  beginTurn(c) {
    const city = this.city;
    const d = [c.dx, c.dz], d2 = c.move;
    const nextW = d2[0] === 0 ? city.rw[c.ix] : city.rw[c.iz];
    const curW = d[0] === 0 ? city.rw[c.ix] : city.rw[c.iz];
    const lanesCur = laneOffsets(curW), lanesNext = laneOffsets(nextW);
    let nl = c.lane;
    if (d2[0] !== d[0] || d2[1] !== d[1]) nl = c.lane === 0 ? 0 : lanesNext.length - 1;
    nl = Math.min(nl, lanesNext.length - 1);
    const off0 = lanesCur[c.lane], off1 = lanesNext[nl];
    const cx = city.rc[c.ix], cz = city.rc[c.iz];
    const hw0 = d[0] === 0 ? city.rw[c.iz] / 2 : city.rw[c.ix] / 2;
    const hw1 = d2[0] === 0 ? city.rw[c.iz] / 2 : city.rw[c.ix] / 2;
    const r0 = [-d[1], d[0]], r1 = [-d2[1], d2[0]];
    const P0 = [cx - d[0] * hw0 + r0[0] * off0, cz - d[1] * hw0 + r0[1] * off0];
    const P2 = [cx + d2[0] * hw1 + r1[0] * off1, cz + d2[1] * hw1 + r1[1] * off1];
    let Q;
    if (d[0] === d2[0] && d[1] === d2[1]) Q = [(P0[0] + P2[0]) / 2, (P0[1] + P2[1]) / 2];
    else Q = [cx + r0[0] * off0 + r1[0] * off1, cz + r0[1] * off0 + r1[1] * off1];
    // comprimento aproximado
    let len = 0, px = P0[0], pz = P0[1];
    for (let i = 1; i <= 12; i++) { const t = i / 12, a = (1 - t) * (1 - t), b = 2 * t * (1 - t), cc = t * t; const x = a * P0[0] + b * Q[0] + cc * P2[0], z = a * P0[1] + b * Q[1] + cc * P2[1]; len += Math.hypot(x - px, z - pz); px = x; pz = z; }
    c.tpath = { P0, Q, P2, len, nl, d2 };
    c.u = 0; c.mode = 'turn';
  }

  update(dt, player, playerBody, night, audio) {
    const city = this.city;
    this.night = night;
    const pp = { x: player.x, z: player.z };
    let impactMax = 0;
    for (const c of this.cars) {
      const b = c.body;
      const dist = Math.hypot(b.x - pp.x, b.z - pp.z);
      if (c.mode === 'wreck') { this.updateWreck(c, dt); c.wreckT += dt; }
      else this.updateAI(c, dt, playerBody, pp);
      // colisão com jogador
      if (dist < 12) {
        if (c.mode !== 'wreck') { b.vx = c.v * Math.sin(b.yaw); b.vz = c.v * Math.cos(b.yaw); b.omega = 0; }
        const imp = collideObb(playerBody, obbOf(playerBody), b, obbOf(b), 0.25);
        if (imp > 0.2) {
          if (c.mode !== 'wreck') { c.mode = 'wreck'; c.wreckT = 0; }
          impactMax = Math.max(impactMax, imp);
        }
      }
      if (c.mode === 'wreck' && dist < 80) this.collideStatic(c);
      // reciclagem
      if (dist > 340 || (c.mode === 'wreck' && c.wreckT > 25 && dist > 60)) { c.mode = 'lane'; this.spawn(pp, false, c); }
      this.syncVisual(c, dt);
    }
    return impactMax;
  }

  collideStatic(c) {
    const b = c.body; const o = obbOf(b);
    this.city.queryColliders(b.x, b.z, 5, (bx) => { const B = { x: (bx[0] + bx[2]) / 2, z: (bx[1] + bx[3]) / 2, fx: 0, fz: 1, lx: 1, lz: 0, hl: (bx[3] - bx[1]) / 2, hw: (bx[2] - bx[0]) / 2 }; collideObb(b, obbOf(b), null, B, 0.15); },
      (ci) => { collideCircle(b, obbOf(b), ci[0], ci[1], ci[2], 0.15); });
  }

  updateWreck(c, dt) {
    const b = c.body; const sp = Math.hypot(b.vx, b.vz);
    const dec = Math.min(sp, 6 * dt);
    if (sp > 0.01) { b.vx -= b.vx / sp * dec; b.vz -= b.vz / sp * dec; }
    b.omega *= Math.exp(-dt * 1.6);
    b.x += b.vx * dt; b.z += b.vz * dt; b.yaw += b.omega * dt;
    c.v = sp; c.brake = sp > 0.5;
  }

  updateAI(c, dt, playerBody, pp) {
    const city = this.city, b = c.body;
    if (c.mode === 'lane') {
      const cx = city.rc[c.ix], cz = city.rc[c.iz];
      const perpHalf = c.dx === 0 ? city.rw[c.iz] / 2 : city.rw[c.ix] / 2;
      const s = (b.x - cx) * c.dx + (b.z - cz) * c.dz; // negativo ao se aproximar
      if (!c.move && -s < 60) this.chooseMove(c);
      const lineDist = perpHalf + 4.6 + 2.5 + 0.6;
      const d2stop = -s - lineDist;
      const axis = c.dx === 0 ? 'z' : 'x';
      const st = city.lightState(axis);
      let vt = c.vmax;
      if (d2stop > -2.5) {
        const brakeDist = (c.v * c.v) / (2 * 3.2) + 2;
        const mustStop = st === 'r' || (st === 'y' && d2stop > brakeDist);
        if (mustStop) vt = Math.min(vt, Math.sqrt(Math.max(0, 2 * 2.8 * Math.max(d2stop, 0))));
      }
      // cuidado com carros à frente
      const rx = -c.dz, rz = c.dx;
      const check = (ox, oz, ov, ow) => {
        const rel = (ox - b.x) * c.dx + (oz - b.z) * c.dz, lat = (ox - b.x) * rx + (oz - b.z) * rz;
        if (rel > 0 && rel < 38 && Math.abs(lat) < 1.2 + ow) {
          const gap = rel - 4.6 - ow * 0 - 1;
          vt = Math.min(vt, gap < 1.5 ? 0 : Math.min(ov + (gap - 4) * 0.55, Math.sqrt(2 * 3.5 * Math.max(gap - 1.5, 0)) + ov * 0.5));
        }
      };
      for (const o of this.cars) if (o !== c) check(o.body.x, o.body.z, o.mode === 'wreck' ? 0 : Math.max(0, o.v), 1.0);
      check(playerBody.x + Math.sin(playerBody.yaw) * playerBody.cOff, playerBody.z + Math.cos(playerBody.yaw) * playerBody.cOff, Math.max(0, playerBody.fwdSpeed * 0.8), 1.0);
      const acc = vt > c.v ? 2.6 : 7.0;
      c.v += clamp(vt - c.v, -acc * dt, acc * dt);
      c.brake = vt < c.v - 0.2;
      // movimento
      const lanes = laneOffsets(c.dx === 0 ? city.rw[c.ix] : city.rw[c.iz]);
      const off = lanes[Math.min(c.lane, lanes.length - 1)];
      b.x += c.dx * c.v * dt; b.z += c.dz * c.v * dt;
      // trava na faixa
      if (c.dx === 0) b.x = lerp(b.x, cx + (-c.dz) * off, 1 - Math.exp(-dt * 6)); else b.z = lerp(b.z, cz + c.dx * off, 1 - Math.exp(-dt * 6));
      b.yaw = Math.atan2(c.dx, c.dz);
      if (!c.move) this.chooseMove(c);
      if (s >= -perpHalf) this.beginTurn(c);
    } else if (c.mode === 'turn') {
      const p = c.tpath;
      const turning = !(p.d2[0] === c.dx && p.d2[1] === c.dz);
      const vt = turning ? Math.min(c.vmax, 6.5) : Math.min(c.vmax, 12);
      c.v += clamp(vt - c.v, -6 * dt, 2.4 * dt);
      c.brake = false;
      c.u += (c.v * dt) / p.len;
      const u = Math.min(c.u, 1), a = (1 - u) * (1 - u), bb = 2 * u * (1 - u), cc = u * u;
      b.x = a * p.P0[0] + bb * p.Q[0] + cc * p.P2[0]; b.z = a * p.P0[1] + bb * p.Q[1] + cc * p.P2[1];
      const tx = 2 * (1 - u) * (p.Q[0] - p.P0[0]) + 2 * u * (p.P2[0] - p.Q[0]), tz = 2 * (1 - u) * (p.Q[1] - p.P0[1]) + 2 * u * (p.P2[1] - p.Q[1]);
      b.yaw = Math.atan2(tx, tz);
      if (c.u >= 1) {
        c.ix += p.d2[0]; c.iz += p.d2[1]; c.dx = p.d2[0]; c.dz = p.d2[1]; c.lane = p.nl; c.move = null; c.mode = 'lane'; c.tpath = null;
      }
    }
  }

  syncVisual(c, dt) {
    const b = c.body, g = c.obj.group;
    const gy = this.city.groundHeight(b.x, b.z);
    g.position.set(b.x, gy, b.z); g.rotation.y = b.yaw;
    const st = this.night > 0.4 ? 1 : 0;
    const U = c.obj.mats.paint.userData.U;
    U.uLights.value = st; U.uBrake.value = c.brake ? 1 : 0;
    const spin = (c.v * dt) / c.spec.wR;
    for (const w of c.obj.wheels) w.spin.rotation.x += spin;
  }

  // ------------------------------------------------------------ carros estacionados (instanciados)
  initParked() {
    const cap = this.Q.parked;
    this.parkedMeshes = [];
    this.parked = { center: new THREE.Vector3(1e9, 0, 1e9), obbs: [] };
    this.parkedGroup = new THREE.Group(); this.scene.add(this.parkedGroup);
    for (const t of CAR_TYPES) {
      const { spec, geo } = this.geoCache[t];
      const mats = makeCarMaterials(spec, 0xffffff, 'lo');
      mats.paint.vertexColors = false;
      const wheelTire = [], wheelRim = [];
      for (const w of geo.wheels) {
        const m = new THREE.Matrix4().makeTranslation(w.x, spec.wR, w.z);
        const rot = new THREE.Matrix4().makeRotationY(w.side < 0 ? Math.PI : 0);
        const mm = m.multiply(rot);
        const t1 = geo.wheelGeo.tire.clone().applyMatrix4(mm); wheelTire.push(t1);
        wheelRim.push(geo.wheelGeo.rim.clone().applyMatrix4(mm)); wheelRim.push(geo.wheelGeo.disc.clone().applyMatrix4(mm));
      }
      const dark = [geo.trim, geo.under, geo.liner].filter(Boolean).map((g) => g.clone());
      const parts = [
        [geo.body, mats.paint, true], [mergeGeometries(dark), mats.liner, false], [geo.chrome, mats.chrome, false],
        [mergeGeometries(wheelTire), mats.tire, false], [mergeGeometries(wheelRim), mats.rim, false],
      ];
      const set = { type: t, spec, meshes: [], count: 0 };
      for (const [g, m, paint] of parts) {
        const im = new THREE.InstancedMesh(g, m, cap);
        im.count = 0; im.frustumCulled = false; im.castShadow = paint; im.receiveShadow = true;
        if (paint) { im.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(cap * 3), 3); }
        this.parkedGroup.add(im); set.meshes.push(im);
      }
      this.parkedMeshes.push(set);
    }
  }

  updateParked(pp) {
    const P = this.parked;
    if (Math.hypot(pp.x - P.center.x, pp.z - P.center.z) < 28) return;
    P.center.set(pp.x, 0, pp.z);
    const city = this.city, R = 230, cap = this.Q.parked;
    const list = [];
    const spacing = 7.2;
    for (let axis = 0; axis < 2; axis++) {
      for (let i = 0; i <= N; i++) {
        const rcI = city.rc[i], w = city.rw[i];
        const along = axis === 0 ? pp.x : pp.z, across = axis === 0 ? pp.z : pp.x; // axis 0: rua ao longo de z em x=rc[i]
        const lat = axis === 0 ? pp.x : pp.z;
        if (Math.abs(rcI - lat) > R) continue;
        const pos = axis === 0 ? pp.z : pp.x;
        for (let j = 0; j < N; j++) {
          const a = city.rc[j] + city.rw[j] / 2 + 9, bnd = city.rc[j + 1] - city.rw[j + 1] / 2 - 9;
          if (bnd < pos - R || a > pos + R) continue;
          const n = Math.floor((bnd - a) / spacing);
          for (const side of [-1, 1]) for (let k = 0; k < n; k++) {
            const h = hash3(axis * 1000 + i, j * 100 + k, side + 3);
            if (h > 0.2) continue;
            const t = a + (k + 0.5) * spacing + (hash3(i, k, j + side) - 0.5) * 1.2;
            const off = side * (w / 2 - 1.15) + (hash3(k, i, j) - 0.5) * 0.25;
            const x = axis === 0 ? rcI + off : t, z = axis === 0 ? t : rcI + off;
            const d2 = (x - pp.x) ** 2 + (z - pp.z) ** 2;
            if (d2 > R * R) continue;
            // avenidas têm canteiro: ignora a vaga central
            // direção: lado direito da pista segue o sentido do tráfego
            let yaw;
            if (axis === 0) yaw = side < 0 ? 0 : Math.PI; else yaw = side < 0 ? -Math.PI / 2 : Math.PI / 2; // x: lado -z ??? ajustado abaixo
            if (axis === 1) yaw = side > 0 ? -Math.PI / 2 : Math.PI / 2;
            yaw += (hash3(j, k, i) - 0.5) * 0.05;
            list.push({ x, z, yaw, d2, h: hash3(i, j * 7, k), type: Math.floor(hash3(k, i + 3, j) * 4) });
          }
        }
      }
    }
    list.sort((a, b) => a.d2 - b.d2);
    P.obbs.length = 0;
    const counts = {};
    for (const s of this.parkedMeshes) s.count = 0;
    const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), pos = new THREE.Vector3(), one = new THREE.Vector3(1, 1, 1), col = new THREE.Color(), up = new THREE.Vector3(0, 1, 0);
    let used = 0;
    for (const s of list) {
      if (used >= cap) break;
      const set = this.parkedMeshes[s.type % this.parkedMeshes.length];
      if (set.count >= cap) continue;
      q.setFromAxisAngle(up, s.yaw); pos.set(s.x, city.groundHeight(s.x, s.z), s.z);
      m4.compose(pos, q, one);
      set.meshes.forEach((im) => im.setMatrixAt(set.count, m4));
      col.setHex(COLORS[Math.floor(s.h * COLORS.length)]);
      set.meshes[0].setColorAt(set.count, col);
      set.count++; used++;
      P.obbs.push({ x: s.x, z: s.z, fx: Math.sin(s.yaw), fz: Math.cos(s.yaw), lx: Math.cos(s.yaw), lz: -Math.sin(s.yaw), hl: set.spec.L / 2, hw: set.spec.W });
    }
    for (const set of this.parkedMeshes) for (const im of set.meshes) {
      im.count = set.count; im.instanceMatrix.needsUpdate = true; if (im.instanceColor) im.instanceColor.needsUpdate = true;
    }
  }
}
